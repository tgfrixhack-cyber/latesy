// Single entry point: Next.js site + PvP WebSocket on one port.
//   node server/index.ts               — development (next dev + game)
//   node server/index.ts --prod        — production (run `next build` first)
//   node server/index.ts --game-only   — only the game server, e.g. when the site is a static export
// Env: PORT (default 3000), PVP_TIME_SCALE (e.g. 0.1 makes buffs every 12 s for testing).
import { createServer } from "node:http";
import type { IncomingMessage, ServerResponse } from "node:http";
import next from "next";
import { PvpServer } from "./game.ts";

const args = new Set(process.argv.slice(2));
const port = Number(process.env.PORT) || 3000;
const host = process.env.BIND_HOST || "0.0.0.0";
const gameOnly = args.has("--game-only");
const dev = !args.has("--prod") && !gameOnly;
const timeScale = Number(process.env.PVP_TIME_SCALE) || 1;

const game = new PvpServer({ timeScale });

async function main() {
  let handle: ((req: IncomingMessage, res: ServerResponse) => Promise<void>) | null = null;
  const server = createServer((req, res) => {
    if (handle) return void handle(req, res);
    res.writeHead(200, { "content-type": "text/plain; charset=utf-8" });
    res.end("PvP game server is running\n");
  });

  // Next attaches its own upgrade listener (HMR) and ignores paths it doesn't own, so both coexist.
  server.on("upgrade", (req, socket, head) => {
    game.handleUpgrade(req, socket, head);
  });

  if (!gameOnly) {
    const app = next({ dev, httpServer: server, port });
    await app.prepare();
    const requestHandler = app.getRequestHandler();
    handle = (req, res) => requestHandler(req, res);
  }

  server.listen(port, host, () => {
    const mode = gameOnly ? "game only" : dev ? "development" : "production";
    console.log(`> Ready on http://${host}:${port} (${mode}), game socket at ws://${host}:${port}/game-ws`);
  });
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
