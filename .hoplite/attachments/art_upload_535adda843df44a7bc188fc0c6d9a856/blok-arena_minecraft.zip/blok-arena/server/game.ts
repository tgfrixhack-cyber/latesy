import type { IncomingMessage } from "node:http";
import type { Duplex } from "node:stream";
import { WebSocketServer, WebSocket } from "ws";
import {
  ARENA_RADIUS,
  BUFF_IDS,
  BUFFS,
  BUILD_REACH,
  BUILDER_BONUS,
  CRIT_MULTIPLIER,
  EYE_HEIGHT,
  HIT_COOLDOWN_MS,
  HIT_REACH,
  MAX_HEIGHT,
  MAX_HP,
  MAX_PLAYERS,
  MIN_PLAYERS,
  PLAYER_COLORS,
  PLAYER_HALF_WIDTH,
  PLAYER_HEIGHT,
  ROULETTE_MS,
  START_DIRT,
  TICK_MS,
  Voxels,
  WS_PATH,
  buffIndexAt,
  buffModifiers,
  cellInRing,
  makeTimings,
  ringRadiusAt,
  spawnPoint,
} from "../src/game/shared.ts";
import type { BagInfo, BuffId, ClientMsg, Phase, PlayerInfo, Role, ServerMsg, Timings } from "../src/game/shared.ts";

interface Client {
  id: number;
  ws: WebSocket;
  name: string | null;
  color: string;
  role: Role;
  joinedAt: number;
  voted: boolean;
  alive: boolean;
  hp: number;
  dirt: number;
  kills: number;
  x: number;
  y: number;
  z: number;
  yaw: number;
  pitch: number;
  lastHit: number;
  lastBreak: number;
  vy: number;
  lastMoveAt: number;
  isAlive: boolean;
}

const BREAK_COOLDOWN_MS = 120;
const LAVA_INTERVAL_MS = 1000;

const finite = (...v: unknown[]) => v.every((n) => typeof n === "number" && Number.isFinite(n));
const ints = (...v: unknown[]) => v.every((n) => Number.isInteger(n));
const r2 = (n: number) => Math.round(n * 100) / 100;

function shuffle<T>(items: T[]): T[] {
  const a = [...items];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function sanitizeName(raw: unknown): string {
  if (typeof raw !== "string") return "";
  return raw.replace(/[\u0000-\u001f\u007f<>]/g, "").replace(/\s+/g, " ").trim().slice(0, 16);
}

/** Distance from a point to the closest point of a player's bounding box. */
function distToPlayer(px: number, py: number, pz: number, c: Client): number {
  const dx = Math.max(c.x - PLAYER_HALF_WIDTH - px, 0, px - (c.x + PLAYER_HALF_WIDTH));
  const dy = Math.max(c.y - py, 0, py - (c.y + PLAYER_HEIGHT));
  const dz = Math.max(c.z - PLAYER_HALF_WIDTH - pz, 0, pz - (c.z + PLAYER_HALF_WIDTH));
  return Math.hypot(dx, dy, dz);
}

export class PvpServer {
  readonly timings: Timings;
  private wss: WebSocketServer;
  private clients = new Map<number, Client>();
  private nextId = 1;
  private phase: Phase = "lobby";
  private phaseStart = Date.now();
  private world = new Voxels();
  private bags = new Map<number, BagInfo>();
  private nextBagId = 1;
  private buffPlan: BuffId[] = [];
  private buffIndex = -1;
  private winner: Client | null = null;
  private randomWin = false;
  private lastLava = 0;
  private rouletteIndex = -1;
  private tickTimer: ReturnType<typeof setInterval>;
  private pingTimer: ReturnType<typeof setInterval>;

  constructor(opts: { timeScale?: number } = {}) {
    this.timings = makeTimings(opts.timeScale ?? 1);
    this.wss = new WebSocketServer({ noServer: true, maxPayload: 4096 });
    this.wss.on("connection", (ws) => this.onConnection(ws));
    this.tickTimer = setInterval(() => this.tick(), TICK_MS);
    this.pingTimer = setInterval(() => {
      for (const c of this.clients.values()) {
        if (!c.isAlive) {
          c.ws.terminate();
          continue;
        }
        c.isAlive = false;
        c.ws.ping();
      }
    }, 15_000);
  }

  /** Returns true when the upgrade request belonged to the game. */
  handleUpgrade(req: IncomingMessage, socket: Duplex, head: Buffer): boolean {
    const { pathname } = new URL(req.url ?? "/", "http://localhost");
    if (pathname !== WS_PATH) return false;
    this.wss.handleUpgrade(req, socket, head, (ws) => this.wss.emit("connection", ws, req));
    return true;
  }

  close(): void {
    clearInterval(this.tickTimer);
    clearInterval(this.pingTimer);
    this.wss.close();
  }

  // ---------------------------------------------------------------- connections

  private onConnection(ws: WebSocket): void {
    const c: Client = {
      id: this.nextId++,
      ws,
      name: null,
      color: PLAYER_COLORS[0],
      role: "spectator",
      joinedAt: Date.now(),
      voted: false,
      alive: false,
      hp: MAX_HP,
      dirt: 0,
      kills: 0,
      x: 0,
      y: 0,
      z: 0,
      yaw: 0,
      pitch: 0,
      lastHit: 0,
      lastBreak: 0,
      vy: 0,
      lastMoveAt: 0,
      isAlive: true,
    };
    this.clients.set(c.id, c);
    ws.on("pong", () => (c.isAlive = true));
    ws.on("message", (data) => {
      let msg: ClientMsg;
      try {
        msg = JSON.parse(String(data));
      } catch {
        return;
      }
      this.onMessage(c, msg);
    });
    ws.on("close", () => this.onClose(c));
    ws.on("error", () => ws.terminate());
  }

  private onMessage(c: Client, m: ClientMsg): void {
    if (!m || typeof m !== "object") return;
    if (m.t === "hello") return this.onHello(c, m.name);
    if (!c.name) return;
    switch (m.t) {
      case "vote":
        return this.onVote(c, !!m.on);
      case "move":
        return this.onMove(c, m);
      case "hit":
        return this.onHit(c, m.id);
      case "place":
        return this.onPlace(c, m.x, m.y, m.z);
      case "break":
        return this.onBreak(c, m.x, m.y, m.z);
    }
  }

  private onHello(c: Client, rawName: unknown): void {
    if (c.name) return;
    let name = sanitizeName(rawName) || `Игрок${c.id}`;
    const taken = new Set(this.named().map((p) => p.name.toLowerCase()));
    if (taken.has(name.toLowerCase())) name = `${name.slice(0, 13)}#${c.id}`;
    c.name = name;
    const usedColors = new Set(this.named().map((p) => p.color));
    c.color = PLAYER_COLORS.find((col) => !usedColors.has(col)) ?? PLAYER_COLORS[c.id % PLAYER_COLORS.length];
    c.joinedAt = Date.now();
    c.role = this.phase === "lobby" && this.participants().length < MAX_PLAYERS ? "player" : "spectator";

    this.send(c, { t: "welcome", id: c.id });
    this.send(c, { t: "world", blocks: this.world.toList() });
    this.send(c, { t: "bags", bags: [...this.bags.values()] });
    this.send(c, this.phaseMsg());
    this.sendYou(c);
    this.broadcastRoster();
  }

  private onClose(c: Client): void {
    this.clients.delete(c.id);
    if (!c.name) return;
    if (c.alive && (this.phase === "playing" || this.phase === "countdown")) {
      this.eliminate(c, null, "leave");
    }
    if (this.phase === "lobby") this.fillLobbySlots();
    this.broadcastRoster();
    if (this.phase === "lobby") this.maybeStart();
    else this.checkRoundEnd();
  }

  // ---------------------------------------------------------------- lobby

  private named(): (Client & { name: string })[] {
    return [...this.clients.values()].filter((c): c is Client & { name: string } => c.name !== null);
  }

  private participants(): Client[] {
    return this.named().filter((c) => c.role === "player");
  }

  private fillLobbySlots(): void {
    const queue = this.named().sort((a, b) => a.joinedAt - b.joinedAt);
    let slots = MAX_PLAYERS;
    for (const c of queue) {
      if (slots > 0) {
        if (c.role !== "player") c.voted = false;
        c.role = "player";
        slots--;
      } else {
        c.role = "spectator";
        c.voted = false;
      }
    }
  }

  private onVote(c: Client, on: boolean): void {
    if (this.phase !== "lobby" || c.role !== "player") return;
    c.voted = on;
    this.broadcastRoster();
    this.maybeStart();
  }

  private maybeStart(): void {
    const ps = this.participants();
    const votes = ps.filter((p) => p.voted).length;
    if (ps.length >= MIN_PLAYERS && votes * 2 > ps.length) this.startCountdown();
  }

  private startCountdown(): void {
    const ps = shuffle(this.participants());
    const offset = Math.random() * Math.PI * 2;
    this.world.clear();
    this.bags.clear();
    this.buffPlan = shuffle(BUFF_IDS).slice(0, Math.max(0, Math.ceil(this.timings.roundMs / this.timings.buffIntervalMs) - 1));
    this.buffIndex = -1;
    this.rouletteIndex = -1;
    this.winner = null;
    this.randomWin = false;
    this.setPhase("countdown");
    ps.forEach((p, i) => {
      const s = spawnPoint(i, ps.length, offset);
      Object.assign(p, { x: s.x, y: 0, z: s.z, yaw: s.yaw, pitch: 0, alive: true, hp: MAX_HP, dirt: START_DIRT, kills: 0, voted: false, vy: 0, lastMoveAt: 0 });
      this.send(p, { t: "tp", x: s.x, y: 0, z: s.z, yaw: s.yaw });
      this.sendYou(p);
    });
    for (const c of this.named()) if (c.role !== "player") this.sendYou(c);
    this.broadcast({ t: "world", blocks: [] });
    this.broadcast({ t: "bags", bags: [] });
    this.broadcastRoster();
  }

  private toLobby(): void {
    this.world.clear();
    this.bags.clear();
    this.buffPlan = [];
    this.buffIndex = -1;
    for (const c of this.named()) {
      c.alive = false;
      c.voted = false;
      c.role = "spectator";
    }
    this.fillLobbySlots();
    this.setPhase("lobby");
    this.broadcast({ t: "world", blocks: [] });
    this.broadcast({ t: "bags", bags: [] });
    for (const c of this.named()) this.sendYou(c);
    this.broadcastRoster();
  }

  // ---------------------------------------------------------------- round

  private get currentBuff(): BuffId | null {
    return this.buffIndex >= 0 ? this.buffPlan[this.buffIndex] : null;
  }

  private get ringRadius(): number {
    return this.phase === "playing" ? ringRadiusAt(Date.now() - this.phaseStart, this.timings) : ARENA_RADIUS;
  }

  private setPhase(phase: Phase): void {
    this.phase = phase;
    this.phaseStart = Date.now();
    this.broadcast(this.phaseMsg());
  }

  private phaseMsg(): ServerMsg {
    return {
      t: "phase",
      phase: this.phase,
      elapsed: Date.now() - this.phaseStart,
      timings: this.timings,
      buff: this.currentBuff,
      winner: this.winner?.id ?? null,
      winnerName: this.winner?.name ?? null,
      randomWin: this.randomWin,
    };
  }

  private activateBuff(index: number): void {
    this.buffIndex = index;
    const buff = this.buffPlan[index];
    this.broadcast({ t: "buff", buff });
    if (buff === "builder") {
      for (const p of this.alivePlayers()) {
        p.dirt += BUILDER_BONUS;
        this.sendYou(p);
      }
    }
    console.log(`[pvp] buff: ${BUFFS[buff].title}`);
  }

  private alivePlayers(): Client[] {
    return this.participants().filter((p) => p.alive);
  }

  private checkRoundEnd(): void {
    if (this.phase !== "playing" && this.phase !== "countdown") return;
    const alive = this.alivePlayers();
    if (alive.length <= 1) this.endRound(alive[0] ?? null, false);
  }

  private endRound(winner: Client | null, random: boolean): void {
    this.winner = winner;
    this.randomWin = random;
    for (const c of this.named()) c.alive = false;
    this.setPhase("ended");
    this.broadcastRoster();
    for (const c of this.named()) this.sendYou(c);
  }

  private eliminate(victim: Client, killer: Client | null, reason: "kill" | "leave"): void {
    victim.alive = false;
    victim.hp = 0;
    if (killer) killer.kills++;
    if (victim.dirt > 0) {
      const bag: BagInfo = { id: this.nextBagId++, x: r2(victim.x), y: this.groundBelow(victim.x, victim.y, victim.z), z: r2(victim.z), dirt: victim.dirt };
      this.bags.set(bag.id, bag);
      this.broadcast({ t: "bags", bags: [...this.bags.values()] });
    }
    victim.dirt = 0;
    this.broadcast({ t: "kill", victim: victim.id, killer: killer?.id ?? null, reason });
    this.broadcastRoster();
    if (victim.ws.readyState === WebSocket.OPEN) this.sendYou(victim);
    this.checkRoundEnd();
  }

  private groundBelow(x: number, y: number, z: number): number {
    const ix = Math.floor(x);
    const iz = Math.floor(z);
    for (let iy = Math.min(MAX_HEIGHT - 1, Math.floor(y)); iy >= 0; iy--) {
      if (this.world.get(ix, iy, iz)) return iy + 1;
    }
    return 0;
  }

  private tick(): void {
    const now = Date.now();
    const elapsed = now - this.phaseStart;
    if (this.phase === "countdown" && elapsed >= this.timings.countdownMs) {
      this.setPhase("playing");
      return;
    }
    if (this.phase === "ended" && elapsed >= this.timings.endMs) {
      this.toLobby();
      return;
    }
    if (this.phase !== "playing" && this.phase !== "countdown") return;

    if (this.phase === "playing") {
      const target = buffIndexAt(elapsed, this.timings, this.buffPlan.length);
      while (this.buffIndex < target) this.activateBuff(this.buffIndex + 1);

      const next = this.buffIndex + 1;
      if (next < this.buffPlan.length && this.rouletteIndex < next) {
        const at = (next + 1) * this.timings.buffIntervalMs;
        if (at - elapsed <= Math.min(ROULETTE_MS, this.timings.buffIntervalMs / 2)) {
          this.rouletteIndex = next;
          this.broadcast({ t: "roulette", buff: this.buffPlan[next], ms: at - elapsed });
        }
      }

      if (buffModifiers(this.currentBuff).lava && now - this.lastLava >= LAVA_INTERVAL_MS) {
        this.lastLava = now;
        for (const p of this.alivePlayers()) {
          if (p.y > 0.05 || p.hp <= 1) continue;
          p.hp -= 1;
          this.broadcast({ t: "hurt", id: p.id, by: 0, hp: p.hp, dmg: 1, crit: false, kx: 0, ky: 0, kz: 0 });
          this.sendYou(p);
        }
      }

      this.pickupBags();

      if (elapsed >= this.timings.roundMs) {
        const alive = this.alivePlayers();
        const pick = alive[Math.floor(Math.random() * alive.length)] ?? null;
        this.endRound(pick, alive.length > 1);
        return;
      }
    }

    const p: number[] = [];
    for (const c of this.alivePlayers()) p.push(c.id, r2(c.x), r2(c.y), r2(c.z), r2(c.yaw), r2(c.pitch), c.hp);
    this.broadcast({ t: "tick", p });
  }

  private pickupBags(): void {
    if (!this.bags.size) return;
    let changed = false;
    for (const bag of this.bags.values()) {
      for (const p of this.alivePlayers()) {
        if (Math.hypot(p.x - bag.x, p.z - bag.z) > 1.6 || Math.abs(p.y - bag.y) > 2) continue;
        p.dirt += bag.dirt;
        this.sendYou(p);
        this.bags.delete(bag.id);
        changed = true;
        break;
      }
    }
    if (changed) this.broadcast({ t: "bags", bags: [...this.bags.values()] });
  }

  // ---------------------------------------------------------------- actions

  private onMove(c: Client, m: { x: number; y: number; z: number; yaw: number; pitch: number }): void {
    if (this.phase !== "playing" || !c.alive || !finite(m.x, m.y, m.z, m.yaw, m.pitch)) return;
    // Movement is client-side; reject blatant teleports and clamp to the arena.
    if (Math.hypot(m.x - c.x, m.y - c.y, m.z - c.z) > 12) {
      this.send(c, { t: "tp", x: c.x, y: c.y, z: c.z, yaw: c.yaw });
      return;
    }
    let { x, z } = m;
    const limit = this.ringRadius - PLAYER_HALF_WIDTH + 0.5;
    const r = Math.hypot(x, z);
    if (r > limit) {
      x *= limit / r;
      z *= limit / r;
    }
    const now = Date.now();
    const y = Math.min(Math.max(m.y, 0), MAX_HEIGHT - PLAYER_HEIGHT);
    c.vy = (y - c.y) / Math.max(0.02, (now - c.lastMoveAt) / 1000);
    c.lastMoveAt = now;
    c.x = x;
    c.z = z;
    c.y = y;
    c.yaw = m.yaw;
    c.pitch = Math.max(-Math.PI / 2, Math.min(Math.PI / 2, m.pitch));
  }

  private onHit(c: Client, targetId: number): void {
    if (this.phase !== "playing" || !c.alive) return;
    const t = this.clients.get(targetId);
    if (!t || t === c || !t.alive || t.role !== "player") return;
    const now = Date.now();
    if (now - c.lastHit < HIT_COOLDOWN_MS * 0.8) return;
    if (distToPlayer(c.x, c.y + EYE_HEIGHT, c.z, t) > HIT_REACH + 1.2) return;
    c.lastHit = now;

    const mods = buffModifiers(this.currentBuff);
    // Minecraft-style critical hit: the attacker is falling and off the ground.
    const crit = now - c.lastMoveAt < 300 && c.vy < -1 && c.y - this.groundBelow(c.x, c.y, c.z) > 0.1;
    const dmg = Math.min(t.hp, crit ? Math.ceil(mods.damage * CRIT_MULTIPLIER) : mods.damage);
    t.hp -= dmg;
    if (mods.lifesteal && c.hp < MAX_HP) {
      c.hp = Math.min(MAX_HP, c.hp + dmg);
      this.sendYou(c);
    }
    let dx = t.x - c.x;
    let dz = t.z - c.z;
    const len = Math.hypot(dx, dz);
    if (len < 0.01) {
      dx = -Math.sin(c.yaw);
      dz = -Math.cos(c.yaw);
    } else {
      dx /= len;
      dz /= len;
    }
    const kb = 7 * mods.knockback;
    this.broadcast({ t: "hurt", id: t.id, by: c.id, hp: t.hp, dmg, crit, kx: r2(dx * kb), ky: mods.knockback > 1 ? 8 : 5.5, kz: r2(dz * kb) });
    if (t.hp <= 0) this.eliminate(t, c, "kill");
    else this.sendYou(t);
  }

  private canReach(c: Client, x: number, y: number, z: number): boolean {
    return Math.hypot(x + 0.5 - c.x, y + 0.5 - (c.y + EYE_HEIGHT), z + 0.5 - c.z) <= BUILD_REACH + 1.5;
  }

  private onPlace(c: Client, x: number, y: number, z: number): void {
    if (this.phase !== "playing" || !c.alive || c.dirt <= 0 || !ints(x, y, z)) return;
    if (!Voxels.inBounds(x, y, z) || !cellInRing(x, z, this.ringRadius) || this.world.get(x, y, z)) return;
    if (!this.canReach(c, x, y, z)) return;
    const w = this.world;
    const supported =
      y === 0 || w.get(x + 1, y, z) || w.get(x - 1, y, z) || w.get(x, y + 1, z) || w.get(x, y - 1, z) || w.get(x, y, z + 1) || w.get(x, y, z - 1);
    if (!supported) return;
    // Lenient overlap test: positions lag a little, and clients push themselves out of blocks.
    for (const p of this.alivePlayers()) {
      const hw = PLAYER_HALF_WIDTH - 0.1;
      if (p.x + hw > x && p.x - hw < x + 1 && p.z + hw > z && p.z - hw < z + 1 && p.y + PLAYER_HEIGHT - 0.1 > y && p.y + 0.5 < y + 1) return;
    }
    w.set(x, y, z, 1);
    c.dirt--;
    this.broadcast({ t: "block", x, y, z, v: 1 });
    this.sendYou(c);
  }

  private onBreak(c: Client, x: number, y: number, z: number): void {
    if (this.phase !== "playing" || !c.alive || !ints(x, y, z) || !this.world.get(x, y, z)) return;
    const now = Date.now();
    if (now - c.lastBreak < BREAK_COOLDOWN_MS || !this.canReach(c, x, y, z)) return;
    c.lastBreak = now;
    this.world.set(x, y, z, 0);
    c.dirt++;
    this.broadcast({ t: "block", x, y, z, v: 0 });
    this.sendYou(c);
  }

  // ---------------------------------------------------------------- messaging

  private send(c: Client, msg: ServerMsg): void {
    if (c.ws.readyState === WebSocket.OPEN) c.ws.send(JSON.stringify(msg));
  }

  private broadcast(msg: ServerMsg): void {
    const data = JSON.stringify(msg);
    for (const c of this.clients.values()) {
      if (c.name && c.ws.readyState === WebSocket.OPEN) c.ws.send(data);
    }
  }

  private sendYou(c: Client): void {
    this.send(c, { t: "you", hp: c.hp, dirt: c.dirt, alive: c.alive, role: c.role });
  }

  private broadcastRoster(): void {
    const players: PlayerInfo[] = this.named()
      .sort((a, b) => a.joinedAt - b.joinedAt)
      .map((c) => ({ id: c.id, name: c.name, color: c.color, role: c.role, alive: c.alive, voted: c.voted, kills: c.kills }));
    this.broadcast({ t: "roster", players });
  }
}
