// Shared by the browser client and the Node game server (run via Node type stripping):
// keep it dependency-free, use `import type` only, no enums or parameter properties.

export const WS_PATH = "/game-ws";

export const MIN_PLAYERS = 2;
export const MAX_PLAYERS = 12;

export const ARENA_RADIUS = 48;
export const FINAL_RING_RADIUS = 12;
export const SPAWN_RADIUS = 40;
/** Ceiling: neither blocks nor players can go above y = MAX_HEIGHT. */
export const MAX_HEIGHT = 20;
export const GRID = ARENA_RADIUS * 2 + 1;

export const PLAYER_HALF_WIDTH = 0.3;
export const PLAYER_HEIGHT = 1.8;
export const EYE_HEIGHT = 1.62;

export const MAX_HP = 20;
export const HIT_DAMAGE = 4;
export const HIT_COOLDOWN_MS = 450;
export const HIT_REACH = 3.6;
export const BUILD_REACH = 5.5;
export const START_DIRT = 10;
export const BUILDER_BONUS = 20;
export const CRIT_MULTIPLIER = 1.5;
/** How long the buff roulette spins before each buff. */
export const ROULETTE_MS = 4500;

export const TICK_MS = 50;

export interface Timings {
  countdownMs: number;
  roundMs: number;
  buffIntervalMs: number;
  shrinkStartMs: number;
  endMs: number;
}

export function makeTimings(scale = 1): Timings {
  return {
    countdownMs: 3000,
    roundMs: 10 * 60_000 * scale,
    buffIntervalMs: 2 * 60_000 * scale,
    shrinkStartMs: 8 * 60_000 * scale,
    endMs: 8000,
  };
}

export type Phase = "lobby" | "countdown" | "playing" | "ended";
export type Role = "player" | "spectator";

export type BuffId =
  | "gravity"
  | "speed"
  | "oneshot"
  | "vampire"
  | "fog"
  | "lava"
  | "knockback"
  | "doublejump"
  | "invisible"
  | "strength"
  | "builder";

export interface BuffDef {
  id: BuffId;
  title: string;
  description: string;
  color: string;
}

export const BUFFS: Record<BuffId, BuffDef> = {
  gravity: { id: "gravity", title: "ГРАВИТАЦИЯ", description: "Гравитация ослабла: прыжки выше, падение медленнее", color: "#7dd3fc" },
  speed: { id: "speed", title: "СКОРОСТЬ", description: "Все бегают в 1.7 раза быстрее", color: "#facc15" },
  oneshot: { id: "oneshot", title: "ВАНШОТ", description: "Один удар — одна смерть", color: "#ef4444" },
  vampire: { id: "vampire", title: "ВАМПИРИЗМ", description: "Урон по врагу лечит вас", color: "#f43f5e" },
  fog: { id: "fog", title: "ТУМАН", description: "Видимость — 10 блоков", color: "#cbd5e1" },
  lava: { id: "lava", title: "ПОЛ — ЛАВА", description: "Пол жжёт, но добить может только игрок. Стройтесь!", color: "#fb923c" },
  knockback: { id: "knockback", title: "ОТБРАСЫВАНИЕ", description: "Удары отбрасывают втрое сильнее", color: "#a78bfa" },
  doublejump: { id: "doublejump", title: "ДВОЙНОЙ ПРЫЖОК", description: "Можно прыгнуть ещё раз в воздухе", color: "#34d399" },
  invisible: { id: "invisible", title: "НЕВИДИМОСТЬ", description: "Все невидимы. Удар выдаёт вас на секунду", color: "#94a3b8" },
  strength: { id: "strength", title: "СИЛА", description: "Урон ×2", color: "#dc2626" },
  builder: { id: "builder", title: "СТРОЙКА", description: `Каждому +${BUILDER_BONUS} земли`, color: "#d4a373" },
};

export const BUFF_IDS = Object.keys(BUFFS) as BuffId[];

export function buffModifiers(buff: BuffId | null) {
  return {
    gravity: buff === "gravity" ? 0.35 : 1,
    speed: buff === "speed" ? 1.7 : 1,
    damage: buff === "oneshot" ? MAX_HP : buff === "strength" ? HIT_DAMAGE * 2 : HIT_DAMAGE,
    lifesteal: buff === "vampire",
    fog: buff === "fog",
    lava: buff === "lava",
    knockback: buff === "knockback" ? 3 : 1,
    extraJumps: buff === "doublejump" ? 1 : 0,
    invisible: buff === "invisible",
  };
}

/** Index of the active buff for a moment of the round, -1 before the first one. */
export function buffIndexAt(elapsedMs: number, t: Timings, planLength: number): number {
  return Math.min(planLength - 1, Math.floor(elapsedMs / t.buffIntervalMs) - 1);
}

export function ringRadiusAt(elapsedMs: number, t: Timings): number {
  if (elapsedMs <= t.shrinkStartMs) return ARENA_RADIUS;
  const k = Math.min(1, (elapsedMs - t.shrinkStartMs) / (t.roundMs - t.shrinkStartMs));
  return ARENA_RADIUS + (FINAL_RING_RADIUS - ARENA_RADIUS) * k;
}

/** Spawn points sit evenly on a circle, each facing the centre (yaw 0 looks towards -Z). */
export function spawnPoint(index: number, count: number, offset: number) {
  const a = offset + (index / count) * Math.PI * 2;
  const x = Math.cos(a) * SPAWN_RADIUS;
  const z = Math.sin(a) * SPAWN_RADIUS;
  return { x, z, yaw: Math.atan2(x, z) };
}

export function cellInRing(x: number, z: number, radius: number): boolean {
  const cx = x + 0.5;
  const cz = z + 0.5;
  return cx * cx + cz * cz <= radius * radius;
}

/** Voxel storage for player-placed blocks (the floor is implicit and unbreakable). */
export class Voxels {
  readonly data = new Uint8Array(GRID * GRID * MAX_HEIGHT);
  readonly filled = new Set<number>();

  static inBounds(x: number, y: number, z: number): boolean {
    return y >= 0 && y < MAX_HEIGHT && cellInRing(x, z, ARENA_RADIUS);
  }

  static index(x: number, y: number, z: number): number {
    return (y * GRID + (z + ARENA_RADIUS)) * GRID + (x + ARENA_RADIUS);
  }

  static decode(i: number): [number, number, number] {
    const x = (i % GRID) - ARENA_RADIUS;
    const z = (Math.floor(i / GRID) % GRID) - ARENA_RADIUS;
    const y = Math.floor(i / (GRID * GRID));
    return [x, y, z];
  }

  get(x: number, y: number, z: number): number {
    return Voxels.inBounds(x, y, z) ? this.data[Voxels.index(x, y, z)] : 0;
  }

  set(x: number, y: number, z: number, v: number): boolean {
    if (!Voxels.inBounds(x, y, z)) return false;
    const i = Voxels.index(x, y, z);
    this.data[i] = v;
    if (v) this.filled.add(i);
    else this.filled.delete(i);
    return true;
  }

  /** Solid for movement: blocks, the floor (y < 0) and the ceiling (y >= MAX_HEIGHT). */
  solid(x: number, y: number, z: number): boolean {
    if (y < 0 || y >= MAX_HEIGHT) return true;
    return this.get(x, y, z) !== 0;
  }

  clear(): void {
    this.data.fill(0);
    this.filled.clear();
  }

  /** Flat [x, y, z, x, y, z, ...] list of filled cells. */
  toList(): number[] {
    const out: number[] = [];
    for (const i of this.filled) out.push(...Voxels.decode(i));
    return out;
  }
}

export interface PlayerInfo {
  id: number;
  name: string;
  color: string;
  role: Role;
  alive: boolean;
  voted: boolean;
  kills: number;
}

export interface BagInfo {
  id: number;
  x: number;
  y: number;
  z: number;
  dirt: number;
}

export type ClientMsg =
  | { t: "hello"; name: string }
  | { t: "vote"; on: boolean }
  | { t: "move"; x: number; y: number; z: number; yaw: number; pitch: number }
  | { t: "hit"; id: number }
  | { t: "place"; x: number; y: number; z: number }
  | { t: "break"; x: number; y: number; z: number };

export type ServerMsg =
  | { t: "welcome"; id: number }
  | { t: "roster"; players: PlayerInfo[] }
  | {
      t: "phase";
      phase: Phase;
      elapsed: number;
      timings: Timings;
      buff: BuffId | null;
      winner: number | null;
      winnerName: string | null;
      randomWin: boolean;
    }
  | { t: "buff"; buff: BuffId }
  | { t: "world"; blocks: number[] }
  | { t: "block"; x: number; y: number; z: number; v: number }
  /** Flat [id, x, y, z, yaw, pitch, hp, ...] for every alive player. */
  | { t: "tick"; p: number[] }
  | { t: "you"; hp: number; dirt: number; alive: boolean; role: Role }
  | { t: "tp"; x: number; y: number; z: number; yaw: number }
  | { t: "hurt"; id: number; by: number; hp: number; dmg: number; crit: boolean; kx: number; ky: number; kz: number }
  | { t: "roulette"; buff: BuffId; ms: number }
  | { t: "kill"; victim: number; killer: number | null; reason: "kill" | "leave" }
  | { t: "bags"; bags: BagInfo[] };

export const PLAYER_COLORS = [
  "#e74c3c", "#3498db", "#2ecc71", "#f1c40f", "#9b59b6", "#e67e22",
  "#1abc9c", "#ff6b9d", "#95a5a6", "#34495e", "#8e44ad", "#16a085",
];
