import * as THREE from "three";
import { numberTexture } from "./textures";

interface Particle {
  p: THREE.Vector3;
  v: THREE.Vector3;
  life: number;
  size: number;
  spin: number;
}

export class Particles {
  readonly mesh: THREE.InstancedMesh;
  private items: Particle[] = [];
  private dummy = new THREE.Object3D();
  private color = new THREE.Color();
  private next = 0;

  constructor(private max = 400) {
    this.mesh = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), new THREE.MeshBasicMaterial(), max);
    this.mesh.frustumCulled = false;
    for (let i = 0; i < max; i++) {
      this.items.push({ p: new THREE.Vector3(), v: new THREE.Vector3(), life: 0, size: 0.1, spin: 0 });
      this.mesh.setColorAt(i, this.color);
    }
  }

  burst(at: THREE.Vector3, colors: string[], count: number, speed: number, size = 0.1) {
    for (let n = 0; n < count; n++) {
      const i = this.next;
      this.next = (this.next + 1) % this.max;
      const it = this.items[i];
      it.p.set(at.x + (Math.random() - 0.5) * 0.5, at.y + (Math.random() - 0.5) * 0.5, at.z + (Math.random() - 0.5) * 0.5);
      it.v.set((Math.random() - 0.5) * speed, Math.random() * speed, (Math.random() - 0.5) * speed);
      it.life = 0.5 + Math.random() * 0.4;
      it.size = size * (0.7 + Math.random() * 0.6);
      it.spin = (Math.random() - 0.5) * 12;
      this.mesh.setColorAt(i, this.color.set(colors[n % colors.length]));
    }
    if (this.mesh.instanceColor) this.mesh.instanceColor.needsUpdate = true;
  }

  /** dt = 0 freezes particles in place (hit-stop). */
  update(dt: number) {
    if (dt === 0) return;
    this.items.forEach((it, i) => {
      if (it.life > 0) {
        it.life -= dt;
        it.v.y -= 18 * dt;
        it.p.addScaledVector(it.v, dt);
        if (it.p.y < 0.05) {
          it.p.y = 0.05;
          it.v.set(it.v.x * 0.5, 0, it.v.z * 0.5);
        }
      }
      this.dummy.position.copy(it.p);
      this.dummy.rotation.set(it.spin * it.life, it.spin * it.life * 0.7, 0);
      this.dummy.scale.setScalar(it.life > 0 ? it.size * Math.min(1, it.life / 0.15) : 0);
      this.dummy.updateMatrix();
      this.mesh.setMatrixAt(i, this.dummy.matrix);
    });
    this.mesh.instanceMatrix.needsUpdate = true;
  }
}

interface FloatingNumber {
  sprite: THREE.Sprite;
  born: number;
  base: THREE.Vector3;
  drift: number;
  height: number;
}

const NUMBER_MS = 900;

/** Damage numbers that pop above the victim, float up and fade. */
export class DamageNumbers {
  readonly group = new THREE.Group();
  private items: FloatingNumber[] = [];
  private cache = new Map<string, THREE.CanvasTexture>();

  spawn(at: THREE.Vector3, text: string, color: string, big: boolean, now: number) {
    const key = `${text}|${color}`;
    let tex = this.cache.get(key);
    if (!tex) {
      tex = numberTexture(text, color);
      this.cache.set(key, tex);
    }
    const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthTest: false, depthWrite: false }));
    sprite.renderOrder = 1000;
    sprite.center.set(0.5, 0);
    this.group.add(sprite);
    this.items.push({ sprite, born: now, base: at.clone(), drift: (Math.random() - 0.5) * 0.8, height: big ? 0.42 : 0.3 });
  }

  update(now: number) {
    this.items = this.items.filter((n) => {
      const t = (now - n.born) / NUMBER_MS;
      if (t >= 1) {
        this.group.remove(n.sprite);
        n.sprite.material.dispose();
        return false;
      }
      const img = n.sprite.material.map!.image as HTMLCanvasElement;
      const h = n.height * (t < 0.15 ? 1.5 - (t / 0.15) * 0.5 : 1);
      n.sprite.scale.set((h * img.width) / img.height, h, 1);
      n.sprite.position.set(n.base.x + n.drift * t, n.base.y + 0.9 * (1 - (1 - t) * (1 - t)), n.base.z);
      n.sprite.material.opacity = t > 0.6 ? 1 - (t - 0.6) / 0.4 : 1;
      return true;
    });
  }

  dispose() {
    for (const n of this.items) n.sprite.material.dispose();
    for (const t of this.cache.values()) t.dispose();
  }
}
