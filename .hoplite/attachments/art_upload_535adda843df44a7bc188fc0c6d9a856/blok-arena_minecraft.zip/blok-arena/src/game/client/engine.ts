import * as THREE from "three";
import {
  ARENA_RADIUS,
  BUFF_IDS,
  BUILD_REACH,
  EYE_HEIGHT,
  HIT_COOLDOWN_MS,
  HIT_REACH,
  MAX_HEIGHT,
  PLAYER_HALF_WIDTH as HW,
  PLAYER_HEIGHT as PH,
  SPAWN_RADIUS,
  Voxels,
  WS_PATH,
  buffModifiers,
  cellInRing,
  ringRadiusAt,
} from "../shared";
import type { BagInfo, BuffId, ClientMsg, ServerMsg } from "../shared";
import { Avatar, createSword } from "./avatar";
import { DamageNumbers, Particles } from "./effects";
import { applyFloorAo, buildBlockGeometry, buildFloor } from "./meshing";
import { sfx } from "./sound";
import type { Spatial } from "./sound";
import type { SpecMode, Store, UiState } from "./store";
import { createTextures, gridTexture, labelTexture, ringTexture, setLabelFont, setPixelFont } from "./textures";

const WALK_SPEED = 5;
const JUMP_SPEED = 9.2;
const GRAVITY = 30;
const MOUSE_SENS = 0.0023;
const SEND_INTERVAL = 50;
const BREAK_REPEAT_MS = 220;
const PLACE_REPEAT_MS = 200;
const DEATH_CAM_MS = 1600;
/** The reel stops a little before the buff lands so the result is readable. */
const ROULETTE_LEAD_MS = 350;
const BASE_FOV = 75;
const SKY = new THREE.Color("#8fc8ff");
const FOG = new THREE.Color("#c3cbd4");
const BLOOD = ["#ef4444", "#b91c1c"];
const STARS = ["#fff7ae", "#ffde59", "#ffffff"];
const POOF = ["#ffffff", "#e5e5e5", "#d4d4d4"];

type Mode = "orbit" | "frozen" | "play" | "spectate";

interface VoxelHit {
  x: number;
  y: number;
  z: number;
  nx: number;
  ny: number;
  nz: number;
  t: number;
  floor: boolean;
}

function serverUrl() {
  const configured = process.env.NEXT_PUBLIC_GAME_SERVER_URL;
  if (configured) return configured;
  const proto = location.protocol === "https:" ? "wss" : "ws";
  return `${proto}://${location.host}${WS_PATH}`;
}

function reelItems(target: BuffId, count = 26): BuffId[] {
  const list: BuffId[] = [];
  while (list.length < count) {
    const b = BUFF_IDS[Math.floor(Math.random() * BUFF_IDS.length)];
    if (b === list[list.length - 1] || (list.length === count - 1 && b === target)) continue;
    list.push(b);
  }
  list.push(target);
  return list;
}

export class Engine {
  private renderer: THREE.WebGLRenderer;
  private scene = new THREE.Scene();
  private camera = new THREE.PerspectiveCamera(BASE_FOV, 1, 0.05, 400);
  private world = new Voxels();
  private tex = createTextures();
  private floor = buildFloor();
  private floorMat: THREE.MeshLambertMaterial;
  private blockMesh: THREE.Mesh;
  private blocksDirty = false;
  private floorAoDirty: "all" | [number, number][] = [];
  private ring: THREE.Mesh;
  private ringMat: THREE.MeshBasicMaterial;
  private ceilingMat: THREE.MeshBasicMaterial;
  private highlight: THREE.LineSegments;
  private viewmodel: THREE.Group;
  private clouds: THREE.InstancedMesh;
  private particles = new Particles();
  private numbers = new DamageNumbers();
  private avatars = new Map<number, Avatar>();
  private dying: Avatar[] = [];
  private bags = new Map<number, { info: BagInfo; group: THREE.Group }>();
  private ws: WebSocket | null = null;
  private name = "";
  private keys = new Set<string>();
  private mouse = { left: false, right: false };
  private resize: ResizeObserver;
  private raf = 0;
  private last = performance.now();
  private disposed = false;
  private feedKey = 0;
  private uiKey = 0;
  private lastCue = "";

  // local player
  private pos = new THREE.Vector3(0, 0, SPAWN_RADIUS);
  private vel = new THREE.Vector3();
  private yaw = 0;
  private pitch = 0;
  private onGround = false;
  private jumpsLeft = 0;
  private jumpHeld = false;
  private lastSend = 0;
  private lastHitAt = 0;
  private lastBreakAt = 0;
  private lastPlaceAt = 0;
  private swingAt = -1e9;
  private walkPhase = 0;

  // hit feedback
  private trauma = 0;
  private fovKick = 0;
  private hitStopUntil = 0;
  private deathAt = -1e9;
  private deathPos = new THREE.Vector3();
  private deathYaw = 0;
  private deathPitch = 0;

  // spectator / orbit camera
  private specMode: SpecMode = "third";
  private specTarget: number | null = null;
  private specPos = new THREE.Vector3(0, 24, 60);
  private specYaw = 0;
  private specPitch = -0.35;
  private orbitAngle = 0;
  private prevMode: Mode = "orbit";

  constructor(
    private container: HTMLElement,
    private store: Store<UiState>,
  ) {
    const style = getComputedStyle(container);
    setLabelFont(style.fontFamily);
    setPixelFont(style.getPropertyValue("--font-pixel"));
    this.store.set({ muted: sfx.muted });

    this.renderer = new THREE.WebGLRenderer({ antialias: true });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFShadowMap;
    container.appendChild(this.renderer.domElement);
    this.renderer.domElement.style.display = "block";
    this.camera.rotation.order = "YXZ";
    this.scene.add(this.camera);

    this.scene.background = SKY.clone();
    this.scene.fog = new THREE.Fog(SKY.clone(), 70, 190);
    this.scene.add(new THREE.HemisphereLight(0xffffff, 0x7a6a50, 1.35));
    const sun = new THREE.DirectionalLight(0xfff4e0, 1.9);
    sun.position.set(30, 70, 20);
    sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048);
    const sc = sun.shadow.camera;
    sc.left = -54;
    sc.right = 54;
    sc.top = 54;
    sc.bottom = -54;
    sc.near = 1;
    sc.far = 160;
    sc.updateProjectionMatrix();
    sun.shadow.bias = -0.0005;
    sun.shadow.normalBias = 0.03;
    this.scene.add(sun, sun.target);

    this.floorMat = new THREE.MeshLambertMaterial({ map: this.tex.grassTop, vertexColors: true });
    const top = new THREE.Mesh(this.floor.top, this.floorMat);
    const ringFloor = new THREE.Mesh(this.floor.ring, new THREE.MeshLambertMaterial({ map: this.tex.stone, vertexColors: true }));
    top.receiveShadow = ringFloor.receiveShadow = true;
    this.scene.add(
      top,
      ringFloor,
      new THREE.Mesh(this.floor.side, new THREE.MeshLambertMaterial({ map: this.tex.grassSide })),
      new THREE.Mesh(this.floor.dirt, new THREE.MeshLambertMaterial({ map: this.tex.dirt })),
    );

    this.blockMesh = new THREE.Mesh(new THREE.BufferGeometry(), new THREE.MeshLambertMaterial({ map: this.tex.block, vertexColors: true }));
    this.blockMesh.castShadow = this.blockMesh.receiveShadow = true;
    this.scene.add(this.blockMesh);

    const rt = ringTexture();
    rt.repeat.set(96, 1);
    this.ringMat = new THREE.MeshBasicMaterial({ map: rt, color: "#9fe8ff", transparent: true, side: THREE.DoubleSide, depthWrite: false, fog: false });
    this.ring = new THREE.Mesh(new THREE.CylinderGeometry(1, 1, MAX_HEIGHT + 1, 128, 1, true), this.ringMat);
    this.ring.position.y = MAX_HEIGHT / 2 - 0.5;
    this.scene.add(this.ring);

    const gt = gridTexture();
    gt.repeat.set(ARENA_RADIUS * 2, ARENA_RADIUS * 2);
    this.ceilingMat = new THREE.MeshBasicMaterial({ map: gt, transparent: true, opacity: 0, side: THREE.DoubleSide, depthWrite: false });
    const ceiling = new THREE.Mesh(new THREE.CircleGeometry(ARENA_RADIUS, 96), this.ceilingMat);
    ceiling.rotation.x = Math.PI / 2;
    ceiling.position.y = MAX_HEIGHT;
    this.scene.add(ceiling);

    this.highlight = new THREE.LineSegments(
      new THREE.EdgesGeometry(new THREE.BoxGeometry(1.004, 1.004, 1.004)),
      new THREE.LineBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.55 }),
    );
    this.highlight.visible = false;
    this.scene.add(this.highlight);

    this.viewmodel = createSword(false);
    this.viewmodel.position.set(0.42, -0.42, -0.72);
    this.camera.add(this.viewmodel);

    this.clouds = new THREE.InstancedMesh(
      new THREE.BoxGeometry(1, 1, 1),
      new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.85, fog: false }),
      26,
    );
    const d = new THREE.Object3D();
    for (let i = 0; i < 26; i++) {
      d.position.set((Math.random() - 0.5) * 260, 48 + Math.random() * 10, (Math.random() - 0.5) * 260);
      d.scale.set(10 + Math.random() * 24, 2, 8 + Math.random() * 16);
      d.updateMatrix();
      this.clouds.setMatrixAt(i, d.matrix);
    }
    this.scene.add(this.clouds, this.particles.mesh, this.numbers.group);

    this.resize = new ResizeObserver(() => this.onResize());
    this.resize.observe(container);
    this.onResize();

    const el = this.renderer.domElement;
    el.addEventListener("mousedown", this.onMouseDown);
    el.addEventListener("contextmenu", this.preventDefault);
    el.addEventListener("wheel", this.onWheel, { passive: true });
    window.addEventListener("mouseup", this.onMouseUp);
    window.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("keyup", this.onKeyUp);
    window.addEventListener("blur", this.onBlur);
    document.addEventListener("mousemove", this.onMouseMove);
    document.addEventListener("pointerlockchange", this.onLockChange);

    this.raf = requestAnimationFrame(this.frame);
  }

  // ------------------------------------------------------------------ public API

  join(name: string) {
    sfx.unlock();
    this.name = name;
    this.connect();
  }

  reconnect() {
    sfx.unlock();
    if (this.name) this.connect();
  }

  vote(on: boolean) {
    this.send({ t: "vote", on });
  }

  toggleMute() {
    sfx.unlock();
    sfx.setMuted(!sfx.muted);
    this.store.set({ muted: sfx.muted });
  }

  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    this.resize.disconnect();
    const el = this.renderer.domElement;
    el.removeEventListener("mousedown", this.onMouseDown);
    el.removeEventListener("contextmenu", this.preventDefault);
    el.removeEventListener("wheel", this.onWheel);
    window.removeEventListener("mouseup", this.onMouseUp);
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    window.removeEventListener("blur", this.onBlur);
    document.removeEventListener("mousemove", this.onMouseMove);
    document.removeEventListener("pointerlockchange", this.onLockChange);
    if (document.pointerLockElement === el) document.exitPointerLock();
    this.ws?.close();
    this.ws = null;
    for (const a of this.avatars.values()) a.dispose();
    for (const a of this.dying) a.dispose();
    this.numbers.dispose();
    this.scene.traverse((o) => {
      if (o instanceof THREE.Mesh || o instanceof THREE.LineSegments) {
        o.geometry.dispose();
        const mats = Array.isArray(o.material) ? o.material : [o.material];
        mats.forEach((m: THREE.Material & { map?: THREE.Texture | null }) => {
          m.map?.dispose();
          m.dispose();
        });
      }
    });
    this.renderer.dispose();
    el.remove();
  }

  // ------------------------------------------------------------------ networking

  private connect() {
    this.ws?.close();
    this.store.set({ conn: "connecting" });
    let ws: WebSocket;
    try {
      ws = new WebSocket(serverUrl());
    } catch {
      this.store.set({ conn: "closed" });
      return;
    }
    this.ws = ws;
    ws.onopen = () => {
      this.store.set({ conn: "open" });
      ws.send(JSON.stringify({ t: "hello", name: this.name } satisfies ClientMsg));
    };
    ws.onmessage = (e) => {
      if (this.ws === ws) this.onMessage(JSON.parse(e.data) as ServerMsg);
    };
    ws.onclose = () => {
      if (this.ws !== ws || this.disposed) return;
      this.ws = null;
      this.store.set({ conn: "closed", myId: null, alive: false });
      for (const a of this.avatars.values()) this.removeAvatar(a.id);
      if (document.pointerLockElement) document.exitPointerLock();
    };
  }

  private send(msg: ClientMsg) {
    if (this.ws?.readyState === WebSocket.OPEN) this.ws.send(JSON.stringify(msg));
  }

  /** Volume falls off with distance; pan follows the camera's left/right. */
  private spatial(p: THREE.Vector3): Spatial {
    const cam = this.camera.position;
    const dx = p.x - cam.x;
    const dz = p.z - cam.z;
    const dist = Math.hypot(dx, p.y - cam.y, dz);
    const right = new THREE.Vector3(1, 0, 0).applyQuaternion(this.camera.quaternion);
    const pan = dist > 0.5 ? (dx * right.x + dz * right.z) / dist : 0;
    return { vol: 1 / (1 + dist * 0.12), pan: pan * 0.8 };
  }

  private onMessage(m: ServerMsg) {
    const now = performance.now();
    switch (m.t) {
      case "welcome":
        this.store.set({ myId: m.id });
        break;
      case "roster": {
        this.store.set({ players: m.players });
        const known = new Set(m.players.filter((p) => p.alive).map((p) => p.id));
        for (const id of this.avatars.keys()) if (!known.has(id)) this.removeAvatar(id);
        break;
      }
      case "phase": {
        const prev = this.store.get().phase;
        this.store.set({
          phase: m.phase,
          phaseStartedAt: now - m.elapsed,
          timings: m.timings,
          buff: m.buff,
          winnerId: m.winner,
          winnerName: m.winnerName,
          randomWin: m.randomWin,
          ...(m.phase === "countdown" ? { feed: [], announce: null, death: null } : {}),
          ...(m.phase !== "playing" ? { roulette: null } : {}),
        });
        this.applyBuffVisuals(m.phase === "playing" ? m.buff : null);
        if (m.phase === "ended" && prev !== "ended") sfx.roundEnd(m.winner !== null && m.winner === this.store.get().myId);
        if ((m.phase === "lobby" || m.phase === "ended") && prev !== m.phase && document.pointerLockElement) {
          document.exitPointerLock();
        }
        break;
      }
      case "roulette": {
        const duration = Math.max(1000, m.ms - ROULETTE_LEAD_MS);
        this.store.set({ roulette: { key: ++this.uiKey, items: reelItems(m.buff), endsAt: now + duration, duration } });
        break;
      }
      case "buff":
        this.store.set({ buff: m.buff, roulette: null, announce: { buff: m.buff, key: ++this.uiKey, at: now } });
        this.applyBuffVisuals(m.buff);
        sfx.horn();
        break;
      case "world":
        this.world.clear();
        for (let i = 0; i < m.blocks.length; i += 3) this.world.set(m.blocks[i], m.blocks[i + 1], m.blocks[i + 2], 1);
        this.floorAoDirty = "all";
        this.blocksDirty = true;
        break;
      case "block": {
        this.world.set(m.x, m.y, m.z, m.v);
        if (m.y === 0 && this.floorAoDirty !== "all") this.floorAoDirty.push([m.x, m.z]);
        this.blocksDirty = true;
        const at = new THREE.Vector3(m.x + 0.5, m.y + 0.5, m.z + 0.5);
        if (m.v) {
          sfx.place(this.spatial(at));
        } else {
          this.particles.burst(at, ["#79553a", "#966c4a", "#5d4128"], 14, 5);
          sfx.breakBlock(this.spatial(at));
        }
        break;
      }
      case "tick":
        this.onTick(m.p);
        break;
      case "you": {
        const s = this.store.get();
        if (s.alive && !m.alive) {
          this.specPos.copy(this.camera.position);
          this.specYaw = this.yaw;
          this.specPitch = this.pitch;
        }
        if (s.alive && m.alive && m.dirt >= s.dirt + 2) sfx.pickup();
        this.store.set({ hp: m.hp, dirt: m.dirt, alive: m.alive, role: m.role });
        break;
      }
      case "tp":
        this.pos.set(m.x, m.y, m.z);
        this.vel.set(0, 0, 0);
        this.yaw = m.yaw;
        this.pitch = 0;
        break;
      case "hurt":
        this.onHurt(m, now);
        break;
      case "kill":
        this.onKill(m, now);
        break;
      case "bags":
        this.syncBags(m.bags);
        break;
    }
  }

  private onHurt(m: Extract<ServerMsg, { t: "hurt" }>, now: number) {
    const s = this.store.get();
    const mine = m.by !== 0 && m.by === s.myId;
    const toMe = m.id === s.myId;
    const victim = this.avatars.get(m.id);
    if (toMe) {
      this.vel.x += m.kx;
      this.vel.z += m.kz;
      if (m.ky) this.vel.y = Math.max(this.vel.y, m.ky);
      this.trauma = Math.min(1, this.trauma + (m.by ? 0.55 : 0.25));
      this.store.set({ hurtKey: s.hurtKey + 1 });
      sfx.hurt();
    }
    victim?.hurt(now);
    if (m.by && !mine) this.avatars.get(m.by)?.swing(now);
    const at = victim ? victim.pos.clone() : toMe ? this.pos.clone() : null;
    if (!at) return;
    at.y += 1.2;
    this.particles.burst(at, BLOOD, m.by ? 8 : 4, 4);
    if (m.crit) this.particles.burst(at, STARS, 18, 6, 0.12);
    if (victim) {
      const color = !m.by ? "#ff9f1c" : mine ? (m.crit ? "#ff8c1a" : "#ffde59") : m.crit ? "#ffc266" : "#ffffff";
      this.numbers.spawn(victim.pos.clone().setY(victim.pos.y + 2.45), `-${m.dmg}${m.crit ? "!" : ""}`, color, mine || m.crit, now);
    }
    if (mine) {
      // Hit-stop: freeze the world for a few frames so the hit lands with weight.
      this.hitStopUntil = now + (m.crit ? 120 : 70);
      this.trauma = Math.min(1, this.trauma + (m.crit ? 0.4 : 0.22));
      if (m.crit) this.fovKick = 7;
      sfx.hit(m.crit);
    } else if (!toMe && m.by) {
      sfx.hit(m.crit, this.spatial(at));
    }
  }

  private onKill(m: Extract<ServerMsg, { t: "kill" }>, now: number) {
    const s = this.store.get();
    const find = (id: number | null) => (id === null ? null : s.players.find((p) => p.id === id));
    const victim = find(m.victim);
    const killer = find(m.killer);
    const a = this.avatars.get(m.victim);
    if (a) {
      this.avatars.delete(m.victim);
      a.die(now);
      this.dying.push(a);
      this.particles.burst(a.pos.clone().setY(a.pos.y + 1), BLOOD, 16, 6);
      sfx.death(this.spatial(a.pos));
    }
    if (m.victim === s.myId) {
      this.deathAt = now;
      this.deathPos.copy(this.pos);
      this.deathYaw = this.yaw;
      this.deathPitch = this.pitch;
      sfx.death();
      this.store.set({ death: { key: ++this.uiKey, killer: killer?.name ?? null, color: killer?.color ?? null, at: now } });
    }
    if (m.killer !== null && m.killer === s.myId) sfx.kill();
    if (victim) {
      this.store.set((st) => ({
        feed: [
          ...st.feed.slice(-4),
          {
            key: ++this.feedKey,
            at: now,
            victim: { name: victim.name, color: victim.color },
            killer: killer ? { name: killer.name, color: killer.color } : null,
            reason: m.reason,
          },
        ],
      }));
    }
  }

  private onTick(p: number[]) {
    const s = this.store.get();
    const seen = new Set<number>();
    for (let i = 0; i < p.length; i += 7) {
      const id = p[i];
      if (id === s.myId) continue;
      seen.add(id);
      let a = this.avatars.get(id);
      if (!a) {
        const info = s.players.find((pl) => pl.id === id);
        if (!info) continue;
        a = new Avatar(id, info.name, info.color);
        this.avatars.set(id, a);
        this.scene.add(a.group);
      }
      a.setTarget(p[i + 1], p[i + 2], p[i + 3], p[i + 4], p[i + 5]);
      a.setHp(p[i + 6]);
    }
    for (const id of this.avatars.keys()) if (!seen.has(id)) this.removeAvatar(id);
  }

  private removeAvatar(id: number) {
    const a = this.avatars.get(id);
    if (!a) return;
    this.scene.remove(a.group);
    a.dispose();
    this.avatars.delete(id);
  }

  private syncBags(list: BagInfo[]) {
    const ids = new Set(list.map((b) => b.id));
    for (const [id, b] of this.bags) {
      if (ids.has(id)) continue;
      this.particles.burst(b.group.position.clone(), ["#facc15", "#a16207"], 10, 4);
      this.scene.remove(b.group);
      b.group.traverse((o) => {
        if (o instanceof THREE.Mesh || o instanceof THREE.Sprite) {
          o.geometry.dispose();
          (o.material as THREE.MeshBasicMaterial).map?.dispose();
          (o.material as THREE.Material).dispose();
        }
      });
      this.bags.delete(id);
    }
    for (const info of list) {
      if (this.bags.has(info.id)) continue;
      const group = new THREE.Group();
      const chest = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.45, 0.4), new THREE.MeshLambertMaterial({ color: "#8b5a2b" }));
      const band = new THREE.Mesh(new THREE.BoxGeometry(0.57, 0.08, 0.42), new THREE.MeshLambertMaterial({ color: "#facc15", emissive: "#5a4500" }));
      band.position.y = 0.06;
      chest.castShadow = true;
      const label = new THREE.Sprite(new THREE.SpriteMaterial({ map: labelTexture(`+${info.dirt} земли`, "#facc15", null) }));
      label.scale.set(1.4, 0.4, 1);
      label.position.y = 0.75;
      group.add(chest, band, label);
      group.position.set(info.x, info.y + 0.4, info.z);
      group.userData.baseY = info.y + 0.4;
      this.scene.add(group);
      this.bags.set(info.id, { info, group });
    }
  }

  private rebuildBlocks() {
    this.blocksDirty = false;
    this.blockMesh.geometry.dispose();
    this.blockMesh.geometry = buildBlockGeometry(this.world);
    const cells = this.floorAoDirty;
    if (cells === "all" || cells.length) applyFloorAo(this.floor, this.world, cells === "all" ? null : cells);
    this.floorAoDirty = [];
  }

  private applyBuffVisuals(buff: BuffId | null) {
    const mods = buffModifiers(buff);
    const fog = this.scene.fog as THREE.Fog;
    if (mods.fog) {
      fog.color.copy(FOG);
      fog.near = 1;
      fog.far = 11;
      (this.scene.background as THREE.Color).copy(FOG);
    } else {
      fog.color.copy(SKY);
      fog.near = 70;
      fog.far = 190;
      (this.scene.background as THREE.Color).copy(SKY);
    }
    this.floorMat.map = mods.lava ? this.tex.lava : this.tex.grassTop;
    this.floorMat.emissive.set(mods.lava ? "#c2410c" : "#000000");
    this.floorMat.needsUpdate = true;
  }

  // ------------------------------------------------------------------ input

  private get mode(): Mode {
    const s = this.store.get();
    if (s.conn !== "open" || s.myId === null || s.phase === "lobby" || s.phase === "ended") return "orbit";
    if (s.alive) return s.phase === "countdown" ? "frozen" : "play";
    return "spectate";
  }

  private preventDefault = (e: Event) => e.preventDefault();

  private onResize() {
    const w = this.container.clientWidth || 1;
    const h = this.container.clientHeight || 1;
    this.renderer.setSize(w, h);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  }

  private isTyping(e: Event) {
    const t = e.target as HTMLElement | null;
    return !!t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.isContentEditable);
  }

  private onKeyDown = (e: KeyboardEvent) => {
    if (this.isTyping(e)) return;
    if (e.code === "KeyM" && !e.repeat) this.toggleMute();
    const mode = this.mode;
    if (mode === "orbit") return;
    if (["Space", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", "Tab"].includes(e.code)) e.preventDefault();
    this.keys.add(e.code);
    if (mode === "spectate" && !e.repeat) {
      if (e.code === "KeyV") {
        const order: SpecMode[] = ["third", "first", "free"];
        this.specMode = order[(order.indexOf(this.specMode) + 1) % order.length];
        if (this.specMode === "free") this.specPos.copy(this.camera.position);
      }
      if (e.code === "KeyE" || e.code === "ArrowRight") this.cycleTarget(1);
      if (e.code === "KeyQ" || e.code === "ArrowLeft") this.cycleTarget(-1);
    }
  };

  private onKeyUp = (e: KeyboardEvent) => {
    this.keys.delete(e.code);
  };

  private onBlur = () => {
    this.keys.clear();
    this.mouse.left = this.mouse.right = false;
  };

  private onMouseDown = (e: MouseEvent) => {
    sfx.unlock();
    const mode = this.mode;
    if (mode === "orbit") return;
    const el = this.renderer.domElement;
    if (document.pointerLockElement !== el) {
      Promise.resolve(el.requestPointerLock()).catch(() => {});
      return;
    }
    if (mode === "spectate") {
      if (e.button === 0) this.cycleTarget(1);
      if (e.button === 2) this.cycleTarget(-1);
      return;
    }
    if (e.button === 0) {
      this.mouse.left = true;
      this.primaryAction(true);
    }
    if (e.button === 2) {
      this.mouse.right = true;
      this.secondaryAction(true);
    }
  };

  private onMouseUp = (e: MouseEvent) => {
    if (e.button === 0) this.mouse.left = false;
    if (e.button === 2) this.mouse.right = false;
  };

  private onWheel = (e: WheelEvent) => {
    if (this.mode === "spectate") this.cycleTarget(e.deltaY > 0 ? 1 : -1);
  };

  private onMouseMove = (e: MouseEvent) => {
    if (document.pointerLockElement !== this.renderer.domElement) return;
    const lim = Math.PI / 2 - 0.01;
    if (this.mode === "spectate") {
      this.specYaw -= e.movementX * MOUSE_SENS;
      this.specPitch = Math.max(-lim, Math.min(lim, this.specPitch - e.movementY * MOUSE_SENS));
    } else {
      this.yaw -= e.movementX * MOUSE_SENS;
      this.pitch = Math.max(-lim, Math.min(lim, this.pitch - e.movementY * MOUSE_SENS));
    }
  };

  private onLockChange = () => {
    const locked = document.pointerLockElement === this.renderer.domElement;
    this.store.set({ locked });
    if (!locked) this.mouse.left = this.mouse.right = false;
  };

  private cycleTarget(dir: number) {
    const ids = [...this.avatars.keys()].sort((a, b) => a - b);
    if (!ids.length) return;
    if (this.specMode === "free") this.specMode = "third";
    const i = this.specTarget === null ? -1 : ids.indexOf(this.specTarget);
    this.specTarget = ids[(i + dir + ids.length) % ids.length];
  }

  // ------------------------------------------------------------------ actions

  private eyeRay() {
    const origin = new THREE.Vector3(this.pos.x, this.pos.y + EYE_HEIGHT, this.pos.z);
    const dir = new THREE.Vector3(0, 0, -1).applyEuler(new THREE.Euler(this.pitch, this.yaw, 0, "YXZ"));
    return { origin, dir };
  }

  private primaryAction(fresh: boolean) {
    if (this.mode !== "play") return;
    const now = performance.now();
    const { origin, dir } = this.eyeRay();
    const player = this.pickPlayer(origin, dir, HIT_REACH);
    const block = this.raycast(origin, dir, BUILD_REACH);
    if (player && (!block || player.t < block.t)) {
      if (now - this.lastHitAt < HIT_COOLDOWN_MS) return;
      this.lastHitAt = now;
      this.swingAt = now;
      sfx.swing();
      this.send({ t: "hit", id: player.id });
      return;
    }
    if (block && !block.floor) {
      if (now - this.lastBreakAt < (fresh ? 120 : BREAK_REPEAT_MS)) return;
      this.lastBreakAt = now;
      this.swingAt = now;
      this.send({ t: "break", x: block.x, y: block.y, z: block.z });
      return;
    }
    if (fresh && now - this.swingAt > 250) {
      this.swingAt = now;
      sfx.swing();
    }
  }

  private secondaryAction(fresh: boolean) {
    if (this.mode !== "play") return;
    const now = performance.now();
    if (now - this.lastPlaceAt < (fresh ? 80 : PLACE_REPEAT_MS)) return;
    const s = this.store.get();
    if (s.dirt <= 0) return;
    const { origin, dir } = this.eyeRay();
    const hit = this.raycast(origin, dir, BUILD_REACH);
    if (!hit) return;
    const x = hit.x + hit.nx;
    const y = hit.y + hit.ny;
    const z = hit.z + hit.nz;
    if (!Voxels.inBounds(x, y, z) || this.world.get(x, y, z) || !cellInRing(x, z, this.ringRadius())) return;
    const p = this.pos;
    if (p.x + HW > x && p.x - HW < x + 1 && p.z + HW > z && p.z - HW < z + 1 && p.y + PH > y && p.y < y + 1) return;
    this.lastPlaceAt = now;
    this.send({ t: "place", x, y, z });
  }

  private pickPlayer(origin: THREE.Vector3, dir: THREE.Vector3, reach: number) {
    let best: { id: number; t: number } | null = null;
    const pad = 0.1;
    for (const a of this.avatars.values()) {
      const min = [a.pos.x - HW - pad, a.pos.y - pad, a.pos.z - HW - pad];
      const max = [a.pos.x + HW + pad, a.pos.y + PH + pad, a.pos.z + HW + pad];
      const o = [origin.x, origin.y, origin.z];
      const d = [dir.x, dir.y, dir.z];
      let t0 = 0;
      let t1 = reach;
      let ok = true;
      for (let k = 0; k < 3 && ok; k++) {
        if (Math.abs(d[k]) < 1e-9) {
          if (o[k] < min[k] || o[k] > max[k]) ok = false;
          continue;
        }
        let ta = (min[k] - o[k]) / d[k];
        let tb = (max[k] - o[k]) / d[k];
        if (ta > tb) [ta, tb] = [tb, ta];
        t0 = Math.max(t0, ta);
        t1 = Math.min(t1, tb);
        if (t0 > t1) ok = false;
      }
      if (ok && (!best || t0 < best.t)) best = { id: a.id, t: t0 };
    }
    return best;
  }

  /** Amanatides–Woo voxel traversal; the floor counts as a hit below y = 0. */
  private raycast(origin: THREE.Vector3, dir: THREE.Vector3, maxDist: number): VoxelHit | null {
    let x = Math.floor(origin.x);
    let y = Math.floor(origin.y);
    let z = Math.floor(origin.z);
    const sx = Math.sign(dir.x);
    const sy = Math.sign(dir.y);
    const sz = Math.sign(dir.z);
    const dx = sx ? Math.abs(1 / dir.x) : Infinity;
    const dy = sy ? Math.abs(1 / dir.y) : Infinity;
    const dz = sz ? Math.abs(1 / dir.z) : Infinity;
    let tx = sx > 0 ? (x + 1 - origin.x) * dx : sx < 0 ? (origin.x - x) * dx : Infinity;
    let ty = sy > 0 ? (y + 1 - origin.y) * dy : sy < 0 ? (origin.y - y) * dy : Infinity;
    let tz = sz > 0 ? (z + 1 - origin.z) * dz : sz < 0 ? (origin.z - z) * dz : Infinity;
    let nx = 0;
    let ny = 0;
    let nz = 0;
    let t = 0;
    for (let i = 0; i < 128; i++) {
      if (tx < ty && tx < tz) {
        x += sx;
        t = tx;
        tx += dx;
        nx = -sx;
        ny = nz = 0;
      } else if (ty < tz) {
        y += sy;
        t = ty;
        ty += dy;
        ny = -sy;
        nx = nz = 0;
      } else {
        z += sz;
        t = tz;
        tz += dz;
        nz = -sz;
        nx = ny = 0;
      }
      if (t > maxDist) return null;
      if (y < 0) return cellInRing(x, z, ARENA_RADIUS) ? { x, y, z, nx, ny, nz, t, floor: true } : null;
      if (y < MAX_HEIGHT && this.world.get(x, y, z)) return { x, y, z, nx, ny, nz, t, floor: false };
    }
    return null;
  }

  // ------------------------------------------------------------------ simulation

  private ringRadius() {
    const s = this.store.get();
    return s.phase === "playing" ? ringRadiusAt(performance.now() - s.phaseStartedAt, s.timings) : ARENA_RADIUS;
  }

  /** Moves along one axis, testing only the cells the leading face enters (blocks overlapping
   *  the player — e.g. placed at their feet — therefore never teleport them). */
  private moveAxis(axis: 0 | 1 | 2, d: number) {
    if (!d) return;
    const p = this.pos;
    const eps = 1e-6;
    const lo = [p.x - HW, p.y, p.z - HW];
    const hi = [p.x + HW, p.y + PH, p.z + HW];
    const oldEdge = d > 0 ? hi[axis] : lo[axis];
    lo[axis] += d;
    hi[axis] += d;
    const newEdge = d > 0 ? hi[axis] : lo[axis];
    const range = (k: number): [number, number] => {
      if (k !== axis) return [Math.floor(lo[k]), Math.floor(hi[k] - eps)];
      return d > 0 ? [Math.floor(oldEdge - eps) + 1, Math.floor(newEdge - eps)] : [Math.floor(newEdge), Math.floor(oldEdge) - 1];
    };
    const [x0, x1] = range(0);
    const [y0, y1] = range(1);
    const [z0, z1] = range(2);
    let bound = d > 0 ? Infinity : -Infinity;
    for (let x = x0; x <= x1; x++)
      for (let y = y0; y <= y1; y++)
        for (let z = z0; z <= z1; z++) {
          if (!this.world.solid(x, y, z)) continue;
          const c = axis === 0 ? x : axis === 1 ? y : z;
          bound = d > 0 ? Math.min(bound, c) : Math.max(bound, c);
        }
    let v = (axis === 0 ? p.x : axis === 1 ? p.y : p.z) + d;
    if (Number.isFinite(bound)) {
      if (axis === 1) {
        v = d > 0 ? bound - PH - 1e-4 : bound + 1;
        if (d < 0) this.onGround = true;
        this.vel.y = 0;
      } else {
        v = d > 0 ? bound - HW - 1e-4 : bound + 1 + HW + 1e-4;
        if (axis === 0) this.vel.x = 0;
        else this.vel.z = 0;
      }
    }
    if (axis === 0) p.x = v;
    else if (axis === 1) p.y = v;
    else p.z = v;
  }

  private updatePlay(dt: number, now: number) {
    const s = this.store.get();
    const mods = buffModifiers(s.buff);
    const k = this.keys;
    const f = (k.has("KeyW") || k.has("ArrowUp") ? 1 : 0) - (k.has("KeyS") || k.has("ArrowDown") ? 1 : 0);
    const r = (k.has("KeyD") || k.has("ArrowRight") ? 1 : 0) - (k.has("KeyA") || k.has("ArrowLeft") ? 1 : 0);
    const sin = Math.sin(this.yaw);
    const cos = Math.cos(this.yaw);
    let wx = -sin * f + cos * r;
    let wz = -cos * f - sin * r;
    const len = Math.hypot(wx, wz);
    const speed = WALK_SPEED * mods.speed;
    if (len) {
      wx = (wx / len) * speed;
      wz = (wz / len) * speed;
    }
    const accel = 1 - Math.exp(-(this.onGround ? 14 : 2.5) * dt);
    this.vel.x += (wx - this.vel.x) * accel;
    this.vel.z += (wz - this.vel.z) * accel;

    const jump = k.has("Space");
    if (jump && this.onGround) {
      this.vel.y = JUMP_SPEED;
      this.jumpsLeft = mods.extraJumps;
      this.jumpHeld = true;
    } else if (jump && !this.jumpHeld && this.jumpsLeft > 0) {
      this.vel.y = JUMP_SPEED;
      this.jumpsLeft--;
      this.jumpHeld = true;
    }
    if (!jump) this.jumpHeld = false;
    this.vel.y = Math.max(-45, this.vel.y - GRAVITY * mods.gravity * dt);

    const vyBefore = this.vel.y;
    const wasOnGround = this.onGround;
    const steps = Math.max(1, Math.ceil((Math.max(Math.abs(this.vel.x), Math.abs(this.vel.y), Math.abs(this.vel.z)) * dt) / 0.45));
    this.onGround = false;
    for (let i = 0; i < steps; i++) {
      this.moveAxis(1, (this.vel.y * dt) / steps);
      this.moveAxis(0, (this.vel.x * dt) / steps);
      this.moveAxis(2, (this.vel.z * dt) / steps);
    }
    if (this.onGround && !wasOnGround && vyBefore < -8) sfx.land(-vyBefore);

    const limit = this.ringRadius() - HW;
    const dist = Math.hypot(this.pos.x, this.pos.z);
    if (dist > limit) {
      this.pos.x *= limit / dist;
      this.pos.z *= limit / dist;
    }

    if (this.mouse.left) this.primaryAction(false);
    if (this.mouse.right) this.secondaryAction(false);

    const hs = Math.hypot(this.vel.x, this.vel.z);
    if (this.onGround && hs > 0.8) {
      const before = Math.floor(this.walkPhase / Math.PI);
      this.walkPhase += hs * dt * 1.6;
      if (Math.floor(this.walkPhase / Math.PI) !== before) sfx.step();
    }
    if (now - this.lastSend >= SEND_INTERVAL) {
      this.lastSend = now;
      this.send({ t: "move", x: this.pos.x, y: this.pos.y, z: this.pos.z, yaw: this.yaw, pitch: this.pitch });
    }
  }

  private updateSpectate(dt: number) {
    // Stay on a spectated player while their death animation plays, then move on.
    const dyingTarget = this.dying.find((a) => a.id === this.specTarget);
    const targets = [...this.avatars.keys()];
    if (this.specMode !== "free" && !dyingTarget && (this.specTarget === null || !this.avatars.has(this.specTarget))) {
      this.specTarget = targets.sort((a, b) => a - b)[0] ?? null;
    }
    const target = dyingTarget ?? (this.specTarget !== null ? this.avatars.get(this.specTarget) : undefined);
    const mode: SpecMode = !target ? "free" : dyingTarget && this.specMode === "first" ? "third" : this.specMode;
    for (const a of this.avatars.values()) a.group.visible = !(mode === "first" && a === target);

    if (mode === "free" || !target) {
      const k = this.keys;
      const dir = new THREE.Vector3(0, 0, -1).applyEuler(new THREE.Euler(this.specPitch, this.specYaw, 0, "YXZ"));
      const right = new THREE.Vector3(Math.cos(this.specYaw), 0, -Math.sin(this.specYaw));
      const move = new THREE.Vector3();
      if (k.has("KeyW") || k.has("ArrowUp")) move.add(dir);
      if (k.has("KeyS") || k.has("ArrowDown")) move.sub(dir);
      if (k.has("KeyD")) move.add(right);
      if (k.has("KeyA")) move.sub(right);
      if (k.has("Space")) move.y += 1;
      if (k.has("ShiftLeft") || k.has("ShiftRight")) move.y -= 1;
      if (move.lengthSq()) this.specPos.addScaledVector(move.normalize(), 14 * dt);
      const r = Math.hypot(this.specPos.x, this.specPos.z);
      if (r > 80) this.specPos.multiplyScalar(80 / r);
      this.specPos.y = Math.max(-6, Math.min(45, this.specPos.y));
      this.camera.position.copy(this.specPos);
      this.camera.rotation.set(this.specPitch, this.specYaw, 0);
    } else if (mode === "first") {
      this.camera.position.copy(target.eye);
      this.camera.rotation.set(target.pitch, target.yaw, 0);
    } else {
      const eye = target.eye;
      const back = new THREE.Vector3(0, 0, -1).applyEuler(new THREE.Euler(this.specPitch, this.specYaw, 0, "YXZ"));
      this.camera.position.copy(eye).addScaledVector(back, -4.5);
      this.camera.lookAt(eye);
    }

    const prev = this.store.get().spectate;
    const name = target ? (this.store.get().players.find((p) => p.id === target.id)?.name ?? null) : null;
    if (!prev || prev.mode !== mode || prev.target !== name) this.store.set({ spectate: { mode, target: name } });
  }

  /** Own death: the camera drops to the floor and tips over before spectating starts. */
  private updateDeathCam(t: number) {
    const k = Math.min(1, (t - this.deathAt) / 700);
    const e = 1 - (1 - k) * (1 - k);
    this.camera.position.set(this.deathPos.x, this.deathPos.y + EYE_HEIGHT + (0.25 - EYE_HEIGHT) * e, this.deathPos.z);
    this.camera.rotation.set(this.deathPitch * (1 - e) - 0.25 * e, this.deathYaw, 1.25 * e);
  }

  private applyShake(dt: number, t: number, active: boolean) {
    this.trauma = Math.max(0, this.trauma - dt * 1.8);
    this.fovKick *= Math.exp(-dt * 7);
    const fov = BASE_FOV + (active ? this.fovKick : 0);
    if (Math.abs(this.camera.fov - fov) > 0.01) {
      this.camera.fov = fov;
      this.camera.updateProjectionMatrix();
    }
    if (!active || this.trauma <= 0) return;
    const k = this.trauma * this.trauma;
    const ts = t / 1000;
    this.camera.rotation.x += Math.sin(ts * 47.3) * 0.045 * k;
    this.camera.rotation.y += Math.sin(ts * 38.1 + 1.3) * 0.045 * k;
    this.camera.rotation.z += Math.sin(ts * 55.7 + 2.1) * 0.06 * k;
  }

  private updateDying(t: number) {
    this.dying = this.dying.filter((a) => {
      if (a.updateDying(t)) return true;
      const at = a.pos.clone().setY(a.pos.y + 0.4);
      this.particles.burst(at, a.palette, 36, 6, 0.17);
      this.particles.burst(at, POOF, 14, 3, 0.22);
      this.scene.remove(a.group);
      a.dispose();
      return false;
    });
  }

  /** Countdown beeps, the "go" signal and ticking over the last 10 seconds. */
  private updateCues(t: number) {
    const s = this.store.get();
    const elapsed = t - s.phaseStartedAt;
    let cue = "";
    if (s.conn === "open" && s.phase === "countdown") {
      cue = `c${Math.max(1, Math.ceil((s.timings.countdownMs - elapsed) / 1000))}`;
    } else if (s.conn === "open" && s.phase === "playing") {
      const left = Math.ceil((s.timings.roundMs - elapsed) / 1000);
      if (elapsed < 800) cue = "go";
      else if (left > 0 && left <= 10) cue = `t${left}`;
    }
    if (cue === this.lastCue) return;
    this.lastCue = cue;
    if (cue === "go") sfx.beep(true);
    else if (cue.startsWith("c")) sfx.beep(false);
    else if (cue.startsWith("t")) sfx.tick(Number(cue.slice(1)) <= 3);
  }

  private frame = (t: number) => {
    if (this.disposed) return;
    this.raf = requestAnimationFrame(this.frame);
    const dt = Math.min(0.05, (t - this.last) / 1000);
    this.last = t;
    const mode = this.mode;
    const s = this.store.get();
    const mods = buffModifiers(s.buff);

    if (mode !== this.prevMode) {
      if (mode === "spectate") {
        this.specMode = "third";
        this.specTarget = null;
      }
      if (mode !== "spectate") {
        for (const a of this.avatars.values()) a.group.visible = true;
        if (s.spectate) this.store.set({ spectate: null });
      }
      this.keys.clear();
      this.prevMode = mode;
    }
    this.updateCues(t);

    const stopped = t < this.hitStopUntil;
    if (stopped) this.swingAt += dt * 1000;

    if (mode === "play") this.updatePlay(dt, t);
    const deathCam = mode === "spectate" && t - this.deathAt < DEATH_CAM_MS;
    if (mode === "play" || mode === "frozen") {
      this.camera.position.set(this.pos.x, this.pos.y + EYE_HEIGHT, this.pos.z);
      this.camera.rotation.set(this.pitch, this.yaw, 0);
    } else if (deathCam) {
      this.updateDeathCam(t);
    } else if (mode === "spectate") {
      this.updateSpectate(dt);
    } else {
      this.orbitAngle += dt * 0.06;
      this.camera.position.set(Math.cos(this.orbitAngle) * 64, 24, Math.sin(this.orbitAngle) * 64);
      this.camera.lookAt(0, 2, 0);
    }
    this.applyShake(dt, t, mode === "play" || mode === "frozen" || deathCam);

    if (!stopped) for (const a of this.avatars.values()) a.update(dt, t, mods.invisible);
    this.updateDying(t);
    for (const { group } of this.bags.values()) {
      group.rotation.y += dt * 1.5;
      group.position.y = group.userData.baseY + Math.sin(t / 300) * 0.08;
    }
    this.particles.update(stopped ? 0 : dt);
    this.numbers.update(t);

    // Viewmodel sword: swing + walk bob.
    this.viewmodel.visible = mode === "play" || mode === "frozen";
    const sw = (t - this.swingAt) / 260;
    const swing = sw < 1 ? Math.sin(sw * Math.PI) : 0;
    this.viewmodel.position.set(0.42 - swing * 0.18, -0.42 + Math.sin(this.walkPhase * 2) * 0.015 + swing * 0.08, -0.72 - swing * 0.12);
    this.viewmodel.rotation.set(-0.35 - swing * 1.3, -0.25 + swing * 0.4, -0.2 - swing * 0.3);

    // Block highlight.
    this.highlight.visible = false;
    if (mode === "play") {
      const { origin, dir } = this.eyeRay();
      const hit = this.raycast(origin, dir, BUILD_REACH);
      const player = this.pickPlayer(origin, dir, HIT_REACH);
      if (hit && (!player || hit.t < player.t)) {
        this.highlight.visible = true;
        this.highlight.position.set(hit.x + 0.5, hit.y + 0.5, hit.z + 0.5);
      }
    }

    // Ring wall and ceiling.
    const ringR = this.ringRadius();
    this.ring.scale.set(ringR, 1, ringR);
    const shrinking = ringR < ARENA_RADIUS - 0.01;
    this.ringMat.color.set(shrinking ? "#ff5a5a" : "#9fe8ff");
    this.ringMat.opacity = shrinking ? 0.9 : 0.55;
    this.ceilingMat.opacity = Math.max(0, Math.min(0.35, (this.camera.position.y - 9) / 20));
    this.clouds.position.x = ((t / 1000) * 0.8) % 60;

    if (this.blocksDirty) this.rebuildBlocks();
    this.renderer.render(this.scene, this.camera);
  };
}
