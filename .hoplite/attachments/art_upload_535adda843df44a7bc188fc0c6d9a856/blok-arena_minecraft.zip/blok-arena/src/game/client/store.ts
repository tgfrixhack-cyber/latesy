import { makeTimings } from "../shared";
import type { BuffId, Phase, PlayerInfo, Role, Timings } from "../shared";

export type SpecMode = "free" | "first" | "third";

export interface FeedItem {
  key: number;
  at: number;
  killer: { name: string; color: string } | null;
  victim: { name: string; color: string };
  reason: "kill" | "leave";
}

export interface UiState {
  conn: "idle" | "connecting" | "open" | "closed";
  myId: number | null;
  phase: Phase;
  /** performance.now() at which the current phase started. */
  phaseStartedAt: number;
  timings: Timings;
  players: PlayerInfo[];
  buff: BuffId | null;
  announce: { buff: BuffId; key: number; at: number } | null;
  /** Reel of buff names; the last item is the buff that will land at `endsAt`. */
  roulette: { key: number; items: BuffId[]; endsAt: number; duration: number } | null;
  hp: number;
  dirt: number;
  alive: boolean;
  role: Role;
  winnerId: number | null;
  winnerName: string | null;
  randomWin: boolean;
  feed: FeedItem[];
  spectate: { mode: SpecMode; target: string | null } | null;
  death: { key: number; killer: string | null; color: string | null; at: number } | null;
  locked: boolean;
  muted: boolean;
  hurtKey: number;
}

export const initialUi = (): UiState => ({
  conn: "idle",
  myId: null,
  phase: "lobby",
  phaseStartedAt: 0,
  timings: makeTimings(),
  players: [],
  buff: null,
  announce: null,
  roulette: null,
  hp: 20,
  dirt: 0,
  alive: false,
  role: "spectator",
  winnerId: null,
  winnerName: null,
  randomWin: false,
  feed: [],
  spectate: null,
  death: null,
  locked: false,
  muted: false,
  hurtKey: 0,
});

export interface Store<T> {
  get(): T;
  set(patch: Partial<T> | ((s: T) => Partial<T>)): void;
  subscribe(listener: () => void): () => void;
}

export function createStore<T>(initial: T): Store<T> {
  let state = initial;
  const listeners = new Set<() => void>();
  return {
    get: () => state,
    set(patch) {
      state = { ...state, ...(typeof patch === "function" ? patch(state) : patch) };
      listeners.forEach((l) => l());
    },
    subscribe(listener) {
      listeners.add(listener);
      return () => listeners.delete(listener);
    },
  };
}
