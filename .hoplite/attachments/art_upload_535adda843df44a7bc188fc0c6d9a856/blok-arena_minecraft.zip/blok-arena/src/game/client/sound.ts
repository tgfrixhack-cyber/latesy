// Procedural WebAudio sound effects: nothing to download or license.

export interface Spatial {
  vol?: number;
  pan?: number;
}

interface ToneOpts {
  type?: OscillatorType;
  f: number;
  f2?: number;
  dur: number;
  vol?: number;
  attack?: number;
  delay?: number;
  lp?: number;
}

interface NoiseOpts {
  dur: number;
  vol?: number;
  type?: BiquadFilterType;
  f?: number;
  f2?: number;
  q?: number;
  delay?: number;
  attack?: number;
}

const MUTE_KEY = "pvp-muted";
const MASTER = 0.6;

class Sfx {
  muted = typeof localStorage !== "undefined" && localStorage.getItem(MUTE_KEY) === "1";
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private noiseBuf: AudioBuffer | null = null;

  /** Browsers only allow audio after a user gesture, so call this from input handlers. */
  unlock() {
    if (typeof window === "undefined") return;
    if (!this.ctx) {
      if (!window.AudioContext) return;
      const ctx = new AudioContext();
      this.ctx = ctx;
      this.master = ctx.createGain();
      this.master.gain.value = this.muted ? 0 : MASTER;
      this.master.connect(ctx.createDynamicsCompressor()).connect(ctx.destination);
      this.noiseBuf = ctx.createBuffer(1, ctx.sampleRate, ctx.sampleRate);
      const d = this.noiseBuf.getChannelData(0);
      for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
  }

  setMuted(muted: boolean) {
    this.muted = muted;
    localStorage.setItem(MUTE_KEY, muted ? "1" : "0");
    if (this.ctx && this.master) this.master.gain.setTargetAtTime(muted ? 0 : MASTER, this.ctx.currentTime, 0.02);
  }

  private out(s: Spatial, delay = 0) {
    const ctx = this.ctx;
    if (!ctx || !this.master || this.muted || ctx.state !== "running") return null;
    const vol = s.vol ?? 1;
    if (vol < 0.03) return null;
    let dest: AudioNode = this.master;
    if (s.pan) {
      const p = ctx.createStereoPanner();
      p.pan.value = Math.max(-1, Math.min(1, s.pan));
      p.connect(dest);
      dest = p;
    }
    const g = ctx.createGain();
    g.gain.value = vol;
    g.connect(dest);
    return { ctx, t: ctx.currentTime + delay, dest: g };
  }

  private envelope(ctx: AudioContext, t: number, vol: number, attack: number, dur: number) {
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol, t + attack);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    return g;
  }

  private tone(o: ToneOpts, s: Spatial = {}) {
    const out = this.out(s, o.delay);
    if (!out) return;
    const { ctx, t, dest } = out;
    const osc = ctx.createOscillator();
    osc.type = o.type ?? "sine";
    osc.frequency.setValueAtTime(o.f, t);
    if (o.f2) osc.frequency.exponentialRampToValueAtTime(o.f2, t + o.dur);
    const env = this.envelope(ctx, t, o.vol ?? 0.3, o.attack ?? 0.005, o.dur);
    if (o.lp) {
      const lp = ctx.createBiquadFilter();
      lp.frequency.value = o.lp;
      osc.connect(lp).connect(env);
    } else {
      osc.connect(env);
    }
    env.connect(dest);
    osc.start(t);
    osc.stop(t + o.dur + 0.05);
  }

  private noise(o: NoiseOpts, s: Spatial = {}) {
    const out = this.out(s, o.delay);
    if (!out || !this.noiseBuf) return;
    const { ctx, t, dest } = out;
    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    const filter = ctx.createBiquadFilter();
    filter.type = o.type ?? "lowpass";
    filter.frequency.setValueAtTime(o.f ?? 1000, t);
    if (o.f2) filter.frequency.exponentialRampToValueAtTime(o.f2, t + o.dur);
    filter.Q.value = o.q ?? 1;
    const env = this.envelope(ctx, t, o.vol ?? 0.3, o.attack ?? 0.003, o.dur);
    src.connect(filter).connect(env).connect(dest);
    src.start(t, Math.random() * 0.5);
    src.stop(t + o.dur + 0.05);
  }

  swing(s?: Spatial) {
    this.noise({ dur: 0.14, vol: 0.12, type: "bandpass", f: 500, f2: 2200, q: 1.5 }, s);
  }

  hit(crit: boolean, s?: Spatial) {
    this.noise({ dur: 0.09, vol: 0.5, f: 1400, f2: 300 }, s);
    this.tone({ type: "square", f: 170, f2: 70, dur: 0.1, vol: 0.16, lp: 1200 }, s);
    if (crit) {
      this.tone({ f: 1250, f2: 1900, dur: 0.2, vol: 0.18, delay: 0.01 }, s);
      this.noise({ dur: 0.22, vol: 0.18, type: "highpass", f: 3000, delay: 0.02 }, s);
    }
  }

  hurt() {
    this.tone({ type: "triangle", f: 320, f2: 140, dur: 0.18, vol: 0.3 });
    this.noise({ dur: 0.08, vol: 0.4, f: 900 });
  }

  kill() {
    this.tone({ f: 1046, dur: 0.12, vol: 0.2 });
    this.tone({ f: 1568, dur: 0.4, vol: 0.2, delay: 0.08 });
  }

  death(s?: Spatial) {
    this.tone({ type: "square", f: 420, f2: 55, dur: 0.6, vol: 0.12, lp: 1500 }, s);
    this.noise({ dur: 0.45, vol: 0.35, f: 1800, f2: 200, delay: 0.05 }, s);
  }

  step() {
    this.noise({ dur: 0.06, vol: 0.07, f: 500 + Math.random() * 300 });
  }

  land(speed: number) {
    this.noise({ dur: 0.12, vol: Math.min(0.4, 0.1 + speed * 0.015), f: 380 });
  }

  place(s?: Spatial) {
    this.noise({ dur: 0.07, vol: 0.3, f: 650 }, s);
    this.tone({ f: 210, f2: 120, dur: 0.07, vol: 0.12 }, s);
  }

  breakBlock(s?: Spatial) {
    this.noise({ dur: 0.16, vol: 0.32, type: "bandpass", f: 900, f2: 400, q: 0.8 }, s);
    this.noise({ dur: 0.05, vol: 0.2, type: "highpass", f: 2500, delay: 0.04 }, s);
  }

  pickup() {
    [660, 880, 1175].forEach((f, i) => this.tone({ f, dur: 0.12, vol: 0.16, delay: i * 0.06 }));
  }

  rouletteTick(progress: number) {
    this.tone({ type: "square", f: 900 + progress * 400, dur: 0.03, vol: 0.05, lp: 3000 });
  }

  rouletteStop() {
    this.tone({ f: 880, dur: 0.6, vol: 0.16 });
    this.tone({ f: 1320, dur: 0.6, vol: 0.1 });
  }

  /** Brass-like fanfare with a low boom for a new buff. */
  horn() {
    const chord = (fs: number[], delay: number, dur: number) =>
      fs.forEach((f) => this.tone({ type: "sawtooth", f, dur, vol: 0.07, attack: 0.04, delay, lp: 1800 }));
    chord([196, 247, 294], 0, 0.22);
    chord([262, 330, 392], 0.2, 0.95);
    this.tone({ f: 70, f2: 38, dur: 0.8, vol: 0.45, delay: 0.2 });
    this.noise({ dur: 0.6, vol: 0.15, f: 300, delay: 0.2 });
  }

  beep(go: boolean) {
    this.tone({ type: "square", f: go ? 1046 : 523, dur: go ? 0.5 : 0.15, vol: 0.1, lp: 3000 });
  }

  tick(urgent: boolean) {
    this.tone({ type: "triangle", f: urgent ? 1400 : 1000, dur: 0.05, vol: 0.12 });
  }

  roundEnd(won: boolean) {
    const notes = won ? [523, 659, 784, 1046] : [392, 494, 587];
    notes.forEach((f, i) =>
      this.tone({ type: "triangle", f, dur: i === notes.length - 1 ? 0.9 : 0.18, vol: 0.2, delay: i * 0.13 }),
    );
  }
}

export const sfx = new Sfx();
