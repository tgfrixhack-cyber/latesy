import * as THREE from "three";
import { EYE_HEIGHT, MAX_HP } from "../shared";
import { faceTexture, headSideTexture, labelTexture } from "./textures";

const PX = 1.8 / 32; // Minecraft proportions: a player is 32 "pixels" tall

const SKIN = "#e0ac7e";
const HAIRS = ["#3b2416", "#6b4423", "#1f1f1f", "#c58b3c", "#8a2f1b"];

function box(w: number, h: number, d: number, mat: THREE.Material | THREE.Material[]) {
  const g = new THREE.BoxGeometry(w * PX, h * PX, d * PX);
  g.translate(0, (-h * PX) / 2, 0); // pivot at the top (shoulder / hip)
  return new THREE.Mesh(g, mat);
}

export function createSword(depthTest = true) {
  const g = new THREE.Group();
  const mk = (color: string) => new THREE.MeshLambertMaterial({ color, depthTest });
  const blade = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.62, 0.035), mk("#d9e4ec"));
  blade.position.y = 0.42;
  const edge = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.6, 0.04), mk("#9fb3c2"));
  edge.position.y = 0.42;
  const guard = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.05, 0.07), mk("#3b3b3b"));
  guard.position.y = 0.1;
  const handle = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.18, 0.05), mk("#6b4423"));
  handle.position.y = -0.02;
  g.add(blade, edge, guard, handle);
  if (!depthTest) g.traverse((o) => (o.renderOrder = 999));
  return g;
}

export class Avatar {
  readonly group = new THREE.Group();
  readonly pos = new THREE.Vector3();
  readonly target = new THREE.Vector3();
  yaw = 0;
  pitch = 0;
  targetYaw = 0;
  targetPitch = 0;
  hp = MAX_HP;
  private head = new THREE.Group();
  private armL: THREE.Mesh;
  private armR: THREE.Mesh;
  private legL: THREE.Mesh;
  private legR: THREE.Mesh;
  private label: THREE.Sprite;
  private materials: THREE.MeshLambertMaterial[] = [];
  private walk = 0;
  private swingAt = -1e9;
  private hurtAt = -1e9;
  private initialized = false;
  private dyingSince = 0;
  private fallDir = 1;
  /** Body colours, used for the death burst. */
  readonly palette: string[];

  constructor(
    readonly id: number,
    readonly name: string,
    readonly color: string,
  ) {
    const hair = HAIRS[id % HAIRS.length];
    this.palette = [color, SKIN, "#2f3a6b", hair];
    const mat = (o: THREE.MeshLambertMaterialParameters) => {
      const m = new THREE.MeshLambertMaterial({ ...o, transparent: true });
      this.materials.push(m);
      return m;
    };
    const skin = mat({ color: SKIN });
    const shirt = mat({ color });
    const pants = mat({ color: "#2f3a6b" });
    const hairMat = mat({ color: hair });
    const face = mat({ map: faceTexture(hair, SKIN) });
    const side = mat({ map: headSideTexture(hair, SKIN) });

    // BoxGeometry face order: +x, -x, +y, -y, +z, -z; the model faces -Z.
    const headMesh = box(8, 8, 8, [side, side, hairMat, skin, hairMat, face]);
    headMesh.position.y = 8 * PX;
    this.head.add(headMesh);
    this.head.position.y = 24 * PX;

    const body = box(8, 12, 4, shirt);
    body.position.y = 24 * PX;
    const sleeve = [shirt, shirt, shirt, skin, shirt, shirt];
    this.armL = box(4, 12, 4, sleeve);
    this.armL.position.set(-6 * PX, 24 * PX, 0);
    this.armR = box(4, 12, 4, sleeve);
    this.armR.position.set(6 * PX, 24 * PX, 0);
    this.legL = box(4, 12, 4, pants);
    this.legL.position.set(-2 * PX, 12 * PX, 0);
    this.legR = box(4, 12, 4, pants);
    this.legR.position.set(2 * PX, 12 * PX, 0);

    const sword = createSword();
    sword.scale.setScalar(0.8);
    sword.position.set(0, -11 * PX, -0.1);
    sword.rotation.x = -Math.PI / 2;
    this.armR.add(sword);

    this.label = new THREE.Sprite(new THREE.SpriteMaterial({ map: labelTexture(name, color, 1), transparent: true }));
    this.label.scale.set(1.6, 0.45, 1);
    this.label.position.y = 2.2;

    this.group.add(this.head, body, this.armL, this.armR, this.legL, this.legR, this.label);
    this.group.rotation.order = "YXZ"; // yaw first, so a death roll tips the body sideways
    this.group.traverse((o) => {
      if (o instanceof THREE.Mesh) o.castShadow = true;
    });
  }

  setTarget(x: number, y: number, z: number, yaw: number, pitch: number) {
    this.target.set(x, y, z);
    this.targetYaw = yaw;
    this.targetPitch = pitch;
    if (!this.initialized) {
      this.initialized = true;
      this.pos.copy(this.target);
      this.yaw = yaw;
      this.pitch = pitch;
    }
  }

  setHp(hp: number) {
    if (hp === this.hp) return;
    this.hp = hp;
    const mat = this.label.material;
    mat.map?.dispose();
    mat.map = labelTexture(this.name, this.color, hp / MAX_HP);
    mat.needsUpdate = true;
  }

  swing(now: number) {
    this.swingAt = now;
  }

  hurt(now: number) {
    this.hurtAt = now;
  }

  get eye() {
    return new THREE.Vector3(this.pos.x, this.pos.y + EYE_HEIGHT, this.pos.z);
  }

  update(dt: number, now: number, invisible: boolean) {
    const k = 1 - Math.exp(-dt * 14);
    const before = this.pos.clone();
    this.pos.lerp(this.target, k);
    let dy = this.targetYaw - this.yaw;
    dy = Math.atan2(Math.sin(dy), Math.cos(dy));
    this.yaw += dy * k;
    this.pitch += (this.targetPitch - this.pitch) * k;

    const speed = Math.hypot(this.pos.x - before.x, this.pos.z - before.z) / Math.max(dt, 1e-3);
    const amp = Math.min(1, speed / 4) * 0.9;
    this.walk += dt * speed * 2.2;
    const s = Math.sin(this.walk) * amp;
    this.legL.rotation.x = s;
    this.legR.rotation.x = -s;
    this.armL.rotation.x = -s;
    this.armR.rotation.x = s;

    const st = (now - this.swingAt) / 280;
    if (st < 1) {
      this.armR.rotation.x = -Math.sin(st * Math.PI) * 1.8;
      this.armR.rotation.z = Math.sin(st * Math.PI) * 0.3;
    } else {
      this.armR.rotation.z = 0;
    }

    this.group.position.copy(this.pos);
    this.group.rotation.y = this.yaw;
    this.head.rotation.x = this.pitch;

    // Invisibility: a hit reveals the attacker for a second.
    const revealed = now - this.swingAt < 1000;
    const opacity = invisible && !revealed ? 0.04 : invisible ? 0.5 : 1;
    const hurt = now - this.hurtAt < 250;
    for (const m of this.materials) {
      m.opacity = opacity;
      m.depthWrite = opacity === 1;
      m.emissive.setRGB(hurt ? 0.7 : 0, 0, 0);
    }
    this.label.visible = !invisible || revealed;
  }

  die(now: number) {
    this.dyingSince = now;
    this.fallDir = Math.random() < 0.5 ? 1 : -1;
    this.label.visible = false;
  }

  /** Death animation: flash red and topple sideways. Returns false once finished. */
  updateDying(now: number) {
    const t = (now - this.dyingSince) / 1000;
    const fall = Math.min(1, t / 0.35);
    this.group.rotation.set(0, this.yaw, fall * fall * (Math.PI / 2) * this.fallDir);
    this.group.position.copy(this.pos);
    const flash = 0.45 + 0.25 * Math.sin(t * 30);
    for (const m of this.materials) {
      m.opacity = 1;
      m.depthWrite = true;
      m.emissive.setRGB(flash, 0, 0);
    }
    return t < 0.9;
  }

  dispose() {
    this.group.traverse((o) => {
      if (o instanceof THREE.Mesh) o.geometry.dispose();
    });
    for (const m of this.materials) {
      m.map?.dispose();
      m.dispose();
    }
    this.label.material.map?.dispose();
    this.label.material.dispose();
  }
}
