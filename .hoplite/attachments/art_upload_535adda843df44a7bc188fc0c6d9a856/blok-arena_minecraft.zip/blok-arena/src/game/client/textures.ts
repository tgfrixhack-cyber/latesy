import * as THREE from "three";

// Procedural 16×16 pixel-art textures, so the game ships without image assets.

function rng(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

function canvas(w: number, h: number) {
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  return [c, c.getContext("2d")!] as const;
}

function pick(r: () => number, palette: string[]) {
  return palette[Math.floor(r() * palette.length)];
}

function noise(ctx: CanvasRenderingContext2D, seed: number, palette: string[], y0 = 0, y1 = 16) {
  const r = rng(seed);
  for (let y = y0; y < y1; y++) {
    for (let x = 0; x < 16; x++) {
      ctx.fillStyle = pick(r, palette);
      ctx.fillRect(x, y, 1, 1);
    }
  }
}

const DIRT = ["#79553a", "#866043", "#966c4a", "#6c4b33", "#866043", "#5d4128"];
const GRASS = ["#5f9e35", "#6bb03c", "#57912f", "#78bd47", "#64a637"];
const STONE = ["#7d7d7d", "#8a8a8a", "#6e6e6e", "#959595", "#848484"];
const LAVA = ["#ff7a00", "#ff9a1f", "#ffb43d", "#e85d04", "#ffd166", "#d94a00"];

function toTexture(c: HTMLCanvasElement, repeat = false) {
  const t = new THREE.CanvasTexture(c);
  t.magFilter = THREE.NearestFilter;
  t.minFilter = THREE.NearestMipmapLinearFilter;
  t.colorSpace = THREE.SRGBColorSpace;
  if (repeat) t.wrapS = t.wrapT = THREE.RepeatWrapping;
  return t;
}

function drawDirt(seed = 1) {
  const [c, ctx] = canvas(16, 16);
  noise(ctx, seed, DIRT);
  return c;
}

export function createTextures() {
  const grassTop = canvas(16, 16);
  noise(grassTop[1], 7, GRASS);

  const grassSide = canvas(16, 16);
  noise(grassSide[1], 3, DIRT);
  const r = rng(11);
  for (let x = 0; x < 16; x++) {
    const depth = 3 + Math.floor(r() * 3);
    for (let y = 0; y < depth; y++) {
      grassSide[1].fillStyle = pick(r, GRASS);
      grassSide[1].fillRect(x, y, 1, 1);
    }
  }

  const stone = canvas(16, 16);
  noise(stone[1], 5, STONE);
  stone[1].strokeStyle = "rgba(0,0,0,0.18)";
  stone[1].strokeRect(0.5, 0.5, 15, 15);

  const lava = canvas(16, 16);
  noise(lava[1], 9, LAVA);

  const block = drawDirt(21);
  const ctx = block.getContext("2d")!;
  ctx.fillStyle = "rgba(0,0,0,0.25)";
  ctx.fillRect(0, 15, 16, 1);
  ctx.fillRect(15, 0, 1, 16);

  return {
    grassTop: toTexture(grassTop[0]),
    grassSide: toTexture(grassSide[0]),
    dirt: toTexture(drawDirt(2), true),
    stone: toTexture(stone[0]),
    lava: toTexture(lava[0]),
    block: toTexture(block),
  };
}

/** Data URL of the dirt block, for HUD icons. */
export function dirtIconUrl() {
  return drawDirt(21).toDataURL();
}

export function faceTexture(hair: string, skin: string) {
  const [c, ctx] = canvas(8, 8);
  ctx.fillStyle = skin;
  ctx.fillRect(0, 0, 8, 8);
  ctx.fillStyle = hair;
  ctx.fillRect(0, 0, 8, 2);
  ctx.fillRect(0, 2, 1, 1);
  ctx.fillRect(7, 2, 1, 1);
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(1, 4, 2, 1);
  ctx.fillRect(5, 4, 2, 1);
  ctx.fillStyle = "#3b2a7a";
  ctx.fillRect(2, 4, 1, 1);
  ctx.fillRect(5, 4, 1, 1);
  ctx.fillStyle = "#9b5d43";
  ctx.fillRect(3, 6, 2, 1);
  return toTexture(c);
}

export function headSideTexture(hair: string, skin: string) {
  const [c, ctx] = canvas(8, 8);
  ctx.fillStyle = skin;
  ctx.fillRect(0, 0, 8, 8);
  ctx.fillStyle = hair;
  ctx.fillRect(0, 0, 8, 3);
  ctx.fillRect(5, 3, 3, 2);
  return toTexture(c);
}

export function ringTexture() {
  const [c, ctx] = canvas(32, 64);
  const g = ctx.createLinearGradient(0, 64, 0, 0);
  g.addColorStop(0, "rgba(255,255,255,0.55)");
  g.addColorStop(0.35, "rgba(255,255,255,0.18)");
  g.addColorStop(1, "rgba(255,255,255,0)");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 32, 64);
  ctx.fillStyle = "rgba(255,255,255,0.35)";
  ctx.fillRect(0, 0, 2, 64);
  const t = new THREE.CanvasTexture(c);
  t.wrapS = THREE.RepeatWrapping;
  return t;
}

export function gridTexture() {
  const [c, ctx] = canvas(32, 32);
  ctx.strokeStyle = "rgba(255,255,255,0.9)";
  ctx.lineWidth = 2;
  ctx.strokeRect(0, 0, 32, 32);
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  return t;
}

let labelFont = "monospace";

/** Canvas can't resolve next/font's generated family name by itself, so the engine passes it in. */
export function setLabelFont(family: string) {
  if (family) labelFont = family;
}

export function labelTexture(text: string, color: string, hpRatio: number | null) {
  const [c, ctx] = canvas(256, 72);
  ctx.font = `bold 30px ${labelFont}`;
  const w = Math.min(248, ctx.measureText(text).width + 24);
  ctx.fillStyle = "rgba(0,0,0,0.5)";
  ctx.fillRect(128 - w / 2, 4, w, 40);
  ctx.fillStyle = color;
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(text, 128, 25);
  if (hpRatio !== null) {
    ctx.fillStyle = "rgba(0,0,0,0.6)";
    ctx.fillRect(68, 52, 120, 14);
    ctx.fillStyle = hpRatio > 0.5 ? "#4ade80" : hpRatio > 0.25 ? "#facc15" : "#ef4444";
    ctx.fillRect(70, 54, 116 * Math.max(0, hpRatio), 10);
  }
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

let pixelFont = "monospace";

export function setPixelFont(family: string) {
  if (family.trim()) pixelFont = family;
}

export function numberTexture(text: string, color: string) {
  const font = `28px ${pixelFont}`;
  const probe = canvas(1, 1)[1];
  probe.font = font;
  const w = Math.ceil(probe.measureText(text).width) + 16;
  const [c, ctx] = canvas(w, 48);
  ctx.font = font;
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.lineWidth = 6;
  ctx.lineJoin = "round";
  ctx.strokeStyle = "rgba(0,0,0,0.85)";
  ctx.strokeText(text, w / 2, 26);
  ctx.fillStyle = color;
  ctx.fillText(text, w / 2, 26);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.minFilter = THREE.LinearFilter;
  t.generateMipmaps = false;
  return t;
}
