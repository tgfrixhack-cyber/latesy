"use client";

import { useEffect, useRef, useState, useSyncExternalStore } from "react";
import type { ReactNode } from "react";
import { BUFFS, MAX_HP, MAX_PLAYERS, MIN_PLAYERS } from "@/game/shared";
import { Engine } from "@/game/client/engine";
import { createStore, initialUi } from "@/game/client/store";
import type { UiState } from "@/game/client/store";
import { dirtIconUrl } from "@/game/client/textures";
import { sfx } from "@/game/client/sound";
import "./pvp.css";

const NAME_KEY = "pvp-name";

function useNow(interval = 200) {
  const [now, setNow] = useState(() => performance.now());
  useEffect(() => {
    const id = setInterval(() => setNow(performance.now()), interval);
    return () => clearInterval(id);
  }, [interval]);
  return now;
}

const fmt = (ms: number) => {
  const s = Math.max(0, Math.ceil(ms / 1000));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
};

function Panel({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <div className={`pvp-panel ${className}`}>{children}</div>;
}

function McButton({ children, onClick, tone = "stone", className = "", disabled }: {
  children: ReactNode;
  onClick?: () => void;
  tone?: "stone" | "green" | "red";
  className?: string;
  disabled?: boolean;
}) {
  return (
    <button type={onClick ? "button" : "submit"} onClick={onClick} disabled={disabled} className={`pvp-btn pvp-btn-${tone} ${className}`}>
      {children}
    </button>
  );
}

const CONTROLS: [string, string][] = [
  ["WASD", "ходьба"],
  ["Пробел", "прыжок"],
  ["Мышь", "обзор"],
  ["ЛКМ", "удар / сломать блок"],
  ["ПКМ", "поставить землю"],
  ["Прыжок + удар", "крит ×1.5"],
  ["M", "звук вкл/выкл"],
];

function Controls() {
  return (
    <ul className="grid grid-cols-2 gap-x-4 gap-y-1 text-sm text-white/80">
      {CONTROLS.map(([k, v]) => (
        <li key={k}>
          <span className="pvp-key">{k}</span> {v}
        </li>
      ))}
    </ul>
  );
}

function JoinScreen({ onJoin }: { onJoin: (name: string) => void }) {
  const [name, setName] = useState(() => localStorage.getItem(NAME_KEY) ?? "");
  return (
    <div className="absolute inset-0 flex items-center justify-center bg-black/35 p-4">
      <Panel className="w-full max-w-lg">
        <h1 className="pvp-title text-center text-3xl text-[#ffde59] md:text-4xl">БЛОК-АРЕНА</h1>
        <p className="mt-2 text-center text-white/85">
          PvP до последнего выжившего · {MIN_PLAYERS}–{MAX_PLAYERS} игроков · новый баф для всех каждые 2 минуты
        </p>
        <form
          className="mt-6 flex gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            const n = name.trim().slice(0, 16);
            localStorage.setItem(NAME_KEY, n);
            onJoin(n);
          }}
        >
          <input
            autoFocus
            value={name}
            maxLength={16}
            onChange={(e) => setName(e.target.value)}
            placeholder="Ваш ник"
            aria-label="Ник"
            className="pvp-input flex-1"
          />
          <McButton tone="green">Играть</McButton>
        </form>
        <ul className="mt-6 space-y-1 text-sm text-white/80">
          <li>• У каждого 10 блоков земли и меч. Убитый теряет всё: его земля выпадает мешком.</li>
          <li>• Удар в падении — критический: урон ×1.5.</li>
          <li>• Арена — круг, строить можно до 20 блоков в высоту. Блоки не падают.</li>
          <li>• Выбыл — смотришь за игроками до конца раунда.</li>
          <li>• Через 8 минут кольцо сужается. Через 10 минут, если живы несколько, победитель выбирается случайно.</li>
        </ul>
        <div className="mt-5">
          <Controls />
        </div>
      </Panel>
    </div>
  );
}

function Lobby({ ui, onVote }: { ui: UiState; onVote: (on: boolean) => void }) {
  const participants = ui.players.filter((p) => p.role === "player");
  const queue = ui.players.filter((p) => p.role === "spectator");
  const votes = participants.filter((p) => p.voted).length;
  const needed = Math.floor(participants.length / 2) + 1;
  const me = ui.players.find((p) => p.id === ui.myId);
  return (
    <div className="absolute inset-0 flex items-center justify-center p-4">
      <Panel className="w-full max-w-md">
        <h2 className="pvp-title text-center text-2xl text-[#ffde59]">Лобби</h2>
        <p className="mt-1 text-center text-sm text-white/75">
          Старт, когда больше половины игроков нажмут «Готов» (минимум {MIN_PLAYERS})
        </p>
        <div className="mt-4 flex items-center justify-between text-sm text-white/80">
          <span>
            Игроки {participants.length}/{MAX_PLAYERS}
          </span>
          <span>
            Готовы {votes}/{participants.length}
            {participants.length >= MIN_PLAYERS ? ` · нужно ${needed}` : ""}
          </span>
        </div>
        <ul className="mt-2 max-h-64 space-y-1 overflow-y-auto">
          {participants.map((p) => (
            <li key={p.id} className="flex items-center gap-2 bg-black/30 px-3 py-1.5">
              <span className="h-3 w-3 shrink-0" style={{ background: p.color }} />
              <span className="flex-1 truncate">
                {p.name}
                {p.id === ui.myId ? " (вы)" : ""}
              </span>
              <span className={p.voted ? "text-[#7CFC00]" : "text-white/40"}>{p.voted ? "ГОТОВ" : "ждёт"}</span>
            </li>
          ))}
        </ul>
        {queue.length > 0 && <p className="mt-2 text-sm text-white/60">В очереди: {queue.map((q) => q.name).join(", ")}</p>}
        {me?.role === "player" ? (
          <McButton tone={me.voted ? "red" : "green"} className="mt-4 w-full" onClick={() => onVote(!me.voted)}>
            {me.voted ? "Отменить" : "Готов к бою"}
          </McButton>
        ) : (
          <p className="mt-4 text-center text-[#ffde59]">Мест нет — вы в очереди на следующий раунд</p>
        )}
        {participants.length < MIN_PLAYERS && (
          <p className="mt-3 text-center text-sm text-white/70">Ждём хотя бы ещё одного игрока…</p>
        )}
        <div className="mt-5">
          <Controls />
        </div>
      </Panel>
    </div>
  );
}

const HEART_ROWS = [".XX.XX.", "XXXXXXX", "XXXXXXX", ".XXXXX.", "..XXX..", "...X..."];

function Heart({ fill }: { fill: 0 | 1 | 2 }) {
  return (
    <svg viewBox="-0.5 -0.5 8 7" className="h-6 w-6" shapeRendering="crispEdges" aria-hidden>
      {HEART_ROWS.flatMap((row, y) =>
        [...row].map((c, x) =>
          c === "X" ? (
            <rect key={`${x}-${y}`} x={x} y={y} width={1} height={1} fill={fill === 2 || (fill === 1 && x <= 3) ? "#e11d48" : "#3f3f46"} stroke="#000" strokeWidth={0.12} />
          ) : null,
        ),
      )}
    </svg>
  );
}

function Hearts({ hp }: { hp: number }) {
  return (
    <div className="flex gap-0.5" aria-label={`Здоровье ${hp} из ${MAX_HP}`}>
      {Array.from({ length: MAX_HP / 2 }, (_, i) => {
        const v = hp - i * 2;
        return <Heart key={i} fill={v >= 2 ? 2 : v === 1 ? 1 : 0} />;
      })}
    </div>
  );
}

function TopBar({ ui, now }: { ui: UiState; now: number }) {
  const elapsed = Math.max(0, now - ui.phaseStartedAt);
  const t = ui.timings;
  const participants = ui.players.filter((p) => p.role === "player");
  const alive = participants.filter((p) => p.alive).length;
  const nextBuffAt = (Math.floor(elapsed / t.buffIntervalMs) + 1) * t.buffIntervalMs;
  const buff = ui.buff ? BUFFS[ui.buff] : null;
  const shrinking = elapsed >= t.shrinkStartMs;
  return (
    <div className="pointer-events-none absolute left-1/2 top-3 flex -translate-x-1/2 flex-col items-center gap-1.5">
      <div className="flex items-center gap-3">
        <Panel className="pvp-title !px-4 !py-2 text-xl">{fmt(t.roundMs - elapsed)}</Panel>
        <Panel className="!px-3 !py-1.5 text-lg">
          Живых <b className="text-[#7CFC00]">{alive}</b>/{participants.length}
        </Panel>
      </div>
      <div className="flex items-center gap-2 text-sm">
        {buff ? (
          <span className="pvp-badge" style={{ borderColor: buff.color, color: buff.color }}>
            {buff.title}
          </span>
        ) : (
          <span className="pvp-badge border-white/40 text-white/70">без бафа</span>
        )}
        {shrinking ? (
          <span className="pvp-badge pvp-pulse border-red-400 text-red-300">Кольцо сужается!</span>
        ) : nextBuffAt < t.roundMs ? (
          <span className="bg-black/45 px-2 py-0.5 text-white">новый баф через {fmt(nextBuffAt - elapsed)}</span>
        ) : null}
      </div>
    </div>
  );
}

function Scoreboard({ ui }: { ui: UiState }) {
  const participants = ui.players.filter((p) => p.role === "player");
  return (
    <div className="pointer-events-none absolute left-3 top-3 w-44 space-y-0.5 text-sm">
      {participants.map((p) => (
        <div key={p.id} className={`flex items-center gap-1.5 bg-black/35 px-2 py-0.5 ${p.alive ? "" : "opacity-45 line-through"}`}>
          <span className="h-2.5 w-2.5 shrink-0" style={{ background: p.color }} />
          <span className="flex-1 truncate">{p.name}</span>
          <span className="text-white/70">⚔{p.kills}</span>
        </div>
      ))}
    </div>
  );
}

function KillFeed({ ui, now }: { ui: UiState; now: number }) {
  const items = ui.feed.filter((f) => now - f.at < 7000);
  return (
    <div className="pointer-events-none absolute right-3 top-3 flex flex-col items-end gap-1 text-sm">
      {items.map((f) => (
        <div key={f.key} className="pvp-feed bg-black/45 px-2 py-1">
          {f.reason === "leave" ? (
            <>
              <span style={{ color: f.victim.color }}>{f.victim.name}</span> <span className="text-white/70">вышел</span>
            </>
          ) : (
            <>
              <span style={{ color: f.killer?.color }}>{f.killer?.name ?? "?"}</span> <span className="text-white/70">⚔</span>{" "}
              <span style={{ color: f.victim.color }}>{f.victim.name}</span>
            </>
          )}
        </div>
      ))}
    </div>
  );
}

function Announcement({ buff }: { buff: NonNullable<UiState["buff"]> }) {
  const b = BUFFS[buff];
  return (
    <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center text-center">
      <div className="pvp-flash absolute inset-0" style={{ background: `radial-gradient(circle at center, ${b.color}aa 0%, transparent 65%)` }} />
      <div className="pvp-sub pvp-outline relative text-base tracking-[0.5em] text-white/90">НОВЫЙ БАФ</div>
      <div className="pvp-shake relative">
        <div className="pvp-announce relative px-4 text-4xl md:text-6xl" style={{ color: b.color, textShadow: `0 0 28px ${b.color}, 5px 5px 0 #000` }}>
          {b.title}
        </div>
      </div>
      <div className="pvp-sub pvp-outline relative mt-4 px-6 text-xl md:text-2xl">{b.description}</div>
    </div>
  );
}

function Countdown({ ui, now }: { ui: UiState; now: number }) {
  const elapsed = Math.max(0, now - ui.phaseStartedAt);
  let text: string | null = null;
  if (ui.phase === "countdown") text = String(Math.max(1, Math.ceil((ui.timings.countdownMs - elapsed) / 1000)));
  else if (ui.phase === "playing" && elapsed < 1200) text = "БОЙ!";
  if (!text) return null;
  return (
    <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
      <div key={text} className="pvp-count pvp-title text-8xl text-[#ffde59]">
        {text}
      </div>
    </div>
  );
}

function SpectatorBar({ ui }: { ui: UiState }) {
  const s = ui.spectate;
  const modeName = s?.mode === "first" ? "1-е лицо" : s?.mode === "third" ? "3-е лицо" : "свободная камера";
  const me = ui.players.find((p) => p.id === ui.myId);
  const lateJoin = me?.role === "spectator";
  return (
    <div className="pointer-events-none absolute bottom-4 left-1/2 flex -translate-x-1/2 flex-col items-center gap-2 text-center">
      <Panel className="!py-2">
        <div className="text-lg text-[#ffde59]">{lateJoin ? "Раунд уже идёт — вы попадёте в следующий" : "Вы выбыли — наблюдение"}</div>
        <div className="text-white/90">
          {s?.target && s.mode !== "free" ? (
            <>
              Смотрите за <b>{s.target}</b> · {modeName}
            </>
          ) : (
            modeName
          )}
        </div>
        <div className="mt-1 text-xs text-white/65">
          <span className="pvp-key">V</span> режим · <span className="pvp-key">Q</span>/<span className="pvp-key">E</span> или ЛКМ/ПКМ — игрок ·{" "}
          <span className="pvp-key">WASD</span> <span className="pvp-key">Пробел</span>/<span className="pvp-key">Shift</span> — полёт
        </div>
      </Panel>
    </div>
  );
}

function EndScreen({ ui, now }: { ui: UiState; now: number }) {
  const left = ui.timings.endMs - Math.max(0, now - ui.phaseStartedAt);
  const winner = ui.players.find((p) => p.id === ui.winnerId);
  return (
    <div className="absolute inset-0 flex items-center justify-center bg-black/40 p-4">
      <Panel className="text-center">
        {ui.winnerName ? (
          <>
            <div className="text-lg tracking-[0.4em] text-white/80">ПОБЕДИТЕЛЬ</div>
            <div className="pvp-announce-in pvp-title mt-3 text-3xl md:text-4xl" style={{ color: winner?.color ?? "#ffde59" }}>
              {ui.winnerName}
            </div>
            {ui.winnerId === ui.myId && <div className="mt-2 text-2xl text-[#7CFC00]">Это вы!</div>}
            {ui.randomWin && <div className="mt-3 text-white/80">Время вышло — победитель выбран случайно среди выживших</div>}
          </>
        ) : (
          <div className="pvp-title text-2xl text-white">Никто не выжил</div>
        )}
        <div className="mt-4 text-sm text-white/60">Лобби через {Math.max(0, Math.ceil(left / 1000))} с</div>
      </Panel>
    </div>
  );
}

const REEL_ITEM_H = 46;

/** Slot-machine reel that decelerates onto the next buff, timed to land just before it activates. */
function Roulette({ r }: { r: NonNullable<UiState["roulette"]> }) {
  const reelRef = useRef<HTMLDivElement>(null);
  const [landed, setLanded] = useState(false);
  useEffect(() => {
    let raf = 0;
    let last = -1;
    const start = r.endsAt - r.duration;
    const n = r.items.length - 1;
    const loop = () => {
      const u = Math.min(1, Math.max(0, (performance.now() - start) / r.duration));
      const p = n * (1 - Math.pow(1 - u, 3));
      if (reelRef.current) reelRef.current.style.transform = `translateY(${-p * REEL_ITEM_H}px)`;
      const idx = Math.round(p);
      if (idx !== last) {
        if (last >= 0) sfx.rouletteTick(u);
        last = idx;
      }
      if (u >= 1) {
        sfx.rouletteStop();
        setLanded(true);
        return;
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [r]);
  return (
    <div className="pointer-events-none absolute inset-x-0 top-[17%] flex flex-col items-center">
      <div className="pvp-outline mb-2 text-sm tracking-[0.4em] text-white/90">СЛЕДУЮЩИЙ БАФ</div>
      <div className={`pvp-reel ${landed ? "pvp-reel-landed" : ""}`} style={{ height: REEL_ITEM_H * 3 }}>
        <div ref={reelRef} style={{ paddingTop: REEL_ITEM_H }}>
          {r.items.map((b, i) => (
            <div key={i} className="pvp-title flex items-center justify-center text-lg" style={{ height: REEL_ITEM_H, color: BUFFS[b].color }}>
              {BUFFS[b].title}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function DeathBanner({ d }: { d: NonNullable<UiState["death"]> }) {
  return (
    <div className="pvp-death pointer-events-none absolute inset-0 flex flex-col items-center justify-center pt-[22vh] text-center">
      <div className="pvp-title text-4xl text-[#ff4d4d] md:text-5xl">ВЫ ПОГИБЛИ</div>
      {d.killer && (
        <div className="pvp-outline mt-5 text-xl">
          Вас убил <span style={{ color: d.color ?? "#fff" }}>{d.killer}</span>
        </div>
      )}
    </div>
  );
}

function SpeakerIcon({ muted }: { muted: boolean }) {
  return (
    <svg viewBox="0 0 16 16" className="h-5 w-5" aria-hidden>
      <path d="M2 6h3l4-3v10l-4-3H2z" fill="#fff" />
      {muted ? (
        <path d="M11 5.5l4 5M15 5.5l-4 5" stroke="#ff6b6b" strokeWidth="1.6" />
      ) : (
        <path d="M11 5.5c1 .8 1 4.2 0 5M13 4c2 1.5 2 6.5 0 8" stroke="#fff" strokeWidth="1.4" fill="none" />
      )}
    </svg>
  );
}

function Hud({ ui, dirtIcon, onVote, onToggleMute }: { ui: UiState; dirtIcon: string; onVote: (on: boolean) => void; onToggleMute: () => void }) {
  const now = useNow();
  const playing = ui.phase === "playing" || ui.phase === "countdown";
  const spectating = playing && !ui.alive;
  return (
    <>
      {ui.hurtKey > 0 && <div key={ui.hurtKey} className="pvp-hurt pointer-events-none absolute inset-0" />}
      {playing && ui.alive && ui.buff === "lava" && <div className="pvp-lava pointer-events-none absolute inset-0" />}

      {ui.phase === "lobby" && <Lobby ui={ui} onVote={onVote} />}

      {playing && (
        <>
          <TopBar ui={ui} now={now} />
          <Scoreboard ui={ui} />
          <KillFeed ui={ui} now={now} />
          <Countdown ui={ui} now={now} />
          {ui.roulette && ui.phase === "playing" && <Roulette key={ui.roulette.key} r={ui.roulette} />}
          {ui.announce && ui.phase === "playing" && now - ui.announce.at < 4000 && <Announcement key={ui.announce.key} buff={ui.announce.buff} />}
        </>
      )}

      {playing && ui.alive && (
        <>
          <div className="pvp-crosshair pointer-events-none absolute left-1/2 top-1/2" />
          <div className="pointer-events-none absolute bottom-4 left-1/2 flex -translate-x-1/2 flex-col items-center gap-2">
            <div key={ui.hurtKey} className={ui.hurtKey ? "pvp-heart-shake" : ""}>
              <Hearts hp={ui.hp} />
            </div>
            <div className="pvp-slot flex items-center gap-2">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={dirtIcon} alt="" className="h-9 w-9 [image-rendering:pixelated]" />
              <span className="pvp-outline text-2xl tabular-nums">{ui.dirt}</span>
            </div>
          </div>
        </>
      )}

      {spectating && ui.death && now - ui.death.at < 3200 && <DeathBanner key={ui.death.key} d={ui.death} />}
      {spectating && ui.spectate && <SpectatorBar ui={ui} />}

      {playing && !ui.locked && (
        <div className="pointer-events-none absolute inset-x-0 top-[62%] text-center">
          <span className="pvp-outline bg-black/45 px-3 py-1.5 text-lg">Кликните по экрану, чтобы управлять мышью</span>
        </div>
      )}

      <button
        type="button"
        onClick={onToggleMute}
        className="pvp-mute absolute bottom-3 right-3"
        aria-label={ui.muted ? "Включить звук" : "Выключить звук"}
        title="Звук (M)"
      >
        <SpeakerIcon muted={ui.muted} />
        <span className="text-xs text-white/70">M</span>
      </button>

      {ui.phase === "ended" && <EndScreen ui={ui} now={now} />}
    </>
  );
}

export default function PvpGame() {
  const hostRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<Engine | null>(null);
  const [store] = useState(() => createStore(initialUi()));
  const [dirtIcon] = useState(() => dirtIconUrl());
  const ui = useSyncExternalStore(store.subscribe, store.get, store.get);

  useEffect(() => {
    const engine = new Engine(hostRef.current!, store);
    engineRef.current = engine;
    return () => {
      engine.dispose();
      engineRef.current = null;
    };
  }, [store]);

  return (
    <div className="pvp-root fixed inset-0 select-none overflow-hidden bg-black text-white">
      <div ref={hostRef} className="absolute inset-0" />
      {ui.conn === "idle" && <JoinScreen onJoin={(name) => engineRef.current?.join(name)} />}
      {ui.conn === "connecting" && (
        <div className="absolute inset-0 flex items-center justify-center">
          <Panel className="text-xl">Подключение к серверу…</Panel>
        </div>
      )}
      {ui.conn === "closed" && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/40 p-4">
          <Panel className="max-w-md text-center">
            <div className="text-2xl text-[#ff7b7b]">Нет связи с игровым сервером</div>
            <p className="mt-2 text-sm text-white/75">Сервер не запущен или соединение оборвалось.</p>
            <McButton className="mt-4" onClick={() => engineRef.current?.reconnect()}>
              Переподключиться
            </McButton>
          </Panel>
        </div>
      )}
      {ui.conn === "open" && <Hud ui={ui} dirtIcon={dirtIcon} onVote={(on) => engineRef.current?.vote(on)} onToggleMute={() => engineRef.current?.toggleMute()} />}
    </div>
  );
}
