This is a [Next.js](https://nextjs.org) project bootstrapped with [`create-next-app`](https://nextjs.org/docs/app/api-reference/cli/create-next-app).

## Блок-Арена (PvP) — `/pvp`

Кубический PvP до последнего выжившего: 2–12 игроков, круглая арена, потолок 20 блоков, новый баф для всех каждые 2 минуты.

- `npm run dev` — сайт и игровой сервер (WebSocket `/game-ws`) на одном порту, http://localhost:3000/pvp
- `npm run build && npm start` — то же в production
- `npm run game` — только игровой сервер (если сайт раздаётся статикой, например с GitHub Pages)

Игровой сервер запускается через встроенный в Node запуск TypeScript, нужен Node 22.18+.
Если сайт и сервер живут на разных хостах, при сборке сайта укажите `NEXT_PUBLIC_GAME_SERVER_URL=wss://ваш-сервер/game-ws`.
`PVP_TIME_SCALE=0.1` ускоряет раунд в 10 раз (удобно для тестов).

Код: `server/` — сервер раундов, `src/game/shared.ts` — общие правила и протокол, `src/game/client/` — движок на Three.js, `src/components/pvp/` — интерфейс.

## Getting Started

First, run the development server:

```bash
npm run dev
# or
yarn dev
# or
pnpm dev
# or
bun dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

You can start editing the page by modifying `app/page.tsx`. The page auto-updates as you edit the file.

This project uses [`next/font`](https://nextjs.org/docs/app/building-your-application/optimizing/fonts) to automatically optimize and load [Geist](https://vercel.com/font), a new font family for Vercel.

## Learn More

To learn more about Next.js, take a look at the following resources:

- [Next.js Documentation](https://nextjs.org/docs) - learn about Next.js features and API.
- [Learn Next.js](https://nextjs.org/learn) - an interactive Next.js tutorial.

You can check out [the Next.js GitHub repository](https://github.com/vercel/next.js) - your feedback and contributions are welcome!

## Deploy on Vercel

The easiest way to deploy your Next.js app is to use the [Vercel Platform](https://vercel.com/new?utm_medium=default-template&filter=next.js&utm_source=create-next-app&utm_campaign=create-next-app-readme) from the creators of Next.js.

Check out our [Next.js deployment documentation](https://nextjs.org/docs/app/building-your-application/deploying) for more details.
