'use strict';
// Регрессии серверных багов: файлы пользователя, тариф в публикациях, удаление аккаунта, куки, битый URL.
// Сервер и база живут во временной копии, настоящий data/ не трогаем.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const net = require('node:net');
const { spawn } = require('node:child_process');
const delay = (ms) => new Promise((r) => setTimeout(r, ms));
const sha = (s) => crypto.createHash('sha256').update(s).digest('hex');

test('Premier server fixes: isolated HTTP E2E', { timeout: 60000 }, async (t) => {
  const root = path.resolve(__dirname, '..'), dir = fs.mkdtempSync(path.join(os.tmpdir(), 'premier-fixes-'));
  let child, store, logs = '';
  t.after(async () => {
    if (child && child.exitCode === null) {
      child.kill('SIGTERM');
      await Promise.race([new Promise((r) => child.once('exit', r)), delay(6000)]);
      if (child.exitCode === null) child.kill('SIGKILL');
    }
    if (store) store.db.close();
    fs.rmSync(dir, { recursive: true, force: true });
  });
  fs.cpSync(root, dir, { recursive: true, filter: (src) => {
    const rel = path.relative(root, src), top = rel.split(path.sep)[0];
    return !rel || ['public', 'locales', 'desktop', 'api'].includes(top) || (!rel.includes(path.sep) && !top.startsWith('.') && /\.(js|json)$/.test(top));
  } });
  store = require(path.join(dir, 'db.js'));
  const sessions = new Map();
  function user(id, plan, until = Date.now() + 864e5) {
    const u = { id, login: id, email: id + '@example.invalid', created: new Date().toISOString(), ...(plan ? { plan, until } : {}) };
    store.users.put(u);
    const token = crypto.randomBytes(32).toString('hex');
    store.sessions.put(sha(token), id, Date.now() + 3600e3); sessions.set(id, token); return u;
  }
  const proUntil = Date.now() + 864e5;
  user('propaid', 'pro', proUntil); user('freeuser'); user('doomed');
  const fid = 'a1b2c3d4e5f60718';
  fs.mkdirSync(path.join(dir, 'data', 'files', 'propaid', fid), { recursive: true });
  fs.writeFileSync(path.join(dir, 'data', 'files', 'propaid', fid, 'note.txt'), 'hello');
  fs.mkdirSync(path.join(dir, 'data', 'sites'), { recursive: true });
  const ghost = 'abcdef0123';
  fs.writeFileSync(path.join(dir, 'data', 'sites', ghost + '.html'), '<h1>ghost</h1>');
  fs.writeFileSync(path.join(dir, 'data', 'sites', ghost + '.json'), JSON.stringify({ key: 'k', uid: 'no-such-user', title: 'ghost' }));
  const reservation = net.createServer(); await new Promise((r) => reservation.listen(0, '127.0.0.1', r));
  const port = reservation.address().port; await new Promise((r) => reservation.close(r));
  const base = 'http://127.0.0.1:' + port;
  child = spawn(process.execPath, ['server.js'], { cwd: dir, env: { ...process.env, HOST: '127.0.0.1', PORT: String(port), ADMIN_PASSWORD: crypto.randomBytes(12).toString('hex'), PUBLIC_URL: base, TRUST_PROXY: '1' }, stdio: ['ignore', 'pipe', 'pipe'] });
  child.stdout.on('data', (b) => { logs += b; }); child.stderr.on('data', (b) => { logs += b; });
  let ready = false;
  for (let i = 0; i < 100; i++) {
    if (child.exitCode !== null) throw new Error('Server did not start: ' + logs);
    try { if ((await fetch(base + '/healthz')).ok) { ready = true; break; } } catch {}
    await delay(100);
  }
  assert.ok(ready, logs);
  const alive = async () => { assert.equal(child.exitCode, null, 'server exited: ' + logs); assert.equal((await fetch(base + '/healthz', { signal: AbortSignal.timeout(3000) })).status, 200); };
  const get = (p, uid, headers = {}) => fetch(base + p, { redirect: 'manual', signal: AbortSignal.timeout(5000), headers: { 'X-Real-IP': '203.0.113.7', ...(uid ? { Cookie: 'premier_session=' + sessions.get(uid) } : {}), ...headers } });
  const post = (p, uid, body) => fetch(base + p, { method: 'POST', signal: AbortSignal.timeout(5000), headers: { 'Content-Type': 'application/json', 'X-Real-IP': '203.0.113.7', Cookie: 'premier_session=' + sessions.get(uid) }, body: JSON.stringify(body) });
  const raw = (head) => new Promise((resolve, reject) => {
    const s = net.connect(port, '127.0.0.1'); let data = '';
    const timer = setTimeout(() => { s.destroy(); reject(new Error('нет ответа на сырой запрос: ' + JSON.stringify(head))); }, 4000);
    s.on('data', (c) => { data += c; }); s.on('close', () => { clearTimeout(timer); resolve(data); }); s.on('error', () => {});
    s.write(head + '\r\nHost: x\r\nConnection: close\r\n\r\n');
  });

  await t.test('файлы: обычный файл отдаётся, «..» и каталоги — 404, процесс жив', async () => {
    const ok = await get(`/api/files/${fid}/note.txt`, 'propaid'); assert.equal(ok.status, 200); assert.equal(await ok.text(), 'hello');
    for (const name of ['..', 'a%2F..', '..%2F', '%2e%2e', 'a%2F..%2F..', '.', '%E0%A4%A', 'nope.txt']) {
      const r = await get(`/api/files/${fid}/${name}`, 'propaid');
      assert.equal(r.status, 404, name); await r.text();
    }
    assert.equal((await get(`/api/files/${fid}/note.txt`, 'freeuser')).status, 404); // чужой файл
    await alive();
  });

  await t.test('тариф: оплаченный Pro без подписи, Free и неизвестный владелец с подписью, until виден в кабинете', async () => {
    const html = '<!doctype html><title>x</title><h1>site</h1>';
    const pub = async (uid) => { const r = await post('/api/publish', uid, { html, title: 'T' }); assert.equal(r.status, 200); return r.json(); };
    const pro = await pub('propaid'), free = await pub('freeuser');
    assert.equal(pro.branding, false); assert.equal(free.branding, true);
    const pp = await (await get(pro.path, 'propaid')).text(), fp = await (await get(free.path)).text();
    assert.ok(!pp.includes('premier-promo')); assert.ok(fp.includes('premier-promo'));
    const bill = await (await get('/api/billing', 'propaid')).json();
    assert.equal(bill.plan.id, 'pro'); assert.equal(bill.plan.until, proUntil); assert.equal(bill.publicationBranding, false);
    const g = await get('/s/' + ghost); assert.equal(g.status, 200); assert.ok((await g.text()).includes('premier-promo')); // владельца нет — раньше 500
    await alive();
  });

  await t.test('удаление аккаунта убирает опубликованные сайты и отзывы', async () => {
    const r = await post('/api/publish', 'doomed', { html: '<h1>bye</h1>', title: 'B' }); assert.equal(r.status, 200);
    const site = await r.json(), id = site.id;
    store.db.prepare("INSERT INTO reviews (id, uid, nick, rating, text, status, at) VALUES ('rv0000000001', 'doomed', 'doomed', 5, 'text text text text text', 'approved', ?)").run(Date.now());
    assert.equal((await get(site.path)).status, 200);
    const d = await fetch(base + '/api/account', { method: 'DELETE', headers: { 'Content-Type': 'application/json', 'X-Real-IP': '203.0.113.7', Cookie: 'premier_session=' + sessions.get('doomed') }, body: JSON.stringify({ confirm: 'delete' }) });
    assert.equal(d.status, 200);
    assert.equal((await get(site.path)).status, 404);
    assert.ok(!fs.existsSync(path.join(dir, 'data', 'sites', id + '.html')) && !fs.existsSync(path.join(dir, 'data', 'sites', id + '.json')));
    assert.equal(store.db.prepare("SELECT count(*) AS n FROM reviews WHERE uid = 'doomed'").get().n, 0);
    assert.ok(fs.existsSync(path.join(dir, 'data', 'sites', ghost + '.html'))); // чужие сайты не тронуты
  });

  await t.test('битая кука не вешает страницы', async () => {
    for (const p of ['/chat', '/login', '/developers']) {
      const r = await get(p, null, { Cookie: 'x=%E0%A4%; y=%; premier_session=' + sessions.get('freeuser') });
      assert.ok(r.status < 500, p + ' ' + r.status); await r.text();
    }
    await alive();
  });

  await t.test('битый URL запроса — 400, а не зависший сокет', async () => {
    for (const head of ['GET // HTTP/1.1', 'GET http:// HTTP/1.1']) assert.match(await raw(head), /^HTTP\/1\.1 400 /, head);
    await alive();
  });

  await t.test('чат: null в теле — 400, огромный Content-Length — сразу 413', async () => {
    const hdr = { 'Content-Type': 'application/json', 'X-Real-IP': '203.0.113.7', Cookie: 'premier_session=' + sessions.get('freeuser') };
    assert.equal((await fetch(base + '/api/chat', { method: 'POST', headers: hdr, body: 'null' })).status, 400);
    const big = await raw(`POST /api/chat HTTP/1.1\r\nContent-Type: application/json\r\nContent-Length: 200000000\r\nX-Real-IP: 203.0.113.7\r\nCookie: premier_session=${sessions.get('freeuser')}`);
    assert.match(big, /^HTTP\/1\.1 413 /); // без чтения 200 МБ в память
    await alive();
  });
});
