# Запуск Premier на сервере

Ниже — безопасная установка на VPS с Ubuntu 22.04/24.04 или Debian 12. Всё, кроме Python-песочницы, делает один скрипт.

## Перед началом
- Домен с A-записью на IP сервера (например, `example.ru`).
- Доступ к серверу по SSH с правами sudo.
- Папка проекта на сервере, например `~/premier-app`.

## Установка одной командой
```
cd ~/premier-app
sudo bash deploy/install.sh example.ru
```
Скрипт:
1. ставит Node.js 22 (если нет или версия старше 22.13);
2. создаёт пользователя `premier` — без пароля, SSH и sudo; сервис работает от него, а не от root;
3. копирует проект в `/opt/premier` (код принадлежит root и доступен сервису только на чтение, писать можно только в `data/`);
4. создаёт `/etc/premier/premier.env` — пароль панели и ключи (читают только root и сервис);
5. запускает сервис `premier` через systemd с ограничениями (без повышения прав, без записи в систему) и автоперезапуском;
6. ставит Caddy — HTTPS-сертификат получается и продлевается сам;
7. включает фаервол: снаружи открыты только SSH, 80 и 443; порт 3000 закрыт, Node слушает только `127.0.0.1`;
8. включает ежедневный бэкап `data/` в 04:00 (снимок базы делается на ходу, без остановки сервиса).

Пароль панели install.sh создаёт сам и печатает в конце установки (строка «Пароль панели /panelp»). Он же — в `/etc/premier/premier.env`.

Если на сервере уже была папка `data/` (пользователи, оплаты) — она переносится в `/opt/premier/data`.

## После установки
- Откройте `/etc/premier/premier.env` (`sudo nano /etc/premier/premier.env`), впишите ключи Platega, затем `sudo systemctl restart premier`.
- **Если ключи Platega уже вводили в панели**, они лежат в базе (настройки панели). После переноса в `premier.env` очистите поля Platega в панели и перезапустите сервис. Тогда секрет не попадёт в бэкапы.
- Логи: `sudo journalctl -u premier -f`. Неудачные входы в панель видны как «Панель: неверный пароль с …».
- Обновление кода: загрузите новую версию в `~/premier-app` и снова запустите `sudo bash deploy/install.sh example.ru` — данные и настройки сохранятся.

## Вариант с nginx
Если на сервере уже есть nginx — вместо Caddy возьмите `deploy/nginx.conf`, затем `sudo certbot --nginx -d example.ru`. Важно оставить строку `proxy_set_header X-Real-IP $remote_addr;` и `proxy_buffering off;`.

## Проверка Chromium после обновления

Sandbox теперь включён по умолчанию. Проверяйте запуск от пользователя сервиса `premier`, не от root:
панель → «Инструменты» → «Проверить браузер», затем чтение страницы и самопроверку сайта.
При ошибке смотрите `sudo journalctl -u premier -n 100`: проверьте `CHROMIUM_PATH`,
наличие библиотек, поддержку user namespaces и политики AppArmor на вашей ОС.
Не отключайте `NoNewPrivileges` или другие ограничения systemd просто ради запуска.

Сетевые запросы Chromium теперь идут через локальный авторизованный прокси с проверкой
IP в момент соединения. Разрешены только порты 80/443; нестандартные порты и `ws://`
не поддерживаются. Это намеренное ограничение; интерфейс и API приложения не меняются.

`BROWSER_NO_SANDBOX=1` в `premier.env` отключает sandbox явно и пишет предупреждение.
Это **не рекомендуемое исправление ошибки запуска**: такой режим допустим только
при дополнительной изоляции браузера в отдельно защищённом окружении.
Сетевой прокси не защищает сервер от уязвимостей самого Chromium; обновляйте браузер
и ограничивайте исходящую сеть средствами ОС/контейнера.

## Шаг 6. Python-песочница через rootless Docker
Обычный Docker даёт тому, кто им управляет, права root на всём сервере. Если Premier взломают — получат и сервер. Rootless Docker работает от пользователя `premier`, и при взломе злоумышленник остаётся обычным пользователем.

```
# 1. Пакеты
sudo apt-get install -y uidmap dbus-user-session docker-ce-rootless-extras || sudo apt-get install -y uidmap dbus-user-session rootlesskit
# (если Docker не установлен: curl -fsSL https://get.docker.com | sudo sh)

# 2. Убедиться, что premier НЕ в группе docker
sudo gpasswd -d premier docker 2>/dev/null || true

# 3. Включить rootless Docker для premier
sudo loginctl enable-linger premier
sudo -iu premier bash -c 'dockerd-rootless-setuptool.sh install && systemctl --user enable --now docker'

# 4. Собрать образ песочницы от имени premier
sudo -iu premier bash -c 'export DOCKER_HOST=unix:///run/user/$(id -u)/docker.sock; docker build -t premier-python /opt/premier/sandbox'

# 5. Указать сервису путь к Docker
echo "DOCKER_HOST=unix:///run/user/$(id -u premier)/docker.sock" | sudo tee -a /etc/premier/premier.env
sudo systemctl restart premier
```
Проверка: панель → «Инструменты» → Python → «Проверить».

Если Python не нужен — добавьте `CODE_RUNNER=off` в `premier.env`, и Docker не понадобится вовсе.

## Вход через Google

1. console.cloud.google.com → **Google Auth Platform** → **Clients** → ваш клиент (Web application).
2. **Authorized JavaScript origins:** `https://ide.kgpix.bond`
   **Authorized redirect URIs:** `https://ide.kgpix.bond/api/auth/google/callback` — без этого Google выдаст `redirect_uri_mismatch`.
3. В `/etc/premier/premier.env`:
   ```
   PUBLIC_URL=https://ide.kgpix.bond
   GOOGLE_CLIENT_ID=...apps.googleusercontent.com
   GOOGLE_CLIENT_SECRET=GOCSPX-...
   ```
   и `sudo systemctl restart premier`. На странице входа появится кнопка «Войти через Google».
4. **Audience:** пока приложение в режиме Testing, войти могут только Test users. Для всех — **Publish app**
   (для scope `email profile` проверка Google не нужна).

Как работает: новый пользователь получает логин из почты (`ivan.petrov`, при совпадении — `ivan.petrov2`), имя из Google
и пробный Pro (с тем же ограничением по IP). Входа по логину и паролю нет — только Google или GitHub.
Если регистрация закрыта в панели, войти могут только существующие пользователи и те, кого администратор
добавил в панели по почте («Пользователи → Создать аккаунт»).

## Вход через GitHub

1. github.com → **Settings → Developer settings → OAuth Apps → New OAuth App**
   (для организации: настройки организации → Developer settings → OAuth Apps).
2. **Homepage URL:** `https://ide.kgpix.bond`
   **Authorization callback URL:** `https://ide.kgpix.bond/api/auth/github/callback` — иначе GitHub выдаст ошибку `redirect_uri`.
3. **Register application** → скопируйте **Client ID**, нажмите **Generate a new client secret**.
4. В `/etc/premier/premier.env`:
   ```
   GITHUB_CLIENT_ID=Ov23li...
   GITHUB_CLIENT_SECRET=...
   ```
   и `sudo systemctl restart premier`. На странице входа появится кнопка «Продолжить с GitHub».

Как работает: Premier просит у GitHub только профиль и почту (`read:user user:email`), к репозиториям доступа нет.
- Нужна **подтверждённая почта** в GitHub (Settings → Emails). Если её нет, пользователь увидит подсказку, как её подтвердить.
- Если аккаунт с той же почтой уже есть (вошёл через Google или создан в панели), GitHub привяжется к нему — это один аккаунт с одними чатами и тарифом, войти можно и так и так.
- Новый пользователь получает логин из GitHub (`octocat`, при совпадении — `octocat2`), имя и пробный Pro, как при входе через Google.
- Кнопки показываются только для настроенных способов. Если не настроен ни один — страница входа подскажет, что добавить ключи.

## Мониторинг и оповещения
1. Создайте бота у [@BotFather](https://t.me/BotFather) и напишите ему любое сообщение.
2. Откройте `https://api.telegram.org/bot<ТОКЕН>/getUpdates` и найдите `"chat":{"id":…}`.
3. В `/etc/premier/premier.env` добавьте `ALERT_TELEGRAM_TOKEN=<токен>` и `ALERT_TELEGRAM_CHAT=<id>`, затем `sudo systemctl restart premier`.

Придут: ошибки в коде сервера, падения процесса, «сайт не отвечает 2 минуты — перезапускаю» и «снова работает» (это проверяет `premier-health.timer` раз в минуту — он работает отдельно от сервера, поэтому сообщит и о зависании).
Журнал ошибок — в `/panelp → Обзор`. Для внешнего монитора (UptimeRobot и т. п.) используйте `https://ваш-домен/healthz`.

Если Premier был установлен раньше, включите проверку вручную:
```
sudo chmod +x /opt/premier/deploy/healthcheck.sh
sudo cp /opt/premier/deploy/premier-health.* /etc/systemd/system/ && sudo systemctl daemon-reload && sudo systemctl enable --now premier-health.timer
```

## Бэкапы
- Хранятся в `/var/backups/premier`, последние 14 копий.
- Чтобы копировать на другой сервер, раскомментируйте `Environment=BACKUP_REMOTE=…` в `/etc/systemd/system/premier-backup.service` (нужен SSH-ключ root на тот сервер), затем `sudo systemctl daemon-reload`.
- Сделать бэкап сейчас: `sudo systemctl start premier-backup`.
- Восстановить: `sudo systemctl stop premier && sudo rm -f /opt/premier/data/premier.db-wal /opt/premier/data/premier.db-shm && sudo tar -xzf /var/backups/premier/premier-ДАТА.tar.gz -C /opt/premier && sudo chown -R premier:premier /opt/premier/data && sudo systemctl start premier`.
