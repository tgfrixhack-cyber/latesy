// Premier — клиент: archives (общие переменные — в 01-core.js; файлы подключаются по порядку в chat.html)
/* ---------- архивы: ZIP и TAR.GZ прямо в браузере ---------- */
function packRoot(files, src) {
  const firsts = new Set(files.map((f) => f.path.includes('/') ? f.path.split('/')[0] : ''));
  if (files.length && firsts.size === 1 && !firsts.has('')) return { root: [...firsts][0], prefix: '' };
  const en = entryOf(files), t = en ? artTitle(en.code) : '';
  const slug = (t && t !== 'Сайт' ? t : 'project').toLowerCase().replace(/[«»"'.,!?:;()]/g, '').trim().replace(/\s+/g, '-').replace(/[^\wа-яё-]/gi, '').slice(0, 40) || 'project';
  return { root: slug, prefix: slug + '/' };
}
const CRC = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
const crc32 = (d) => { let c = 0xffffffff; for (let i = 0; i < d.length; i++) c = CRC[(c ^ d[i]) & 255] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; };
async function squeeze(data, fmt) {
  try { return new Uint8Array(await new Response(new Blob([data]).stream().pipeThrough(new CompressionStream(fmt))).arrayBuffer()); } catch { return null; }
}
async function makeZip(entries) {
  const enc = new TextEncoder(), parts = [], central = []; let off = 0;
  const d = new Date(), time = (d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1), date = ((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate();
  for (const e of entries) {
    const name = enc.encode(e.name), data = e.data instanceof Uint8Array ? e.data : enc.encode(e.code), crc = crc32(data);
    const def = await squeeze(data, 'deflate-raw'), useDef = def && def.length < data.length, body = useDef ? def : data;
    const h = new DataView(new ArrayBuffer(30));
    h.setUint32(0, 0x04034b50, true); h.setUint16(4, 20, true); h.setUint16(6, 0x0800, true); h.setUint16(8, useDef ? 8 : 0, true);
    h.setUint16(10, time, true); h.setUint16(12, date, true); h.setUint32(14, crc, true); h.setUint32(18, body.length, true); h.setUint32(22, data.length, true); h.setUint16(26, name.length, true);
    const c = new DataView(new ArrayBuffer(46));
    c.setUint32(0, 0x02014b50, true); c.setUint16(4, 20, true); c.setUint16(6, 20, true); c.setUint16(8, 0x0800, true); c.setUint16(10, useDef ? 8 : 0, true);
    c.setUint16(12, time, true); c.setUint16(14, date, true); c.setUint32(16, crc, true); c.setUint32(20, body.length, true); c.setUint32(24, data.length, true); c.setUint16(28, name.length, true); c.setUint32(42, off, true);
    parts.push(h, name, body); central.push(c, name); off += 30 + name.length + body.length;
  }
  const csize = central.reduce((n, x) => n + x.byteLength, 0), end = new DataView(new ArrayBuffer(22));
  end.setUint32(0, 0x06054b50, true); end.setUint16(8, entries.length, true); end.setUint16(10, entries.length, true); end.setUint32(12, csize, true); end.setUint32(16, off, true);
  return new Blob([...parts, ...central, end], { type: 'application/zip' });
}
async function makeTgz(entries) {
  const enc = new TextEncoder(), chunks = [];
  for (const e of entries) {
    const data = e.data instanceof Uint8Array ? e.data : enc.encode(e.code), h = new Uint8Array(512); let name = enc.encode(e.name), prefix = new Uint8Array(0);
    if (name.length > 100) { const i = e.name.lastIndexOf('/', e.name.length - 1); prefix = enc.encode(e.name.slice(0, i)); name = enc.encode(e.name.slice(i + 1)); }
    const put = (str, at, len) => h.set(typeof str === 'string' ? enc.encode(str).slice(0, len) : str.slice(0, len), at);
    put(name, 0, 100); put('0000644\0', 100, 8); put('0000000\0', 108, 8); put('0000000\0', 116, 8);
    put(data.length.toString(8).padStart(11, '0') + '\0', 124, 12); put(Math.floor(Date.now() / 1000).toString(8).padStart(11, '0') + '\0', 136, 12);
    put('        ', 148, 8); put('0', 156, 1); put('ustar\0', 257, 6); put('00', 263, 2); put(prefix, 345, 155);
    put(h.reduce((a, b) => a + b, 0).toString(8).padStart(6, '0') + '\0 ', 148, 8);
    chunks.push(h, data, new Uint8Array((512 - (data.length % 512)) % 512));
  }
  chunks.push(new Uint8Array(1024));
  const gz = await squeeze(new Blob(chunks), 'gzip');
  return gz ? new Blob([gz], { type: 'application/gzip' }) : new Blob(chunks, { type: 'application/x-tar' });
}
function saveBlob(blob, name) { const u = URL.createObjectURL(blob), l = document.createElement('a'); l.href = u; l.download = name; document.body.appendChild(l); l.click(); l.remove(); setTimeout(() => URL.revokeObjectURL(u), 5000); }
async function downloadPack(mid, fmt) {
  const src = findMsg(mid)?.t || ''; let files = getFiles(src);
  if (!files.length) files = PremierArtifact.latest(src)?.files || []; if (!files.length) return;
  const { root, prefix } = packRoot(files, src);
  try { const entries = await PremierAssets.entries(files.map(f => ({ name: prefix + f.path, code: f.code })), root); const blob = fmt === 'tgz' ? await makeTgz(entries) : await makeZip(entries); saveBlob(blob, root + (fmt === 'tgz' ? (blob.type === 'application/gzip' ? '.tar.gz' : '.tar') : '.zip')); }
  catch (e) { toast('Не удалось собрать архив: ' + e.message); }
}
// inline: `код`, **жирный**, *курсив*, ~~зачёркнутый~~, [ссылка](url), голые https://…, экранирование \*.
// Код, ссылки и экранированные символы прячем в заглушки, чтобы * и _ внутри них не стали разметкой.
// Длина выделения ограничена: иначе длинная строка с одиночными * разбирается за квадратичное время.
const emph = (s) => s.length > 20000 ? s : s
  .replace(/\*\*\*(?=\S)(.{1,1000}?)(?<=\S)\*\*\*/g, '<strong><em>$1</em></strong>')
  .replace(/\*\*(?=\S)(.{1,1000}?)(?<=\S)\*\*/g, '<strong>$1</strong>')
  .replace(/(?<![\p{L}\p{N}_])__(?=\S)(.{1,1000}?)(?<=\S)__(?![\p{L}\p{N}_])/gu, '<strong>$1</strong>')
  .replace(/\*(?=[^\s*])(.{1,1000}?)(?<=[^\s*])\*/g, '<em>$1</em>')
  .replace(/(?<![\p{L}\p{N}_])_(?=[^\s_])(.{1,1000}?)(?<=[^\s_])_(?![\p{L}\p{N}_])/gu, '<em>$1</em>')
  .replace(/~~(?=\S)(.{1,1000}?)(?<=\S)~~/g, '<del>$1</del>');
const URL_RE = /https?:\/\/(?:[^\s()<\u0001]|\([^\s()<\u0001]*\))+/g;
const linkTo = (url, html) => `<a href="${url}" target="_blank" rel="noopener">${html}</a>`;
// хвостовая пунктуация и закрывающая скобка без пары — не часть адреса
function urlEnd(u) {
  for (let m; (m = u.match(/(?:&quot;|&gt;|&lt;|&#39;|&amp;|[.,;:!?'*_~\]])$/) || (u.endsWith(')') && (u.match(/\(/g) || []).length < (u.match(/\)/g) || []).length && [')']));) u = u.slice(0, -m[0].length);
  return u;
}
function inline(t) {
  const keep = [], put = (html) => `\u0001${keep.push(html) - 1}\u0001`;
  let s = esc(String(t).replace(/\u0001/g, ''))
    .replace(/`([^`]+)`/g, (_, c) => put(`<code>${c}</code>`))
    .replace(/\\([\\`*_{}[\]()#+\-.!|~])/g, (_, c) => put(c))
    .replace(/(!?)\[([^\]]*)\]\((https?:\/\/(?:[^\s()]|\([^\s()]*\))+)\)/g, (_, img, txt, url) => put(linkTo(url, txt ? emph(txt) : url)))
    .replace(URL_RE, (u) => { const v = urlEnd(u); return put(linkTo(v, v)) + u.slice(v.length); });
  s = emph(s);
  while (/\u0001\d+\u0001/.test(s)) s = s.replace(/\u0001(\d+)\u0001/g, (_, i) => keep[i]);
  return s;
}
// таблицы Markdown: | a | b | + строка-разделитель |---|:---:|; крайние | необязательны
const cells = (l) => l.trim().replace(/^\|/, '').replace(/(?<!\\)\|$/, '').split(/(?<!\\)\|/).map((c) => c.trim().replace(/\\\|/g, '|'));
const pipes = (l) => /(?<!\\)\|/.test(l || '');
const isRow = (l) => /^\s*\|.*\|\s*$/.test(l || '');
const isSep = (l) => /^\s*\|?\s*:?-+:?\s*(\|\s*:?-+:?\s*)*\|?\s*$/.test(l || '');
const tableAt = (lines, i) => pipes(lines[i]) && isSep(lines[i + 1]) && (pipes(lines[i + 1]) || isRow(lines[i])) && cells(lines[i]).length === cells(lines[i + 1]).length;
function table(rows) {
  const al = cells(rows[1]).map((c) => (/^:-+:$/.test(c) ? 'center' : /-+:$/.test(c) ? 'right' : ''));
  const row = (r) => { const c = cells(r); return al.map((_, i) => c[i] ?? ''); };
  // модели часто переносят строки внутри ячейки тегом <br>
  const td = (tag, c, i) => `<${tag}${al[i] ? ` style="text-align:${al[i]}"` : ''}>${inline(c).replace(/&lt;br\s*\/?&gt;/gi, '<br>')}</${tag}>`;
  return `<div class="tbl"><table><thead><tr>${row(rows[0]).map((c, i) => td('th', c, i)).join('')}</tr></thead><tbody>${rows.slice(2).map((r) => `<tr>${row(r).map((c, i) => td('td', c, i)).join('')}</tr>`).join('')}</tbody></table></div>`;
}
// псевдографика (рамки, схемы, полоски ███░░) вне ``` — показываем моноширинно, с пробелами как есть
const BOX = /[\u2500-\u259f]/g;
const LI = /^(\s*)(?:([-*+])|(\d+)[.)])\s+(.*)/;
const isArt = (l) => !!l && !LI.test(l) && ((l.match(BOX) || []).length >= 3 || /^\s*[\u2500-\u259f]/.test(l));
const indent = (l) => l.match(/^[ \t]*/)[0].replace(/\t/g, '    ').length;
function block(t, depth = 0) {
  let h = ''; const stack = []; // открытые списки: { tag, ind }
  const pop = () => { h += `</li></${stack.pop().tag}>`; };
  const close = () => { while (stack.length) pop(); };
  const item = (tag, ind, num, text) => {
    while (stack.length && stack[stack.length - 1].ind > ind + 1) pop();
    const top = stack[stack.length - 1];
    if (top && Math.abs(top.ind - ind) <= 1 && top.tag === tag) h += '</li><li>';
    else {
      if (top && Math.abs(top.ind - ind) <= 1) pop();
      h += `<${tag}${tag === 'ol' && num !== 1 ? ` start="${num}"` : ''}><li>`; stack.push({ tag, ind });
    }
    h += inline(text);
  };
  const lines = t.split('\n');
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i]; let m;
    if (tableAt(lines, i)) { close(); const rows = [line, lines[i + 1]]; i += 2; while (i < lines.length && lines[i].trim() && pipes(lines[i])) rows.push(lines[i++]); i--; h += table(rows); continue; }
    if (/^\s*>/.test(line) && depth < 8) {
      close(); const rows = [];
      while (i < lines.length && /^\s*>/.test(lines[i])) rows.push(lines[i++].replace(/^\s*>\s?/, ''));
      i--; h += `<blockquote>${block(rows.join('\n'), depth + 1)}</blockquote>`; continue;
    }
    if (isArt(line)) {
      close(); const rows = [line];
      while (i + 1 < lines.length && (isArt(lines[i + 1]) || (lines[i + 1].trim() && !LI.test(lines[i + 1]) && isArt(lines[i + 2])))) rows.push(lines[++i]);
      h += `<pre class="txtart">${esc(rows.join('\n').replace(/\s+$/, ''))}</pre>`; continue;
    }
    if (!line.trim() || /^\s*([-*+]|\d+[.)])\s*$/.test(line)) {
      // пустая строка между пунктами не рвёт список (иначе нумерация начинается заново)
      if (stack.length) { let j = i + 1; while (j < lines.length && !lines[j].trim()) j++; if (LI.test(lines[j] || '')) continue; }
      close(); continue;
    }
    if (/^\s{0,3}([-*_])(\s*\1){2,}\s*$/.test(line)) { close(); h += '<hr>'; }
    else if ((m = line.match(/^\s{0,3}(#{1,6})[ \t]+(.*)$/))) { close(); const tag = 'h' + Math.min(m[1].length + 1, 6); h += `<${tag}>${inline(m[2].trimEnd().replace(/(^|[ \t])#+$/, '').trimEnd())}</${tag}>`; }
    else if ((m = line.match(LI))) item(m[2] ? 'ul' : 'ol', indent(line), +m[3], m[4]);
    else if (stack.length && indent(line) >= 2) h += '<br>' + inline(line.trim());
    else { close(); h += `<p>${inline(line)}</p>`; }
  }
  close(); return h;
}
