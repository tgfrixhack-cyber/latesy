'use strict';
// Варианты ответов вместо удаления: перегенерация, правка, переключение, сохранение, EN. Нужны Playwright и Chromium.
const test = require('node:test'), assert = require('node:assert/strict'), fs = require('fs');
const { copyApp, seed, startServer, rm } = require('./helpers');

const HTML = '```html\n<!doctype html><html><head><title>Сцена</title></head><body>Первая сцена</body></html>\n```';
const PREV = 'Предыдущий вариант', NEXT = 'Следующий вариант';

test('чат в Chromium: варианты ответов и правка сообщений без потери истории', { timeout: 120000 }, async (t) => {
  const { chromium } = require('playwright');
  const dir = copyApp(); seed(dir);
  fs.writeFileSync(dir + '/data/models.json', JSON.stringify([{ id: 'm1', name: 'UI Mock', modelId: 'mock', baseUrl: 'http://127.0.0.1:1', apiKey: 'test' }]));
  const s = await startServer(dir);
  const b = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH, chromiumSandbox: true });
  t.after(async () => { await b.close(); await s.stop(); rm(dir); });
  const context = await b.newContext();
  await context.addCookies([{ name: 'premier_session', value: 'tok1', url: s.base }]);
  const page = await context.newPage();
  const errors = [], chatReqs = [], syncBodies = [];
  page.setDefaultTimeout(10000);
  page.on('pageerror', (e) => errors.push(e.message));
  page.on('request', (r) => { if (r.method() === 'POST' && new URL(r.url()).pathname === '/api/sync') syncBodies.push(r.postData()); });
  let mode = 'ok', n = 0, hold = null;
  await context.route('**/*', async (route) => {
    const url = new URL(route.request().url());
    if (url.origin !== s.base) return route.abort();
    if (url.pathname !== '/api/chat') return route.continue();
    chatReqs.push(route.request().postData());
    if (hold) await hold;
    const events = mode === 'err' ? [{ e: 'Сбой модели' }, { diag: { outcome: 'error' } }]
      : mode === 'html' ? [{ t: HTML }, { diag: { outcome: 'complete' } }]
      : [{ t: 'Ответ ' + (++n) }, { diag: { outcome: 'complete' } }];
    await route.fulfill({ status: 200, contentType: 'application/x-ndjson', body: events.map((e) => JSON.stringify(e)).join('\n') + '\n' });
  });
  const idle = () => page.waitForFunction(() => !busyMap.size && !cur()?.msgs.some((m) => m.live));
  const ask = async (text) => { await page.evaluate((x) => send(x), text); await idle(); };
  const texts = () => page.evaluate(() => cur().msgs.map((m) => m.t));
  const nav = (label) => page.locator(`#col [aria-label="${label}"]`);
  const counts = () => page.locator('#col .vnav .vc').allInnerTexts();
  const until = async (fn) => { for (let i = 0; i < 100; i++) { if (await fn()) return true; await new Promise((r) => setTimeout(r, 100)); } return false; };

  await page.goto(s.base + '/chat');
  await page.waitForFunction(() => MODELS.length > 0);
  await page.evaluate(() => { window.__clip = []; Object.defineProperty(navigator, 'clipboard', { value: { writeText: async (x) => { __clip.push(x); } }, configurable: true }); });

  // 1. перегенерация сохраняет первый ответ как вариант вместе с хвостом
  await ask('вопрос 1'); await ask('вопрос 2');
  assert.deepEqual(await texts(), ['вопрос 1', 'Ответ 1', 'вопрос 2', 'Ответ 2']);
  const chatId = await page.evaluate(() => cur().id), oldId = await page.evaluate(() => cur().msgs[1].id);
  assert.deepEqual(await counts(), []);
  await page.locator('[data-redo="1"]').click(); await idle();
  assert.deepEqual(await texts(), ['вопрос 1', 'Ответ 3']);
  assert.deepEqual(await counts(), ['2/2']);
  const st = await page.evaluate(() => { const m = cur().msgs[1]; return { vi: m.vi, n: m.vers.length, active: m.vers[1], old: m.vers[0].m.t, tail: m.vers[0].tail.map((x) => x.t), leak: 'vers' in m.vers[0].m || 'vi' in m.vers[0].m, id: m.id }; });
  assert.deepEqual({ vi: st.vi, n: st.n, active: st.active, old: st.old, tail: st.tail, leak: st.leak }, { vi: 1, n: 2, active: null, old: 'Ответ 1', tail: ['вопрос 2', 'Ответ 2'], leak: false });
  assert.notEqual(st.id, oldId);
  assert.equal(await nav(NEXT).isDisabled(), true);
  await nav(PREV).click();
  assert.deepEqual(await texts(), ['вопрос 1', 'Ответ 1', 'вопрос 2', 'Ответ 2']);
  assert.deepEqual(await counts(), ['1/2']);
  assert.match(await page.locator('#col').innerText(), /Ответ 2/);
  assert.equal(await page.evaluate(() => cur().msgs[1].id), oldId);
  // индексы действий после переключения указывают на нужные сообщения
  await page.locator('[data-copy="3"]').click();
  assert.equal(await page.evaluate(() => __clip.at(-1)), 'Ответ 2');
  await page.locator('[data-edit="2"]').click();
  assert.equal(await page.locator('#q').inputValue(), 'вопрос 2');
  await page.keyboard.press('Escape');
  await nav(NEXT).click();
  assert.deepEqual(await texts(), ['вопрос 1', 'Ответ 3']);

  // 2. правка → отмена ничего не меняет (кнопка, Esc, смена чата)
  const before = await page.evaluate(() => JSON.stringify(cur().msgs));
  await page.locator('[data-edit="0"]').click();
  assert.equal(await page.locator('#editBar').isVisible(), true);
  assert.match(await page.locator('#editBar').innerText(), /Редактирование сообщения[\s\S]*Отмена/);
  assert.equal(await page.locator('#q').inputValue(), 'вопрос 1');
  assert.equal(await page.evaluate(() => JSON.stringify(cur().msgs)), before);
  await page.locator('#editBar [data-edit-cancel]').click();
  assert.equal(await page.locator('#editBar').isVisible(), false);
  assert.equal(await page.locator('#q').inputValue(), '');
  assert.equal(await page.evaluate(() => JSON.stringify(cur().msgs)), before);
  await page.locator('[data-edit="0"]').click(); await page.keyboard.press('Escape');
  assert.equal(await page.locator('#editBar').isVisible(), false);
  assert.equal(await page.locator('#q').inputValue(), '');
  await page.locator('[data-edit="0"]').click(); await page.locator('#newChat').click();
  assert.equal(await page.locator('#editBar').isVisible(), false);
  assert.equal(await page.locator('#q').inputValue(), '');
  await page.locator('#chats .item', { hasText: 'вопрос 1' }).click();
  await page.waitForFunction((id) => S.cur === id, chatId);
  assert.equal(await page.evaluate(() => JSON.stringify(cur().msgs)), before);

  // 3. правка → отправка: старое сообщение с хвостом становится вариантом пользовательского сообщения
  await page.locator('[data-edit="0"]').click();
  await page.locator('#q').fill('вопрос 1 (правка)'); await page.keyboard.press('Enter'); await idle();
  assert.deepEqual(await texts(), ['вопрос 1 (правка)', 'Ответ 4']);
  assert.equal(await page.locator('#editBar').isVisible(), false);
  assert.deepEqual(await counts(), ['2/2']);
  const u = await page.evaluate(() => { const m = cur().msgs[0]; return { vi: m.vi, n: m.vers.length, old: m.vers[0].m.t, tail: m.vers[0].tail.map((x) => x.t), nested: m.vers[0].tail[0].vers?.length }; });
  assert.deepEqual(u, { vi: 1, n: 2, old: 'вопрос 1', tail: ['Ответ 3'], nested: 2 });
  await nav(PREV).first().click();
  assert.deepEqual(await texts(), ['вопрос 1', 'Ответ 3']);
  assert.deepEqual(await counts(), ['1/2', '2/2']);
  await nav(PREV).last().click();
  assert.deepEqual(await texts(), ['вопрос 1', 'Ответ 1', 'вопрос 2', 'Ответ 2']);
  await nav(NEXT).last().click(); await nav(NEXT).first().click();
  assert.deepEqual(await texts(), ['вопрос 1 (правка)', 'Ответ 4']);

  // 4. во время генерации переключение отключено
  let release; hold = new Promise((r) => (release = r));
  await page.evaluate(() => send('вопрос 3'));
  await page.waitForFunction(() => busyMap.size > 0);
  assert.equal(await page.locator('#col .vnav button:not([disabled])').count(), 0);
  assert.equal(await page.evaluate(() => { const x = JSON.stringify(cur().msgs); switchVer(cur(), 0, -1); return x === JSON.stringify(cur().msgs); }), true);
  hold = null; release(); await idle();
  assert.deepEqual(await texts(), ['вопрос 1 (правка)', 'Ответ 4', 'вопрос 3', 'Ответ 5']);

  // 5. ошибочный ответ заменяется без лишнего варианта, но уже накопленные варианты сохраняются
  await page.locator('#newChat').click();
  mode = 'err'; await ask('ошибка?');
  assert.equal(await page.evaluate(() => !!cur().msgs[1].err), true);
  mode = 'ok'; await page.locator('[data-redo="1"]').click(); await idle();
  assert.equal(await page.evaluate(() => cur().msgs.length === 2 && cur().msgs[1].vers === undefined && !cur().msgs[1].err), true);
  await page.locator('[data-redo="1"]').click(); await idle();
  mode = 'err'; await page.locator('[data-redo="1"]').click(); await idle();
  assert.equal(await page.evaluate(() => !!cur().msgs[1].err && cur().msgs[1].vers.length === 3), true);
  mode = 'ok'; await page.locator('[data-redo="1"]').click(); await idle();
  const er = await page.evaluate(() => { const m = cur().msgs[1]; return { n: m.vers.length, vi: m.vi, err: !!m.err, kept: m.vers[0].m.t, t: m.t }; });
  assert.deepEqual(er, { n: 3, vi: 2, err: false, kept: er.kept, t: er.t });
  assert.match(er.kept, /^Ответ \d+$/);

  // 6. панель артефакта закрывается, когда её сообщение уходит из чата
  await page.locator('#newChat').click();
  mode = 'html'; await ask('сделай сайт');
  await page.locator('.art').click();
  await page.waitForFunction(() => A.open && document.querySelector('#pFrame')?.srcdoc.includes('Первая сцена'));
  mode = 'ok'; await page.locator('[data-redo="1"]').click(); await idle();
  assert.equal(await page.evaluate(() => A.open), false);
  await nav(PREV).click();
  assert.equal(await page.locator('.art').count(), 1);
  await page.locator('.art').click();
  await page.waitForFunction(() => A.open && $('pane').classList.contains('on'));
  await nav(NEXT).click();
  assert.equal(await page.evaluate(() => A.open), false);
  assert.equal(await page.evaluate(() => $('pane').classList.contains('on')), false);

  // 7. варианты уходят на сервер и переживают перезагрузку, но не попадают в запросы к модели
  assert.ok(await until(() => syncBodies.some((x) => JSON.parse(x).put.some((c) => c.id === chatId && c.msgs[0].vers?.length === 2))), 'sync payload without versions');
  const srv = (await s.req('GET', '/api/sync?since=0', { token: 'tok1' })).json.chats.find((c) => c.id === chatId);
  assert.equal(srv.data.msgs[0].vers[0].m.t, 'вопрос 1');
  assert.ok(chatReqs.length >= 8);
  for (const body of chatReqs) assert.doesNotMatch(body, /"vers"|"vi"/);
  await page.reload(); await page.waitForFunction(() => MODELS.length > 0);
  const kept = await page.evaluate((id) => { const m = S.chats.find((c) => c.id === id).msgs[0]; return { vi: m.vi, old: m.vers[0].m.t, nested: m.vers[0].tail[0].vers.length }; }, chatId);
  assert.deepEqual(kept, { vi: 1, old: 'вопрос 1', nested: 2 });
  await page.locator('#chats .item', { hasText: 'вопрос 1' }).click();
  await page.waitForFunction((id) => S.cur === id, chatId);
  assert.deepEqual(await counts(), ['2/2']);
  const ctx2 = await b.newContext(); await ctx2.addCookies([{ name: 'premier_session', value: 'tok1', url: s.base }]);
  const page2 = await ctx2.newPage(); await ctx2.route('**/*', (r) => (new URL(r.request().url()).origin === s.base ? r.continue() : r.abort()));
  await page2.goto(s.base + '/chat');
  await page2.waitForFunction((id) => S.chats.find((c) => c.id === id)?.msgs[0].vers?.length === 2, chatId);
  await ctx2.close();

  // 8. лимиты: 10 вариантов на сообщение, размер чата, нехватка места в localStorage
  const cap = await page.evaluate(() => {
    const c = { id: 'cap', title: 'cap', msgs: [{ id: 'x1', r: 'u', t: 'q' }, { id: 'x2', r: 'a', t: 'v' }] };
    for (let k = 0; k < 12; k++) branch(c, 1, { id: 'n' + k, r: 'a', t: 'v' + k });
    const m = c.msgs[1]; return { n: m.vers.length, vi: m.vi, first: m.vers[0].m.t, prev: m.vers[8].m.t, active: m.vers[m.vi], t: m.t };
  });
  assert.deepEqual(cap, { n: 10, vi: 9, first: 'v2', prev: 'v10', active: null, t: 'v11' });
  const big = await page.evaluate(() => {
    const c = { id: 'big', title: 'big', msgs: [{ id: 'y1', r: 'u', t: 'q' }, { id: 'y2', r: 'a', t: 'x'.repeat(1e6) }] };
    for (let k = 0; k < 8; k++) branch(c, 1, { id: 'b' + k, r: 'a', t: String(k).repeat(1e6) });
    return { len: clean(c).length, n: c.msgs[1].vers.length };
  });
  assert.ok(big.len <= 6e6 && big.n >= 2 && big.n < 9, JSON.stringify(big));
  const shed = await page.evaluate(() => {
    const orig = Storage.prototype.setItem;
    try {
      Storage.prototype.setItem = function (k, v) { if (v.length > 2.5e6) throw new DOMException('quota', 'QuotaExceededError'); return orig.call(this, k, v); };
      const c = { id: 'shed', title: 'shed', msgs: [{ id: 'z1', r: 'u', t: 'q' }, { id: 'z2', r: 'a', t: 'x'.repeat(5e5) }] };
      for (let k = 0; k < 4; k++) branch(c, 1, { id: 's' + k, r: 'a', t: 'y'.repeat(1e6) });
      S.chats.push(c); persistLocal();
      return { stored: localStorage.getItem(KEY).length, n: c.msgs[1].vers.length, toast: $('toast').textContent };
    } finally { Storage.prototype.setItem = orig; S.chats = S.chats.filter((x) => x.id !== 'shed'); }
  });
  assert.ok(shed.stored > 0 && shed.stored <= 2.5e6 && shed.n < 5, JSON.stringify(shed));
  assert.match(shed.toast, /самые старые варианты/);

  // 9. английская версия: подписи и плашка правки
  await page.goto(s.base + '/chat?lang=en'); await page.waitForFunction(() => MODELS.length > 0);
  assert.equal(await page.evaluate(() => [...document.scripts].some((x) => x.src.includes('/en/js/05-chat.js'))), true);
  await page.locator('#chats .item', { hasText: 'вопрос 1' }).click();
  await page.waitForFunction((id) => S.cur === id, chatId);
  assert.equal(await page.locator('#col [aria-label="Previous version"]').count(), 1);
  assert.equal(await page.locator('#col [aria-label="Next version"]').count(), 1);
  await page.locator('[data-edit="0"]').click();
  assert.match(await page.locator('#editBar').innerText(), /Editing message[\s\S]*Cancel/);
  await page.keyboard.press('Escape');
  assert.equal(await page.locator('#editBar').isVisible(), false);
  await page.locator('#newChat').click();
  await page.evaluate(() => send('question'));
  await page.waitForFunction(() => !busyMap.size && cur()?.msgs.length === 2);
  await page.locator('[data-redo="1"]').click();
  await page.waitForFunction(() => !busyMap.size && cur().msgs[1].vers?.length === 2);
  assert.deepEqual(await page.locator('#col .vnav .vc').allInnerTexts(), ['2/2']);
  const old = await page.evaluate(() => cur().msgs[1].vers[0].m.t);
  await page.locator('#col [aria-label="Previous version"]').click();
  assert.equal(await page.evaluate(() => cur().msgs[1].t), old);
  assert.deepEqual(errors, []);
});
