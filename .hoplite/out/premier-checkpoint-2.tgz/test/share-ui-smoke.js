'use strict';
// Проверка в настоящем браузере: node --test test/share-ui-smoke.js (нужны Playwright и Chromium, CHROMIUM_PATH).
// Кнопки «Поделиться» / «Экспорт», диалог ссылки, публичная страница, экспорт в .md и печать в PDF — на русском и английском.
const test = require('node:test'), assert = require('node:assert/strict'), fs = require('fs'), os = require('os'), path = require('path');
const { execFileSync } = require('child_process');
const { copyApp, seed, startServer, rm } = require('./helpers');

const OUT = process.env.SHARE_QA_DIR || '';
const md = `Вот пример.\n\nФормула: $x^2 + y^2 = z^2$, а так:\n\n$$\\int_0^1 x\\,dx = \\tfrac12$$\n\n| Имя | Значение |\n|---|---|\n| a | 1 |\n| b | 2 |\n\n\`\`\`js\nconst x = 1; // MARK-CODE\nfunction f(a) { return a * 2 }\n\`\`\`\n\nСсылка: https://example.com/path и \`inline\`.`;

for (const lang of ['ru', 'en']) {
  const en = lang === 'en';
  test(`ссылка на чат и экспорт в Chromium (${lang})`, { timeout: 120000 }, async (t) => {
    const { chromium } = require('playwright');
    const dir = copyApp(); seed(dir);
    fs.writeFileSync(dir + '/data/models.json', JSON.stringify([{ id: 'm1', name: 'UI Mock', modelId: 'mock', baseUrl: 'http://127.0.0.1:1', apiKey: 'test' }]));
    const s = await startServer(dir);
    const b = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH, args: ['--no-sandbox'] });
    t.after(async () => { await b.close(); await s.stop(); rm(dir); });
    const context = await b.newContext({ viewport: { width: 1280, height: 800 }, acceptDownloads: true });
    await context.addCookies([{ name: 'premier_session', value: 'tok1', url: s.base }, { name: 'premier_lang', value: lang, url: s.base }]);
    await context.route('**/*', (route) => new URL(route.request().url()).origin === s.base ? route.continue() : route.abort());
    const page = await context.newPage(), errors = [];
    page.on('pageerror', (e) => errors.push(e.message));
    page.on('console', (m) => { if (m.type() === 'error' && !/\/api\/share/.test(m.location().url)) errors.push(m.text()); }); // 404 на «ссылки ещё нет» — штатный ответ
    page.on('dialog', (d) => d.accept());
    await page.goto(s.base + '/chat');
    await page.waitForFunction(() => MODELS.length > 0);

    await t.test('кнопки видны только в непустом чате', async () => {
      assert.equal(await page.locator('#shareBtn').isVisible(), false);
      assert.equal(await page.locator('#exportBtn').isVisible(), false);
      await page.evaluate((md) => {
        const mk = (r, t, x = {}) => ({ id: 'm' + Math.random().toString(36).slice(2, 8), r, t, ...x });
        S.chats.unshift({ id: 'c1', title: 'Тест / чата?', proj: null, msgs: [mk('u', 'Привет <b>мир</b>', { files: [{ name: 'a.txt', text: 'SECRET-FILE-BODY' }, { name: 'b.py', text: 'x' }], images: ['data:image/png;base64,AAAA'] }), mk('a', md, { m: 'UI Mock', vers: [{ t: 'VARIANT-TEXT' }], vi: 0 }), mk('a', 'ошибка', { err: 'boom' }), mk('a', '', {}), mk('a', 'Остановлено', { cancelled: true })] });
        S.cur = 'c1'; save(); render();
      }, md);
      assert.equal(await page.locator('#shareBtn').isVisible(), true);
      assert.equal(await page.locator('#exportBtn').isVisible(), true);
      assert.equal(await page.locator('#shareBtn').getAttribute('aria-label'), en ? 'Share' : 'Поделиться');
      assert.equal(await page.locator('#exportBtn').getAttribute('aria-label'), en ? 'Export' : 'Экспорт');
      await page.evaluate(() => { S.cur = null; render(); });
      assert.equal(await page.locator('#shareBtn').isVisible(), false);
      await page.evaluate(() => { S.cur = 'c1'; render(); });
      assert.equal(await page.locator('#shareBtn').isVisible(), true);
    });

    let url, snap;
    await t.test('диалог: создать, копировать, обновить, дождаться ответа', async () => {
      await context.grantPermissions(['clipboard-read', 'clipboard-write'], { origin: s.base });
      await page.click('#shareBtn');
      await page.waitForSelector('#shMake');
      assert.equal(await page.locator('#dtitle').textContent(), en ? 'Share chat' : 'Поделиться чатом');
      assert.match(await page.locator('#shBox').textContent(), en ? /Files and images are not published/ : /Файлы и картинки не публикуются/);
      await page.evaluate(() => busyMap.set('c1', new AbortController()));
      await page.click('#dclose'); await page.click('#shareBtn'); await page.waitForSelector('#shMake');
      assert.equal(await page.locator('#shMake').isDisabled(), true, 'пока идёт ответ — создавать нельзя');
      await page.evaluate(() => busyMap.delete('c1'));
      await page.click('#dclose'); await page.click('#shareBtn'); await page.waitForSelector('#shMake');
      await page.click('#shMake');
      await page.waitForSelector('#shUrl');
      url = await page.inputValue('#shUrl');
      assert.match(url, new RegExp('^' + s.base + '/c/[A-Za-z0-9_-]{12}$'));
      await page.click('#shCopy');
      assert.equal(await page.evaluate(() => navigator.clipboard.readText()), url);
      snap = JSON.parse(fs.readFileSync(path.join(dir, 'data', 'shares', url.split('/c/')[1] + '.json'), 'utf8'));
      assert.deepEqual(snap.msgs.map((m) => m.r), ['u', 'a'], 'ошибки, остановленные и пустые ответы не попали');
      assert.equal(snap.msgs[0].t, 'Привет <b>мир</b>\n\n📎 a.txt, b.py');
      assert.ok(!JSON.stringify(snap).includes('SECRET-FILE-BODY') && !JSON.stringify(snap).includes('VARIANT-TEXT') && !JSON.stringify(snap).includes('data:image'));
      assert.equal(snap.msgs[1].m, 'UI Mock');
      // закрыть и открыть заново — ссылка находится по chatId
      await page.click('#dclose'); await page.click('#shareBtn');
      await page.waitForSelector('#shUrl');
      assert.equal(await page.inputValue('#shUrl'), url);
    });

    await t.test('публичная страница: разметка, формулы, подсветка, без ошибок на 1280 и 390', async () => {
      const guest = await b.newContext({ viewport: { width: 1280, height: 800 } });
      await guest.route('**/*', (route) => new URL(route.request().url()).origin === s.base ? route.continue() : route.abort());
      const gp = await guest.newPage(), gerr = [];
      gp.on('pageerror', (e) => gerr.push(e.message)); gp.on('console', (m) => { if (m.type() === 'error') gerr.push(m.text()); });
      await gp.goto(url + (en ? '?lang=en' : ''));
      assert.equal(await gp.getAttribute('html', 'lang'), lang);
      assert.equal(await gp.locator('.sh-title').textContent(), 'Тест / чата?');
      assert.equal(await gp.locator('#shCta').textContent(), en ? 'Try Premier for free' : 'Попробовать Premier бесплатно');
      assert.equal(await gp.getAttribute('#shCta', 'href'), '/');
      assert.equal(await gp.getAttribute('.sh-brand', 'href'), '/');
      assert.match(await gp.locator('#shNote').textContent(), en ? /^Snapshot of the chat at the time of sharing/ : /^Копия чата на момент публикации/);
      assert.equal(await gp.locator('.msg').count(), 2);
      assert.equal(await gp.locator('.u .bub').textContent(), 'Привет <b>мир</b>\n\n📎 a.txt, b.py');
      assert.equal(await gp.locator('.u .bub b').count(), 0, 'текст пользователя не превращается в разметку');
      assert.match(await gp.locator('.a .who').textContent(), /Premier\s*· UI Mock/);
      await gp.waitForSelector('.md .katex', { timeout: 15000 });
      await gp.waitForSelector('.pre code .hljs-keyword', { timeout: 15000 });
      assert.ok((await gp.locator('.md .katex').count()) >= 2);
      assert.equal(await gp.locator('.tbl table tr').count(), 3);
      assert.equal(await gp.locator('.md a[href="https://example.com/path"]').count(), 1);
      assert.equal(await gp.locator('.md .pre .bar span').textContent(), 'js');
      assert.equal(await gp.locator('.pre .bar button').textContent(), en ? 'Copy' : 'Копировать');
      assert.equal(await gp.locator('.art, [data-art]').count(), 0);
      await guest.grantPermissions(['clipboard-read', 'clipboard-write'], { origin: s.base });
      await gp.click('[data-copycode]');
      assert.match(await gp.evaluate(() => navigator.clipboard.readText()), /MARK-CODE/);
      assert.equal(await gp.locator('.pre .bar button').textContent(), en ? 'Copied' : 'Скопировано');
      for (const [name, w, h] of [['desktop', 1280, 800], ['mobile', 390, 844]]) {
        await gp.setViewportSize({ width: w, height: h });
        await gp.waitForTimeout(150);
        const sw = await gp.evaluate(() => ({ s: document.documentElement.scrollWidth, c: document.documentElement.clientWidth }));
        assert.ok(sw.s <= sw.c, `${name}: горизонтального прокручивания нет (${sw.s} > ${sw.c})`);
        if (OUT && !en) { fs.mkdirSync(OUT, { recursive: true }); await gp.screenshot({ path: path.join(OUT, `share-${name}.png`), fullPage: true }); }
      }
      if (OUT) for (const scheme of ['dark', 'light']) { await gp.setViewportSize({ width: 1280, height: 800 }); await gp.emulateMedia({ colorScheme: scheme }); await gp.waitForTimeout(100); await gp.screenshot({ path: path.join(OUT, `share-${lang}-${scheme}.png`) }); }
      assert.deepEqual(gerr, []);
      await guest.close();
    });

    await t.test('обновить копию и удалить ссылку', async () => {
      const id = url.split('/c/')[1];
      await page.evaluate(() => { cur().msgs.push({ id: 'mx1', r: 'u', t: 'Новое сообщение NEWMSG' }); });
      await page.click('#shUpd');
      await page.waitForFunction((txt) => /Link updated|Ссылка обновлена/.test(document.getElementById('toast').textContent), null);
      assert.equal(await page.inputValue('#shUrl'), url, 'адрес не меняется');
      const r = await fetch(url);
      assert.ok((await r.text()).includes('NEWMSG'));
      await page.click('#shDel');
      await page.waitForSelector('#shMake');
      assert.equal((await fetch(url)).status, 404);
      assert.ok(!fs.existsSync(path.join(dir, 'data', 'shares', id + '.json')));
      await page.click('#shMake'); await page.waitForSelector('#shUrl');
      assert.notEqual(await page.inputValue('#shUrl'), url);
      await page.click('#dclose');
    });

    await t.test('экспорт в Markdown', async () => {
      await page.click('#exportBtn');
      assert.equal(await page.locator('#expMenu.open').count(), 1);
      const [dl] = await Promise.all([page.waitForEvent('download'), page.click('[data-exp=md]')]);
      assert.equal(dl.suggestedFilename(), 'Тест _ чата_.md');
      const text = fs.readFileSync(await dl.path(), 'utf8');
      assert.ok(text.startsWith(`# Тест / чата?\n\n**${en ? 'You' : 'Вы'}:**\n\nПривет <b>мир</b>\n\n📎 a.txt, b.py\n\n---\n\n**Premier · UI Mock:**\n\nВот пример.`), text.slice(0, 200));
      assert.ok(text.includes('MARK-CODE') && text.includes('NEWMSG') && !text.includes('boom') && !text.includes('SECRET-FILE-BODY'));
      await page.waitForTimeout(250);
      assert.equal(await page.locator('#expMenu.open').count(), 0, 'меню закрылось');
    });

    await t.test('PDF: печатаются все сообщения', async () => {
      await page.evaluate(() => {
        const c = cur(), para = (i) => `MSG-${String(i).padStart(3, '0')} ` + 'длинный абзац ответа '.repeat(60);
        for (let i = 1; i <= 40; i++) { c.msgs.push({ id: 'p' + i, r: 'u', t: `Вопрос ${i}` }); c.msgs.push({ id: 'q' + i, r: 'a', t: para(i) + '\n\n```js\nconst veryLongLine' + i + ' = "' + 'x'.repeat(150) + '";\n```', m: 'UI Mock' }); }
        render(); window.print = () => { window.__printed = (window.__printed || 0) + 1; };
      });
      await page.click('#exportBtn'); await page.click('[data-exp=pdf]');
      await page.waitForFunction(() => window.__printed === 1);
      assert.equal(await page.evaluate(() => document.getElementById('col').dataset.title), 'Тест / чата?');
      const pdf = await page.pdf({ format: 'A4', printBackground: true });
      const file = path.join(OUT || os.tmpdir(), `chat-print-${lang}.pdf`); fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, pdf);
      const info = execFileSync('pdfinfo', [file]).toString(), pages = +/Pages:\s+(\d+)/.exec(info)[1];
      const text = execFileSync('pdftotext', ['-layout', file, '-']).toString();
      assert.ok(pages > 5, 'страниц: ' + pages);
      for (let i = 1; i <= 40; i++) assert.ok(text.includes('MSG-' + String(i).padStart(3, '0')), 'нет сообщения ' + i);
      assert.ok(text.includes('Тест / чата?') && text.includes('NEWMSG') && text.includes('Вопрос 40') && text.includes('veryLongLine40'));
      assert.ok(text.replace(/\s/g, '').includes('x'.repeat(150)), 'строка кода не обрезана');
      assert.ok(!text.includes(en ? 'Recent' : 'Недавние') && !/Premier может ошибаться|Premier can make mistakes/.test(text), 'боковой панели и поля ввода в печати нет');
      // тёмная тема на экране не должна давать тёмную печать
      await page.emulateMedia({ colorScheme: 'dark' }); await page.evaluate(() => document.documentElement.setAttribute('data-theme', 'dark'));
      const dark = path.join(path.dirname(file), `chat-print-dark-${lang}.pdf`); fs.writeFileSync(dark, await page.pdf({ format: 'A4', printBackground: true }));
      execFileSync('pdftoppm', ['-r', '20', '-f', '1', '-l', '1', '-singlefile', '-gray', dark, dark.replace(/\.pdf$/, '')]);
      const pgm = fs.readFileSync(dark.replace(/\.pdf$/, '.pgm')), px = pgm.subarray(pgm.length - 200 * 200);
      assert.ok(px.reduce((n, v) => n + v, 0) / px.length > 200, 'печать светлая в тёмной теме');
      await page.emulateMedia({ colorScheme: null }); await page.evaluate(() => document.documentElement.removeAttribute('data-theme'));
      await page.evaluate(() => dispatchEvent(new Event('afterprint')));
      assert.equal(await page.evaluate(() => document.getElementById('col').dataset.title), undefined);
    });
    assert.deepEqual(errors, []);
  });
}
