'use strict';
// Ссылка на чат: node --test tests/share.test.js. Сервер и база — во временной копии, не в data/.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { copyApp, seed, startServer, rm } = require('../test/helpers');

test('share by link: API, public page, validation, ownership, account deletion', { timeout: 60000 }, async (t) => {
  const dir = copyApp();
  seed(dir, {
    users: ['u1', 'u2', 'u3', 'u4'].map((id) => ({ id, login: id, email: id + '@example.com', created: '2026-01-01T00:00:00Z' })),
    sessions: { tok1: 'u1', tok2: 'u2', tok3: 'u3', tok4: 'u4' },
  });
  const s = await startServer(dir);
  t.after(async () => { await s.stop(); rm(dir); });
  const post = (token, body, q = '') => s.req('POST', '/api/share' + q, { token, body });
  const msgs = [{ r: 'u', t: 'Привет' }, { r: 'a', t: 'Здравствуйте! $x^2$', m: 'Mock' }];
  const pageData = (html) => { const m = /<script type="application\/json" id="share-data">([\s\S]*?)<\/script>/.exec(html); assert.ok(m, 'share-data block'); return JSON.parse(m[1]); };
  let id;

  await t.test('требует вход', async () => {
    assert.equal((await post(null, { chatId: 'c1', msgs })).status, 401);
    assert.equal((await s.req('GET', '/api/share?chatId=c1')).status, 401);
    assert.equal((await s.req('DELETE', '/api/share/AAAAAAAAAAAA')).status, 401);
  });

  await t.test('удаление чата через синхронизацию снимает его ссылку', async () => {
    const a = await post('tok4', { chatId: 'gone', title: 'Удалю', msgs });
    assert.equal(a.status, 200);
    const keep = await post('tok4', { chatId: 'stay', title: 'Оставлю', msgs });
    assert.equal((await s.req('POST', '/api/sync', { token: 'tok4', body: { base: 0, del: ['gone'] } })).status, 200);
    assert.equal((await s.req('GET', '/c/' + a.json.id)).status, 404);
    assert.equal((await s.req('GET', '/api/share?chatId=gone', { token: 'tok4' })).status, 404);
    assert.equal((await s.req('GET', '/c/' + keep.json.id)).status, 200, 'ссылки других чатов не трогаем');
    assert.equal((await s.req('POST', '/api/sync', { token: 'tok2', body: { base: 0, del: ['stay'] } })).status, 200);
    assert.equal((await s.req('GET', '/c/' + keep.json.id)).status, 200, 'чужое удаление с тем же id чата не снимает ссылку');
  });

  await t.test('создание, обновление с тем же id, поиск по chatId', async () => {
    const a = await post('tok1', { chatId: 'c1', title: 'Мой чат', msgs });
    assert.equal(a.status, 200);
    id = a.json.id;
    assert.match(id, /^[A-Za-z0-9_-]{12}$/);
    assert.equal(a.json.url, '/c/' + id);
    const b = await post('tok1', { chatId: 'c1', title: 'Мой чат 2', msgs: [...msgs, { r: 'u', t: 'ещё' }] });
    assert.equal(b.json.id, id);
    const g = await s.req('GET', '/api/share?chatId=c1', { token: 'tok1' });
    assert.equal(g.status, 200);
    assert.equal(g.json.id, id); assert.equal(g.json.url, '/c/' + id); assert.ok(g.json.updated);
    assert.equal((await s.req('GET', '/api/share?chatId=nope', { token: 'tok1' })).status, 404);
    assert.equal((await s.req('GET', '/api/share?chatId=c1', { token: 'tok2' })).status, 404, 'чужой chatId не виден');
    assert.equal((await s.req('GET', '/api/share?chatId=__proto__', { token: 'tok1' })).status, 404);
    const other = await post('tok2', { chatId: 'c1', msgs });
    assert.notEqual(other.json.id, id, 'тот же chatId у другого пользователя — отдельная ссылка');
    const f = JSON.parse(fs.readFileSync(path.join(dir, 'data', 'shares', id + '.json'), 'utf8'));
    assert.deepEqual(Object.keys(f).sort(), ['cid', 'created', 'id', 'msgs', 'title', 'uid', 'updated']);
    assert.equal(f.uid, 'u1'); assert.equal(f.cid, 'c1'); assert.equal(f.title, 'Мой чат 2'); assert.equal(f.msgs.length, 3);
  });

  await t.test('публичная страница: без cookie, заголовки, данные экранированы', async () => {
    const evil = '</script><script>alert(1)</script> & "q" <img src=x onerror=alert(2)>';
    const title = 'A <b>"x"</b> & y';
    const c = await post('tok3', { chatId: 'evil', title, msgs: [{ r: 'u', t: evil }, { r: 'a', t: evil, m: '<m>' }] });
    const r = await s.req('GET', '/c/' + c.json.id);
    assert.equal(r.status, 200);
    assert.match(r.headers.get('content-type'), /text\/html/);
    const csp = r.headers.get('content-security-policy');
    for (const d of ["script-src 'self'", "style-src 'self' 'unsafe-inline'", "img-src 'self' data:", "font-src 'self'", "object-src 'none'", "base-uri 'none'", "frame-ancestors 'none'"]) assert.ok(csp.includes(d), d);
    assert.match(r.headers.get('x-robots-tag'), /noindex/);
    assert.equal(r.headers.get('referrer-policy'), 'no-referrer');
    assert.equal(r.headers.get('x-content-type-options'), 'nosniff');
    assert.ok(!r.headers.get('set-cookie'));
    assert.match(r.text, /<html lang="ru">/);
    // единственные <script> — наши; текст пользователя не создал новых тегов и обработчиков
    assert.equal((r.text.match(/<script/gi) || []).length, 5);
    assert.ok(!r.text.includes('alert(1)</script>') && !r.text.includes('<img src=x'));
    assert.deepEqual(pageData(r.text).msgs, [{ r: 'u', t: evil }, { r: 'a', t: evil, m: '<m>' }]);
    assert.ok(r.text.includes('<title>A &lt;b&gt;&quot;x&quot;&lt;/b&gt; &amp; y — Premier</title>'));
    assert.ok(r.text.includes('<meta property="og:title" content="A &lt;b&gt;&quot;x&quot;&lt;/b&gt; &amp; y">'));
    assert.ok(r.text.includes('property="og:site_name" content="Premier"'));
    assert.match(r.text, /property="og:description" content="&lt;\/script&gt;&lt;script&gt;alert\(1\)/);
    assert.ok(!('uid' in pageData(r.text)) && !('cid' in pageData(r.text)), 'владелец не раскрывается');
    const en = await s.req('GET', '/c/' + id + '?lang=en');
    assert.match(en.text, /<html lang="en">/);
    assert.ok(en.text.includes('/en/js/02-markdown.js') && en.text.includes('/en/js/03-archives.js'));
    assert.ok((await s.req('GET', '/c/' + id)).text.includes('src="/js/02-markdown.js"'));
    const long = await post('tok3', { chatId: 'long', msgs: [{ r: 'u', t: 'слово '.repeat(100) }] });
    const desc = /property="og:description" content="([^"]*)"/.exec((await s.req('GET', '/c/' + long.json.id)).text)[1];
    assert.ok(desc.length <= 160 && desc.endsWith('…'));
    assert.equal((await s.req('GET', '/share.html')).status, 404, 'шаблон напрямую не отдаётся');
  });

  await t.test('неизвестная ссылка — 404-страница', async () => {
    for (const u of ['/c/AAAAAAAAAAAA', '/c/', '/c/..%2Fserver', '/c/' + 'a'.repeat(80)]) {
      const r = await s.req('GET', u);
      assert.equal(r.status, 404, u);
      assert.match(r.headers.get('x-robots-tag'), /noindex/);
      assert.ok(r.headers.get('content-security-policy'));
      assert.match(r.text, /Чат не найден/);
    }
    assert.match((await s.req('GET', '/c/AAAAAAAAAAAA?lang=en')).text, /Chat not found/);
  });

  await t.test('проверка данных', async () => {
    const bad = async (body, code = 400, q = '') => { const r = await post('tok4', body, q); assert.equal(r.status, code, JSON.stringify(body).slice(0, 80) + ' → ' + r.text.slice(0, 80)); return r; };
    const ok = [{ r: 'u', t: 'x' }];
    await bad({ msgs: ok });
    await bad({ chatId: 5, msgs: ok });
    await bad({ chatId: 'a'.repeat(65), msgs: ok });
    await bad({ chatId: 'a b', msgs: ok });
    await bad({ chatId: '__proto__', msgs: ok });
    await bad({ chatId: 'c', title: 'т'.repeat(121), msgs: ok });
    await bad({ chatId: 'c', title: 5, msgs: ok });
    await bad({ chatId: 'c' });
    await bad({ chatId: 'c', msgs: [] });
    await bad({ chatId: 'c', msgs: 'x' });
    await bad({ chatId: 'c', msgs: Array.from({ length: 501 }, () => ok[0]) });
    await bad({ chatId: 'c', msgs: [{ r: 'x', t: 'a' }] });
    await bad({ chatId: 'c', msgs: [{ r: 'u', t: 5 }] });
    await bad({ chatId: 'c', msgs: [{ r: 'u' }] });
    await bad({ chatId: 'c', msgs: [null] });
    await bad({ chatId: 'c', msgs: [{ r: 'a', t: 'a', m: 'm'.repeat(81) }] });
    await bad({ chatId: 'c', msgs: [{ r: 'a', t: 'a', m: 5 }] });
    await bad({ chatId: 'c', msgs: [{ r: 'u', t: 'a'.repeat(200001) }] });
    await bad({ chatId: 'c', msgs: [{ r: 'u', t: '   ' }] }, 400);
    assert.equal((await post('tok4', { chatId: 'c', msgs: [{ r: 'u', t: 'a'.repeat(200000) }] })).status, 200, '200 тыс. знаков — предел включительно');
    assert.equal((await post('tok4', { chatId: 'c', title: 'т'.repeat(120), msgs: [{ r: 'a', t: 'a', m: 'm'.repeat(80) }] })).status, 200);
    // общий размер: 11 × 190 тыс. > 2 МБ
    const big = Array.from({ length: 11 }, () => ({ r: 'u', t: 'ж'.repeat(190000) }));
    await bad({ chatId: 'c', msgs: big }, 413);
    await bad({ chatId: 'c', msgs: [{ r: 'u', t: 'x' }], pad: 'y'.repeat(2700000) }, 413);
    const broken = await fetch(s.base + '/api/share', { method: 'POST', headers: { 'Content-Type': 'application/json', Cookie: 'premier_session=tok4' }, body: '{oops' });
    assert.equal(broken.status, 400);
    // английские тексты ошибок
    assert.equal((await bad({ chatId: 'c', msgs: [{ r: 'x', t: 'a' }] }, 400, '?lang=en')).json.error, 'Invalid message');
    assert.equal((await bad({ chatId: 'c', msgs: big }, 413, '?lang=en')).json.error, 'The chat is larger than 2 MB — a link cannot be created');
    // лишние поля отбрасываются
    const r = await post('tok4', { chatId: 'extra', title: ' T ', evil: 1, msgs: [{ r: 'u', t: 'hi', html: '<b>', files: [1] }, { r: 'a', t: 'yo', m: 'M', steps: [1] }] });
    const f = JSON.parse(fs.readFileSync(path.join(dir, 'data', 'shares', r.json.id + '.json'), 'utf8'));
    assert.deepEqual(f.msgs, [{ r: 'u', t: 'hi' }, { r: 'a', t: 'yo', m: 'M' }]);
    assert.equal(f.title, 'T'); assert.equal(f.evil, undefined);
  });

  await t.test('удалить может только владелец', async () => {
    assert.equal((await s.req('DELETE', '/api/share/' + id, { token: 'tok2' })).status, 404);
    assert.equal((await s.req('GET', '/c/' + id)).status, 200, 'чужое удаление не сработало');
    assert.equal((await s.req('DELETE', '/api/share/short', { token: 'tok1' })).status, 404);
    assert.equal((await s.req('DELETE', '/api/share/' + id, { token: 'tok1' })).status, 200);
    assert.equal((await s.req('GET', '/c/' + id)).status, 404);
    assert.equal((await s.req('GET', '/api/share?chatId=c1', { token: 'tok1' })).status, 404);
    assert.ok(!fs.existsSync(path.join(dir, 'data', 'shares', id + '.json')));
    assert.equal((await s.req('DELETE', '/api/share/' + id, { token: 'tok1' })).status, 404);
    const again = await post('tok1', { chatId: 'c1', msgs });
    assert.notEqual(again.json.id, id, 'после удаления выдаётся новый адрес');
  });

  await t.test('ограничение частоты: 30 в час', async () => {
    let last;
    for (let i = 0; i < 31; i++) last = await post('tok2', { chatId: 'rl', msgs });
    assert.equal(last.status, 429);
    assert.match((await post('tok2', { chatId: 'rl', msgs }, '?lang=en')).json.error, /Too many link updates/);
  });

  await t.test('удаление аккаунта убирает ссылки', async () => {
    const a = await post('tok3', { chatId: 'gone', msgs }), shares = path.join(dir, 'data', 'shares');
    const mine = fs.readdirSync(shares).filter((f) => JSON.parse(fs.readFileSync(path.join(shares, f), 'utf8')).uid === 'u3');
    assert.ok(mine.length >= 3);
    const d = await s.req('DELETE', '/api/account', { token: 'tok3', body: { confirm: 'delete' } });
    assert.equal(d.status, 200);
    assert.equal((await s.req('GET', '/c/' + a.json.id)).status, 404);
    for (const f of mine) assert.ok(!fs.existsSync(path.join(shares, f)), f);
    assert.equal((await s.req('GET', '/c/' + id + '?lang=en')).status, 404);
    const other = fs.readdirSync(shares).filter((f) => JSON.parse(fs.readFileSync(path.join(shares, f), 'utf8')).uid !== 'u3');
    assert.ok(other.length > 0, 'ссылки других пользователей на месте');
  });
});
