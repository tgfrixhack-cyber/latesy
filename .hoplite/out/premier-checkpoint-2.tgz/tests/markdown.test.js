// Рендер Markdown в чате (public/js и public/en/js/03-archives.js): таблицы, псевдографика, разметка.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const root = path.join(__dirname, '..', 'public');
const escLine = fs.readFileSync(path.join(root, 'js', '01-core.js'), 'utf8').split('\n').find((l) => l.startsWith('const esc = '));
const load = (file) => {
  const ctx = vm.createContext({});
  vm.runInContext(escLine + '\n' + fs.readFileSync(path.join(root, file), 'utf8'), ctx);
  return vm.runInContext('block', ctx);
};
// полный рендер с настоящими KaTeX и highlight.js, как в браузере после их загрузки
const loadRich = (dir) => {
  const ctx = vm.createContext({});
  for (const f of ['vendor/katex/katex.min.js', 'vendor/hljs/highlight.min.js', 'js/rich.js', dir + '/02-markdown.js', dir + '/03-archives.js']) vm.runInContext((f === 'vendor/katex/katex.min.js' ? escLine + '\n' : '') + fs.readFileSync(path.join(root, f), 'utf8'), ctx, { filename: f });
  return { md: vm.runInContext('md', ctx), block: vm.runInContext('block', ctx) };
};

for (const file of ['js/03-archives.js', 'en/js/03-archives.js']) {
  const block = load(file);
  test(`${file}: псевдографика без блока кода сохраняет пробелы`, () => {
    const art = '┌──────┬─────┐\n│ Pro  │ 390 │\n└──────┴─────┘';
    assert.equal(block(`Тарифы:\n${art}\nИтого`), `<p>Тарифы:</p><pre class="txtart">${art}</pre><p>Итого</p>`);
    assert.equal(block('Прогресс: ████████░░ 80%'), '<pre class="txtart">Прогресс: ████████░░ 80%</pre>');
    assert.equal(block('│ <b>x</b> │ ──'), '<pre class="txtart">│ &lt;b&gt;x&lt;/b&gt; │ ──</pre>');
  });
  test(`${file}: таблицы с крайними | и без них`, () => {
    const t = '<div class="tbl"><table><thead><tr><th>A</th><th style="text-align:right">B</th></tr></thead><tbody><tr><td>1</td><td style="text-align:right">2</td></tr><tr><td>3</td><td style="text-align:right"></td></tr></tbody></table></div>';
    assert.equal(block('| A | B |\n|---|--:|\n| 1 | 2 |\n| 3 |'), t);
    assert.equal(block('A | B\n---|--:\n1 | 2\n3 |'), t);
    assert.equal(block('a | b\n---'), '<p>a | b</p><hr>');
    assert.match(block('A | B\n:-: | -:\n1 | 2'), /<th style="text-align:center">A<\/th><th style="text-align:right">B<\/th>/);
  });
  test(`${file}: курсив, зачёркивание, код и ссылки`, () => {
    assert.equal(block('*к* _i_ **ж** ***жк*** ~~x~~'), '<p><em>к</em> <em>i</em> <strong>ж</strong> <strong><em>жк</em></strong> <del>x</del></p>');
    assert.equal(block('snake_case_name и 2 * 3 * 4'), '<p>snake_case_name и 2 * 3 * 4</p>');
    assert.equal(block('`a*b*c` [*s*](https://x.io/a_b_c)'), '<p><code>a*b*c</code> <a href="https://x.io/a_b_c" target="_blank" rel="noopener"><em>s</em></a></p>');
  });
  test(`${file}: заголовки, цитаты, разделители`, () => {
    assert.equal(block('# A\n## B\n### C #'), '<h2>A</h2><h3>B</h3><h4>C</h4>');
    assert.equal(block('> **q**\n> - x\n\n---\n***'), '<blockquote><p><strong>q</strong></p><ul><li>x</li></ul></blockquote><hr><hr>');
  });
  test(`${file}: экранирование, картинки, голые ссылки, <br> в таблице`, () => {
    assert.equal(block('\\*не курсив\\* и 2\\_3'), '<p>*не курсив* и 2_3</p>');
    assert.equal(block('![схема](https://x.io/a.png)'), '<p><a href="https://x.io/a.png" target="_blank" rel="noopener">схема</a></p>');
    assert.equal(block('[вики](https://ru.wikipedia.org/wiki/A_(b))'), '<p><a href="https://ru.wikipedia.org/wiki/A_(b)" target="_blank" rel="noopener">вики</a></p>');
    assert.equal(block('см. https://x.io/a_b_c. И (https://y.io/q?a=1&b=2), "https://z.io"'),
      '<p>см. <a href="https://x.io/a_b_c" target="_blank" rel="noopener">https://x.io/a_b_c</a>. И (<a href="https://y.io/q?a=1&amp;b=2" target="_blank" rel="noopener">https://y.io/q?a=1&amp;b=2</a>), &quot;<a href="https://z.io" target="_blank" rel="noopener">https://z.io</a>&quot;</p>');
    assert.equal(block('`https://x.io` и [t](https://x.io)'), '<p><code>https://x.io</code> и <a href="https://x.io" target="_blank" rel="noopener">t</a></p>');
    assert.equal(block('a | b\n-|-\n1<br>2 | <script>'), '<div class="tbl"><table><thead><tr><th>a</th><th>b</th></tr></thead><tbody><tr><td>1<br>2</td><td>&lt;script&gt;</td></tr></tbody></table></div>');
    assert.equal(block('javascript:alert(1) [x](javascript:alert(1))'), '<p>javascript:alert(1) [x](javascript:alert(1))</p>');
  });
  test(`${file}: псевдографика в списках и цитатах`, () => {
    assert.equal(block('- Готово ████░░ 60%\n- Ещё'), '<ul><li>Готово ████░░ 60%</li><li>Ещё</li></ul>');
    assert.equal(block('> ┌─┐\n> └─┘'), '<blockquote><pre class="txtart">┌─┐\n└─┘</pre></blockquote>');
  });
  test(`${file}: патологический ввод не подвешивает рендер`, () => {
    const t0 = Date.now();
    block('*a '.repeat(60000)); block('# a' + ' '.repeat(30000) + 'b'); block('_x '.repeat(60000)); block('>'.repeat(6000) + ' x');
    block('https://x.io/' + '('.repeat(30000)); block('| a '.repeat(20000) + '\n' + '|-'.repeat(20000));
    assert.ok(Date.now() - t0 < 1500, `${Date.now() - t0} мс`);
  });
  test(`${file}: вложенные списки и нумерация`, () => {
    assert.equal(block('- a\n  - b\n    1. c\n- d'), '<ul><li>a<ul><li>b<ol><li>c</li></ol></li></ul></li><li>d</li></ul>');
    assert.equal(block('1. a\n\n2. b'), '<ol><li>a</li><li>b</li></ol>');
    assert.equal(block('1. a\n\nтекст\n\n2. b'), '<ol><li>a</li></ol><p>текст</p><ol start="2"><li>b</li></ol>');
    assert.equal(block('- a\n  ещё'), '<ul><li>a<br>ещё</li></ul>');
  });
}

for (const dir of ['js', 'en/js']) {
  test(`${dir}: формулы без KaTeX показываются исходником, цены не считаются формулами`, () => {
    const block = load(dir + '/03-archives.js');
    assert.equal(block('Площадь $S = \\pi r^2$ и \\(a<b\\)'), '<p>Площадь <code class="math-src">S = \\pi r^2</code> и <code class="math-src">a&lt;b</code></p>');
    assert.equal(block('Стоит $5 и $10, или 5$ и 10$. Экранировано: \\$x\\$'), '<p>Стоит $5 и $10, или 5$ и 10$. Экранировано: $x$</p>');
    assert.equal(block('Было $10, или 5$ за штуку; costs $10 or 5$ total; $x$ и $\\text{Площадь } S$'), '<p>Было $10, или 5$ за штуку; costs $10 or 5$ total; <code class="math-src">x</code> и <code class="math-src">\\text{Площадь } S</code></p>');
    assert.equal(block('$$\nx^2\n$$\nдалее'), '<div class="math-d"><code class="math-src">x^2</code></div><p>далее</p>');
    assert.equal(block('`$a$` и *$b_1$*'), '<p><code>$a$</code> и <em><code class="math-src">b_1</code></em></p>');
    assert.equal(block('$$\n\\frac{1'), '<div class="math-d"><code class="math-src">\n\\frac{1</code></div>'); // формула ещё печатается
  });
  test(`${dir}: KaTeX и подсветка кода`, () => {
    const { md, block } = loadRich(dir);
    const inl = block('Итог: $x^2$');
    assert.match(inl, /^<p>Итог: <span class="katex"><span class="katex-mathml"><math/);
    assert.match(block('\\[\\int_0^1 x\\,dx\\]'), /^<div class="math-d"><span class="katex-display">/);
    assert.match(block('$$\n\\begin{aligned}a&=1\\\\b&=2\\end{aligned}\n$$'), /katex-display/);
    assert.match(block('$\\href{javascript:alert(1)}{x}$'), /^<p><span class="katex">/);
    assert.doesNotMatch(block('$\\href{javascript:alert(1)}{x}$'), /href="javascript/);
    assert.match(block('$\\frac{$'), /math-src|katex-error|katex/); // ошибка TeX не роняет рендер
    const code = md('```python\ndef f(x):\n    return "<b>"  # комментарий\n```', null);
    assert.match(code, /<code><span class="hljs-keyword">def<\/span> <span class="hljs-title function_">f<\/span>/);
    assert.match(code, /<span class="hljs-string">&quot;&lt;b&gt;&quot;<\/span>/);
    assert.doesNotMatch(code, /<b>/);
    assert.match(md('```\n┌─┐\n```', null), /<pre class="boxart"><code>┌─┐<\/code><\/pre>/); // без языка — без подсветки
    assert.match(md('```nosuchlang\n<i>\n```', null), /<code>&lt;i&gt;<\/code>/);
  });
}
