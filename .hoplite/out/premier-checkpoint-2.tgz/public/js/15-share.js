// Premier — клиент: ссылка на чат и экспорт (общие переменные — в 01-core.js; файлы подключаются по порядку в chat.html)
/* ---------- снимок чата ---------- */
// только активная ветка и только текст; ошибки, остановленные, недописанные и пустые ответы пропускаем
function shareSnap(c) {
  const out = [];
  for (const m of c.msgs) {
    if ((m.r !== 'u' && m.r !== 'a') || m.err || m.cancelled || m.live) continue;
    let t = m.r === 'a' ? stripLog(m.t) : String(m.t || '').trim();
    const f = m.r === 'u' ? (m.files || []).map((x) => x.name).filter(Boolean) : [];
    if (f.length) t = (t ? t + '\n\n' : '') + '📎 ' + f.join(', ');
    if (t) out.push(m.r === 'a' && m.m ? { r: 'a', t, m: String(m.m).slice(0, 80) } : { r: m.r, t });
  }
  return out;
}
const shareTitle = (c) => String(c.title || '').trim().slice(0, 120);
/* ---------- ссылка на чат ---------- */
let shareTok = 0;
async function shareApi(method, url, body) {
  const r = await fetch(url, { method, headers: body ? { 'Content-Type': 'application/json' } : {}, body: body ? JSON.stringify(body) : undefined });
  if (r.status === 401) { toLogin(); throw new Error('401'); }
  return { ok: r.ok, status: r.status, j: await r.json().catch(() => ({})) };
}
const shareLive = (tok) => $('modal').classList.contains('on') && $('shBox')?.dataset.tok === String(tok);
function shareView(c, link, tok) {
  const busy = busyMap.has(c.id), full = link ? location.origin + link.url : '';
  $('dbody').innerHTML = `<div id="shBox" data-tok="${tok}">` + (link
    ? `<p class="shp">Копия чата на момент публикации. Ссылку увидит любой, у кого она есть. Файлы и картинки не публикуются.</p>
      <div class="field"><span>Ссылка на чат</span><div class="shurl"><input id="shUrl" readonly value="${esc(full)}" aria-label="Ссылка на чат"><button type="button" class="btn" id="shCopy">Копировать</button></div><small>Обновлено: ${esc(new Date(link.updated).toLocaleString('ru-RU'))}</small></div>
      <div class="btns"><button type="button" class="btn dangerb" id="shDel">Удалить ссылку</button><div class="sp"></div><button type="button" class="btn pri" id="shUpd"${busy ? ' disabled' : ''}>Обновить</button></div>`
    : `<p class="shp">Создайте публичную ссылку на копию этого чата — её откроет любой, у кого она есть, даже без аккаунта. Файлы и картинки не публикуются.</p>
      <div class="btns"><button type="button" class="btn" id="shCancel">Отмена</button><button type="button" class="btn pri" id="shMake"${busy ? ' disabled' : ''}>Создать ссылку</button></div>`)
    + (busy ? '<p class="shp shwait">Дождитесь, пока Premier закончит ответ.</p>' : '') + '</div>';
  const save = async (btn) => {
    if (busyMap.has(c.id)) return toast('Дождитесь, пока Premier закончит ответ');
    const msgs = shareSnap(c); if (!msgs.length) return toast('В чате пока нет сообщений для публикации');
    btn.disabled = true;
    try {
      const r = await shareApi('POST', '/api/share', { chatId: c.id, title: shareTitle(c), msgs });
      if (!r.ok) { btn.disabled = false; return toast(r.j.error || 'Не удалось сохранить ссылку'); }
      if (shareLive(tok)) shareView(c, r.j, tok);
      toast(link ? 'Ссылка обновлена' : 'Ссылка создана');
    } catch { btn.disabled = false; toast('Нет связи с сервером. Попробуйте ещё раз'); }
  };
  if (!link) { $('shCancel').onclick = closePanel; $('shMake').onclick = (e) => save(e.currentTarget); return; }
  $('shUpd').onclick = (e) => save(e.currentTarget);
  $('shUrl').onfocus = (e) => e.target.select();
  $('shCopy').onclick = async () => {
    try { await navigator.clipboard.writeText(full); } catch { $('shUrl').select(); document.execCommand('copy'); }
    toast('Ссылка скопирована');
  };
  $('shDel').onclick = async (e) => {
    const btn = e.currentTarget;
    if (!confirm('Удалить ссылку? Она перестанет открываться у всех, кому вы её отправили.')) return;
    btn.disabled = true;
    try {
      const r = await shareApi('DELETE', '/api/share/' + link.id);
      if (!r.ok && r.status !== 404) { btn.disabled = false; return toast(r.j.error || 'Не удалось удалить ссылку'); }
      if (shareLive(tok)) shareView(c, null, tok);
      toast('Ссылка удалена');
    } catch { btn.disabled = false; toast('Нет связи с сервером. Попробуйте ещё раз'); }
  };
}
async function shareOpen() {
  const c = cur(); if (!c || !c.msgs.length) return;
  const tok = ++shareTok;
  dlgW(false); $('dtitle').textContent = 'Поделиться чатом';
  $('dbody').innerHTML = `<div id="shBox" data-tok="${tok}"><p class="shp">Загрузка…</p></div>`; $('modal').classList.add('on');
  try {
    const r = await shareApi('GET', '/api/share?chatId=' + encodeURIComponent(c.id));
    if (shareLive(tok)) shareView(c, r.ok ? r.j : null, tok);
  } catch { if (shareLive(tok)) shareView(c, null, tok); }
}
/* ---------- экспорт ---------- */
function exportMd() {
  const c = cur(), msgs = c && shareSnap(c); if (!msgs?.length) return toast('В чате пока нет сообщений для экспорта');
  const text = '# ' + (shareTitle(c) || 'Чат') + '\n\n' + msgs.map((m) => (m.r === 'u' ? '**Вы:**' : '**Premier' + (m.m ? ' · ' + m.m : '') + ':**') + '\n\n' + m.t).join('\n\n---\n\n') + '\n';
  const name = (shareTitle(c).replace(/[\\/:*?"<>|\u0000-\u001f]/g, '_').replace(/^[\s.]+|[\s.]+$/g, '').slice(0, 80) || 'chat') + '.md';
  const u = URL.createObjectURL(new Blob([text], { type: 'text/markdown;charset=utf-8' })), a = document.createElement('a');
  a.href = u; a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(u), 5000);
}
// печать: стили @media print (print.css) разворачивают чат на всю высоту; заголовок чата — в имени файла и над перепиской
function exportPdf() {
  const c = cur(), col = $('col'); if (!c || !c.msgs.length) return;
  const was = document.title, done = () => { document.title = was; delete col.dataset.title; removeEventListener('afterprint', done); };
  document.title = c.title || 'Premier'; col.dataset.title = c.title || ''; addEventListener('afterprint', done);
  setTimeout(() => print(), 60);
}
const expMenu = (open) => { $('expMenu').classList.toggle('open', open); $('exportBtn').setAttribute('aria-expanded', String(open)); };
$('shareBtn').onclick = shareOpen;
$('exportBtn').onclick = (e) => { e.stopPropagation(); expMenu(!$('expMenu').classList.contains('open')); };
$('expMenu').onclick = (e) => { const b = e.target.closest('[data-exp]'); if (!b) return; expMenu(false); b.dataset.exp === 'md' ? exportMd() : exportPdf(); };
document.addEventListener('click', (e) => { if (!e.target.closest('.exp')) expMenu(false); });
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') expMenu(false); });
