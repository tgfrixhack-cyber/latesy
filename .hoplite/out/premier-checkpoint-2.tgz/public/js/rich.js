// Premier — формулы (KaTeX) и подсветка кода (highlight.js). Общий файл: чат RU, чат EN и страница общего чата.
// Библиотеки грузятся лениво — только когда в ответе встретились формула или код с языком.
// После загрузки документ получает событие premier:rich, и страница перерисовывает сообщения.
const Rich = (() => {
  const WEB = typeof document !== 'undefined';
  const SRC = { katex: ['/vendor/katex/katex.min.js?v=0.19.1', '/vendor/katex/katex.min.css?v=0.19.1'], hljs: ['/vendor/hljs/highlight.min.js?v=11.12.0'] };
  const state = {}, cache = new Map();
  function want(name) {
    if (!WEB || state[name]) return;
    state[name] = 'loading';
    const [js, css] = SRC[name];
    if (css) { const l = document.createElement('link'); l.rel = 'stylesheet'; l.href = css; document.head.appendChild(l); }
    const s = document.createElement('script'); s.src = js; s.async = true;
    s.onload = () => { state[name] = 'ready'; document.dispatchEvent(new Event('premier:rich')); };
    s.onerror = () => { state[name] = 'failed'; }; // без библиотеки остаётся исходный текст формулы / код без цвета
    document.head.appendChild(s);
  }
  const remember = (k, h) => { if (cache.size > 1500) cache.clear(); cache.set(k, h); return h; };
  const unesc = (s) => s.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&amp;/g, '&');
  // src — TeX, уже прошедший esc(); возвращает HTML формулы или исходник, пока KaTeX грузится
  function math(src, display) {
    const k = (display ? 'D' : 'I') + src;
    if (cache.has(k)) return cache.get(k);
    if (typeof katex === 'undefined') { want('katex'); return `<code class="math-src">${src}</code>`; }
    let h;
    try { h = katex.renderToString(unesc(src), { displayMode: !!display, throwOnError: false, strict: 'ignore', trust: false, maxExpand: 500, maxSize: 30, output: 'htmlAndMathml' }); }
    catch { h = `<code class="math-src">${src}</code>`; }
    return remember(k, h);
  }
  // code — исходный текст; null, если подсветить нельзя (нет языка, библиотека не загружена, слишком большой файл)
  function code(src, lang, closed) {
    lang = String(lang || '').toLowerCase();
    if (!lang || src.length > (closed ? 150000 : 20000)) return null;
    if (typeof hljs === 'undefined') { want('hljs'); return null; }
    if (!hljs.getLanguage(lang)) return null;
    const k = 'C' + lang + '\u0000' + src;
    if (cache.has(k)) return cache.get(k);
    let h; try { h = hljs.highlight(src, { language: lang, ignoreIllegals: true }).value; } catch { return null; }
    return closed ? remember(k, h) : h; // недописанный блок меняется на каждом фрагменте — не кэшируем
  }
  if (WEB) document.addEventListener('premier:rich', () => { if (typeof renderChat === 'function') renderChat(); });
  return { math, code };
})();
