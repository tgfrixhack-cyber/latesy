// Premier — клиент: ссылка на чат и экспорт (общие переменные — в 01-core.js; файлы подключаются по порядку в chat.html)
/* ---------- снимок чата ---------- */
// только активная ветка и только текст; ошибки, остановленные, недописанные и пустые ответы пропускаем
function shareSnap(c) {
  const out = [];
  for (const m of c.msgs) {
    if ((m.r !== 'u' && m.r !== 'a') || m.err || m.cancelled || m.live) continue;
    let t = m.r === 'a' ? stripLog(m.t) : String(m.t || '').trim();
    const f = m.r === 'u' ? (m.files || []).map((x) => x.name).filter(Boolean) : [];
    if (f.length) t = (t ? t + '\n\n' : '') + '📎 ' + f.join(', ');
    if (t) out.push(m.r === 'a' && m.m ? { r: 'a', t, m: String(m.m).slice(0, 80) } : { r: m.r, t });
  }
  return out;
}
const shareTitle = (c) => String(c.title || '').trim().slice(0, 120);
/* ---------- ссылка на чат ---------- */
let shareTok = 0;
async function shareApi(method, url, body) {
  const r = await fetch(url, { method, headers: body ? { 'Content-Type': 'application/json' } : {}, body: body ? JSON.stringify(body) : undefined });
  if (r.status === 401) { toLogin(); throw new Error('401'); }
  return { ok: r.ok, status: r.status, j: await r.json().catch(() => ({})) };
}
const shareLive = (tok) => $('modal').classList.contains('on') && $('shBox')?.dataset.tok === String(tok);
function shareView(c, link, tok) {
  const busy = busyMap.has(c.id), full = link ? location.origin + link.url : '';
  $('dbody').innerHTML = `<div id="shBox" data-tok="${tok}">` + (link
    ? `<p class="shp">Snapshot of the chat at the time of sharing. Anyone with the link can see it. Files and images are not published.</p>
      <div class="field"><span>Chat link</span><div class="shurl"><input id="shUrl" readonly value="${esc(full)}" aria-label="Chat link"><button type="button" class="btn" id="shCopy">Copy</button></div><small>Updated: ${esc(new Date(link.updated).toLocaleString('en-US'))}</small></div>
      <div class="btns"><button type="button" class="btn dangerb" id="shDel">Delete link</button><div class="sp"></div><button type="button" class="btn pri" id="shUpd"${busy ? ' disabled' : ''}>Update</button></div>`
    : `<p class="shp">Create a public link to a copy of this chat — anyone with the link can open it, even without an account. Files and images are not published.</p>
      <div class="btns"><button type="button" class="btn" id="shCancel">Cancel</button><button type="button" class="btn pri" id="shMake"${busy ? ' disabled' : ''}>Create link</button></div>`)
    + (busy ? '<p class="shp shwait">Wait until Premier finishes the answer.</p>' : '') + '</div>';
  const save = async (btn) => {
    if (busyMap.has(c.id)) return toast('Wait until Premier finishes the answer');
    const msgs = shareSnap(c); if (!msgs.length) return toast('The chat has no messages to share yet');
    btn.disabled = true;
    try {
      const r = await shareApi('POST', '/api/share', { chatId: c.id, title: shareTitle(c), msgs });
      if (!r.ok) { btn.disabled = false; return toast(r.j.error || 'Could not save the link'); }
      if (shareLive(tok)) shareView(c, r.j, tok);
      toast(link ? 'Link updated' : 'Link created');
    } catch { btn.disabled = false; toast('No connection to the server. Please try again'); }
  };
  if (!link) { $('shCancel').onclick = closePanel; $('shMake').onclick = (e) => save(e.currentTarget); return; }
  $('shUpd').onclick = (e) => save(e.currentTarget);
  $('shUrl').onfocus = (e) => e.target.select();
  $('shCopy').onclick = async () => {
    try { await navigator.clipboard.writeText(full); } catch { $('shUrl').select(); document.execCommand('copy'); }
    toast('Link copied');
  };
  $('shDel').onclick = async (e) => {
    const btn = e.currentTarget;
    if (!confirm('Delete the link? It will stop working for everyone you sent it to.')) return;
    btn.disabled = true;
    try {
      const r = await shareApi('DELETE', '/api/share/' + link.id);
      if (!r.ok && r.status !== 404) { btn.disabled = false; return toast(r.j.error || 'Could not delete the link'); }
      if (shareLive(tok)) shareView(c, null, tok);
      toast('Link deleted');
    } catch { btn.disabled = false; toast('No connection to the server. Please try again'); }
  };
}
async function shareOpen() {
  const c = cur(); if (!c || !c.msgs.length) return;
  const tok = ++shareTok;
  dlgW(false); $('dtitle').textContent = 'Share chat';
  $('dbody').innerHTML = `<div id="shBox" data-tok="${tok}"><p class="shp">Loading…</p></div>`; $('modal').classList.add('on');
  try {
    const r = await shareApi('GET', '/api/share?chatId=' + encodeURIComponent(c.id));
    if (shareLive(tok)) shareView(c, r.ok ? r.j : null, tok);
  } catch { if (shareLive(tok)) shareView(c, null, tok); }
}
/* ---------- экспорт ---------- */
function exportMd() {
  const c = cur(), msgs = c && shareSnap(c); if (!msgs?.length) return toast('The chat has no messages to export yet');
  const text = '# ' + (shareTitle(c) || 'Chat') + '\n\n' + msgs.map((m) => (m.r === 'u' ? '**You:**' : '**Premier' + (m.m ? ' · ' + m.m : '') + ':**') + '\n\n' + m.t).join('\n\n---\n\n') + '\n';
  const name = (shareTitle(c).replace(/[\\/:*?"<>|\u0000-\u001f]/g, '_').replace(/^[\s.]+|[\s.]+$/g, '').slice(0, 80) || 'chat') + '.md';
  const u = URL.createObjectURL(new Blob([text], { type: 'text/markdown;charset=utf-8' })), a = document.createElement('a');
  a.href = u; a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(u), 5000);
}
// печать: стили @media print (print.css) разворачивают чат на всю высоту; заголовок чата — в имени файла и над перепиской
function exportPdf() {
  const c = cur(), col = $('col'); if (!c || !c.msgs.length) return;
  const was = document.title, done = () => { document.title = was; delete col.dataset.title; removeEventListener('afterprint', done); };
  document.title = c.title || 'Premier'; col.dataset.title = c.title || ''; addEventListener('afterprint', done);
  setTimeout(() => print(), 60);
}
const expMenu = (open) => { $('expMenu').classList.toggle('open', open); $('exportBtn').setAttribute('aria-expanded', String(open)); };
$('shareBtn').onclick = shareOpen;
$('exportBtn').onclick = (e) => { e.stopPropagation(); expMenu(!$('expMenu').classList.contains('open')); };
$('expMenu').onclick = (e) => { const b = e.target.closest('[data-exp]'); if (!b) return; expMenu(false); b.dataset.exp === 'md' ? exportMd() : exportPdf(); };
document.addEventListener('click', (e) => { if (!e.target.closest('.exp')) expMenu(false); });
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') expMenu(false); });
