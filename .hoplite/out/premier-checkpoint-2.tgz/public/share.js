// Страница общего чата /c/<id>: снимок лежит в #share-data, ответы рисует тот же md(), что и в чате (без запуска артефактов)
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
(() => {
  const en = document.documentElement.lang === 'en';
  const T = en
    ? { cta: 'Try Premier for free', note: 'Snapshot of the chat at the time of sharing', copy: 'Copy', copied: 'Copied', locale: 'en-US' }
    : { cta: 'Попробовать Premier бесплатно', note: 'Копия чата на момент публикации', copy: 'Копировать', copied: 'Скопировано', locale: 'ru-RU' };
  let D = { msgs: [] };
  try { D = JSON.parse(document.getElementById('share-data').textContent); } catch {}
  try { const q = new URLSearchParams(location.search).get('theme'); if (q === 'dark' || q === 'light') document.documentElement.setAttribute('data-theme', q); } catch {}
  document.getElementById('shCta').textContent = T.cta;
  const when = D.updated || D.created ? new Date(D.updated || D.created) : null;
  document.getElementById('shNote').textContent = T.note + (when && !isNaN(when) ? ' · ' + when.toLocaleDateString(T.locale, { day: 'numeric', month: 'long', year: 'numeric' }) : '');
  const col = document.getElementById('col');
  const body = (t) => { try { return md(t, null); } catch { return '<p>' + esc(t) + '</p>'; } };
  function render() {
    col.innerHTML = D.msgs.map((m) => m.r === 'u'
      ? `<div class="msg"><div class="u"><div class="bub">${esc(m.t)}</div></div></div>`
      : `<div class="msg a"><div class="who"><div class="mark"><img src="/icon-p-amber.svg" alt=""></div>Premier${m.m ? ` <i>· ${esc(m.m)}</i>` : ''}</div><div class="md">${body(m.t)}</div></div>`).join('');
  }
  render();
  document.addEventListener('premier:rich', render); // формулы и подсветка подгружаются лениво
  document.addEventListener('click', (e) => {
    const b = e.target.closest('[data-copycode]'), code = b && b.closest('.pre')?.querySelector('code'); if (!code) return;
    const text = code.innerText;
    const done = () => { b.textContent = T.copied; setTimeout(() => (b.textContent = T.copy), 1400); };
    if (navigator.clipboard) navigator.clipboard.writeText(text).then(done, () => {});
    else { const ta = document.createElement('textarea'); ta.value = text; document.body.appendChild(ta); ta.select(); try { document.execCommand('copy'); done(); } catch {} ta.remove(); }
  });
})();
