// Рендер Markdown в чате (public/js и public/en/js/03-archives.js): таблицы, псевдографика, разметка.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const root = path.join(__dirname, '..', 'public');
const escLine = fs.readFileSync(path.join(root, 'js', '01-core.js'), 'utf8').split('\n').find((l) => l.startsWith('const esc = '));
const load = (file) => {
  const ctx = vm.createContext({});
  vm.runInContext(escLine + '\n' + fs.readFileSync(path.join(root, file), 'utf8'), ctx);
  return vm.runInContext('block', ctx);
};

for (const file of ['js/03-archives.js', 'en/js/03-archives.js']) {
  const block = load(file);
  test(`${file}: псевдографика без блока кода сохраняет пробелы`, () => {
    const art = '┌──────┬─────┐\n│ Pro  │ 390 │\n└──────┴─────┘';
    assert.equal(block(`Тарифы:\n${art}\nИтого`), `<p>Тарифы:</p><pre class="txtart">${art}</pre><p>Итого</p>`);
    assert.equal(block('Прогресс: ████████░░ 80%'), '<pre class="txtart">Прогресс: ████████░░ 80%</pre>');
    assert.equal(block('│ <b>x</b> │ ──'), '<pre class="txtart">│ &lt;b&gt;x&lt;/b&gt; │ ──</pre>');
  });
  test(`${file}: таблицы с крайними | и без них`, () => {
    const t = '<div class="tbl"><table><thead><tr><th>A</th><th style="text-align:right">B</th></tr></thead><tbody><tr><td>1</td><td style="text-align:right">2</td></tr><tr><td>3</td><td style="text-align:right"></td></tr></tbody></table></div>';
    assert.equal(block('| A | B |\n|---|--:|\n| 1 | 2 |\n| 3 |'), t);
    assert.equal(block('A | B\n---|--:\n1 | 2\n3 |'), t);
    assert.equal(block('a | b\n---'), '<p>a | b</p><hr>');
    assert.match(block('A | B\n:-: | -:\n1 | 2'), /<th style="text-align:center">A<\/th><th style="text-align:right">B<\/th>/);
  });
  test(`${file}: курсив, зачёркивание, код и ссылки`, () => {
    assert.equal(block('*к* _i_ **ж** ***жк*** ~~x~~'), '<p><em>к</em> <em>i</em> <strong>ж</strong> <strong><em>жк</em></strong> <del>x</del></p>');
    assert.equal(block('snake_case_name и 2 * 3 * 4'), '<p>snake_case_name и 2 * 3 * 4</p>');
    assert.equal(block('`a*b*c` [*s*](https://x.io/a_b_c)'), '<p><code>a*b*c</code> <a href="https://x.io/a_b_c" target="_blank" rel="noopener"><em>s</em></a></p>');
  });
  test(`${file}: заголовки, цитаты, разделители`, () => {
    assert.equal(block('# A\n## B\n### C #'), '<h2>A</h2><h3>B</h3><h4>C</h4>');
    assert.equal(block('> **q**\n> - x\n\n---\n***'), '<blockquote><p><strong>q</strong></p><ul><li>x</li></ul></blockquote><hr><hr>');
  });
  test(`${file}: вложенные списки и нумерация`, () => {
    assert.equal(block('- a\n  - b\n    1. c\n- d'), '<ul><li>a<ul><li>b<ol><li>c</li></ol></li></ul></li><li>d</li></ul>');
    assert.equal(block('1. a\n\n2. b'), '<ol><li>a</li><li>b</li></ol>');
    assert.equal(block('1. a\n\nтекст\n\n2. b'), '<ol><li>a</li></ol><p>текст</p><ol start="2"><li>b</li></ol>');
    assert.equal(block('- a\n  ещё'), '<ul><li>a<br>ещё</li></ul>');
  });
}
